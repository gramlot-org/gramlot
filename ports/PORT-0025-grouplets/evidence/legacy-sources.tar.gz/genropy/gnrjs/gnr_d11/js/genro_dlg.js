/*
 *-*- coding: UTF-8 -*-
 *--------------------------------------------------------------------------
 * package       : Genro js - see LICENSE for details
 * module genro_dlg : todo
 * Copyright (c) : 2004 - 2007 Softwell sas - Milano
 * Written by    : Giovanni Porcari, Francesco Cavazzana
 *                 Saverio Porcari, Francesco Porcari
 *--------------------------------------------------------------------------
 *This library is free software; you can redistribute it and/or
 *modify it under the terms of the GNU Lesser General Public
 *License as published by the Free Software Foundation; either
 *version 2.1 of the License, or (at your option) any later version.

 *This library is distributed in the hope that it will be useful,
 *but WITHOUT ANY WARRANTY; without even the implied warranty of
 *MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *Lesser General Public License for more details.

 *You should have received a copy of the GNU Lesser General Public
 *License along with this library; if not, write to the Free Software
 *Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
 */


//######################## genro  #########################

dojo.declare("gnr.GnrDlgHandler", null, {

    constructor: function(application) {
        this.application = application;
        this.alert_count = 0;
        this._quickDialogDestroyTimeout = 500;
    },
    recordChange: function(record_path, selected_pkey) {
        var pkey_now = genro.getDataNode(record_path).attr.pkey;
        if (pkey_now == selected_pkey) {
            return true;
        } else {
            if (genro.getData(record_path).get_modified()) {
                var todo = request('vuoi salvare?');
                if (todo == 'salva') {
                    salva();
                    return true;
                } else if (todo == 'non salvare') {
                    return true;
                } else {
                    return false;
                }
            }
        }
    },
    dialog:function(msg, cb, buttons) {
        var root = genro.getNode()._('div', '_dlg');
        var dlg = root._('dialog', 'dialogbox', {gnrId:'dialogbox', toggle:"fade", toggleDuration:250});
        dlg._('layoutcontainer', {height:'100%'});
        dlg._('contentpane', {'_class':'dojoDialogInner',layoutAling:'client'})._('span', {content:msg});
        var bottom = dlg._('contentpane', {layoutAling:'bottom'})._('div', {'align':'right'});
        buttons = buttons || [
            {'caption':'OK', result:'OK'},
            {'caption':'cancel', result:'cancel'}
        ];
        for (let btn in buttons) {
            btn.action = function() {
                genro.dialogbox.hide();
                cb(btn.result);
            };
            bottom._('button', btn);
        }
        dlg.show();
    },

    showMenuPane:function(nodeId) {
        //alert(nodeId);
        var root = genro.nodeById(nodeId);
        root.freeze();
        root._('contentPane', {'_class':'menucontainer','background_color':'red',
            'height':'3em',margin_left:'1em',margin_right:'1em',layoutAlign:'top'});
        /*var menunodes = genro.getData('gnr.pagemenu').getNodes();
         for (var i=0; i < menunodes.length; i++) {
         var title = menunodes[i].attr.title;
         var url = menunodes[i].attr.url;
         mc._('a',{content:title,href:url,margin:'1em'});
         };*/
        dojo.fx.wipeIn({node:root.getDomNode(),duration:1000}).play();

    },
    connectTooltipDialog:function(wdg, btnId) {
        dojo.connect(wdg, 'onclick', function(e) {
            genro.wdgById(btnId)._openDropDown(e.target);
        });
    },
    /*experimental*/
    genericWipePane:function(nodeId, msgpth, over) {
        var nodeId = nodeId || 'standardmsgpane';
        var msgpth = msgpth || 'gnr.message';
        var msg = genro.getData(msgpth);
        var root = genro.nodeById(nodeId);

        root.clearValue().freeze();
        if (over == true) {
            root.attr['z_index'] = 999;
            root.attr['position'] = 'absolute';

        }
        ;
        var mc = root._('div', {'background_color':'silver',
            'height':'3em',width:'400px'
        });
        mc._('span', {content:msg});
        var cb = function  (argument) {
            dojo.fx.wipeOut({node:root.getDomNode(),duration:1000}).play();
        };
        mc._('button', {label:'close',onClick:cb});
        root.unfreeze();
        dojo.fx.wipeIn({node:root.getDomNode(),duration:1000}).play();

    },

    createStandardMsg: function(domnode) {
        dojo.require("dojox.widget.Toaster");
        var toaster = new dojox.widget.Toaster({positionDirection:"tl-down",
            duration:1000,
            separator:'<hr>',
            messageTopic:'standardMsg'
        });
        dojo.connect(toaster, 'setContent', this, 'onMsgShow');
        domnode.appendChild(toaster.domNode);
        this.messanger = toaster;
    },

    onMsgShow: function() {
        if (this.messanger.forcedPos) {
            dijit.placeOnScreenAroundElement(genro.dlg.messanger.domNode, this.messanger.forcedPos, {'TL': 'BL', 'BL': 'TL'});
        }
    },

    removeFloatingMessage:function(sourceNode){
        sourceNode._value.popNode('_floatingmess');
    },

    makeFloatingMessage:function(sourceNode,kw){
        console.warn('Use floatingMessage instead of makeFloatingMessage');
        this.floatingMessage(sourceNode,kw);
    },

    floatingMessage:function(sourceNode,kw){
        kw = objectUpdate({},kw);
        var yRatio = objectPop(kw,'yRatio');
        var xRatio = objectPop(kw,'xRatio');
        var duration = objectPop(kw,'duration') || 2;
        var duration_in = objectPop(kw,'duration_in') || duration;
        var duration_out = objectPop(kw,'duration_out') || duration;
        var sound = objectPop(kw,'sound');
        var message = objectPop(kw,'message');
        var msgType = objectPop(kw,'messageType') || 'message';
        var onClosedCb = objectPop(kw,'onClosedCb');
        if(onClosedCb){
            onClosedCb = funcCreate(onClosedCb,null,sourceNode);
        }
        var slideDown = objectPop(kw,'slideDown');
        var fmClass = 'fm_box fm_'+msgType + (slideDown ? ' fm_slidedown' : '');
        var messageBox = sourceNode._('div','_floatingmess',{
            _class: fmClass,
            style: slideDown ? '' : 'opacity:0; transform:scale(0.9); transition:opacity '+duration_in+'s, transform '+duration_in+'s;'
        }).getParentNode();
        kw.innerHTML = _T(message);
        messageBox._('div',{_class:'fm_content'})._('div',kw);
        var that = sourceNode;
        var deleteCb = function(){
            that._value.popNode('_floatingmess');
            if(onClosedCb){
                onClosedCb();
            }
        };
        messageBox._('div',{_class:'fm_closebtn',connect_onclick:deleteCb});
        if(!slideDown){
            genro.dom.centerOn(messageBox,sourceNode,xRatio,yRatio);
        }
        if(sound){
            genro.playSound(sound);
        }
        setTimeout(function(){
            var domNode = messageBox.getDomNode ? messageBox.getDomNode() : messageBox.domNode;
            if(!domNode){ return; }
            if(slideDown){
                domNode.classList.add('fm_visible');
                if(duration_out > 0){
                    setTimeout(function(){
                        domNode.classList.remove('fm_visible');
                        domNode.classList.add('fm_hiding');
                        setTimeout(deleteCb, 400);
                    }, (duration_in + duration_out) * 1000);
                }
            }else{
                domNode.style.opacity = '1';
                domNode.style.transform = 'scale(1)';
                if(duration_out > 0){
                    setTimeout(function(){
                        if(domNode){
                            domNode.style.opacity = '0';
                            domNode.style.transform = 'scale(0.9)';
                        }
                        setTimeout(deleteCb, duration_out * 500);
                    }, (duration_in + duration_out / 2) * 1000);
                }
            }
        }, 16)

    },
    iframeDialog:function(iframeId,kw){
        var dialogId = iframeId+'_dlg';
        var dlgNode = genro.nodeById(dialogId);
        var openKw = kw.openKw;
        if(!dlgNode){
            var root = genro.src.getNode()._('div', '_dlg_iframe');
            var parentRatio = objectPop(kw,'parentRatio');
            var windowRatio = objectPop(kw,'windowRatio');
            var fullScreen = objectPop(kw,'fullScreen');
            var dlgKw = {title:kw.title,closable:kw.closable,nodeId:dialogId,
                parentRatio:parentRatio,windowRatio:windowRatio,fullScreen:fullScreen};
            objectUpdate(dlgKw,objectExtract(kw,'dlg_*'));
            var dlg = root._('dialog',dlgKw);
            var iframekw = {src:kw.src,border:0,height:'100%',width:'100%',nodeId:iframeId};
            objectUpdate(iframekw,objectExtract(kw,'iframe_*'));
            iframekw.selfsubscribe_close = "this.dialog.hide();";
            var onIframeStarted = objectPop(kw,'onIframeStarted');
            if(onIframeStarted || openKw){
                iframekw.onStarted = function(){
                    if(onIframeStarted){
                        onIframeStarted(this,genro.wdgById(dialogId));
                    }
                    if(openKw){
                        this.domNode.gnr.postMessage(this,openKw);
                    }
                };
            }
            objectUpdate(iframekw,objectExtract(kw,'selfsubscribe_*',true,true));
            var iframe;
            if(!(parentRatio || windowRatio)){
                iframe = dlg._('div',{height:kw.height,width:kw.width,overflow:'hidden'})._('iframe','iframe',iframekw);
            }else{
                iframe = dlg._('borderContainer')._('ContentPane',{'region':'center',overflow:'hidden'})._('iframe','iframe',iframekw);
            }
            dlgNode = dlg.getParentNode();
            dlgNode._iframeNode = iframe.getParentNode();
            dlgNode._iframeNode.dialog = dlgNode.widget;
            dlgNode.widget.show();
            //create dlg and iframe
        }else{
            dlgNode.widget.show();
            if(openKw){
                dlgNode._iframeNode.domNode.gnr.postMessage(dlgNode._iframeNode,openKw);
            }
        }
        return dlgNode;
    },

    thIframeDialog:function(kw,openKw){
        kw.src = this._prepareThIframeUrl(kw); 
        if(openKw.pkey){
            openKw.topic = 'main_form_open';
            kw.main_call = 'main_form';
        }
        var iframeId = kw.nodeId || 'th_'+kw.table.replace('.','_')+(kw.formResource || '')+(kw.main_call  || '');
        openKw = openKw || {};
        var onSavedCb = objectPop(kw,'onSavedCb');
        kw.closable = kw.closable===false?false:true;
        kw.openKw = openKw;
        var fixedTitle = objectPop(kw,'fixedTitle');
        kw.onIframeStarted = function(iframeNode,wdg){
            if(iframeNode._genro._rootForm){
                if(kw.main_call=='main_form'){
                    iframeNode._genro._rootForm.subscribe('onDismissed',function(){wdg.hide();});
                }
                if(!fixedTitle){
                    iframeNode._genro._rootForm.subscribe('onChangedTitle',function(kw){wdg.setTitle(kw.title);});
                }
            }else if(kw.lookup){
                iframeNode._genro.nodeById('lookup_root').subscribe('lookup_cancel',function(){wdg.hide();});
            }
            if(onSavedCb){
                iframeNode._genro._rootForm.subscribe('onSaved',function(kw){
                    onSavedCb(kw);
                });
            }
        };
        this.iframeDialog(iframeId,kw);
    },

    lightboxDialog:function(kwOrCb,onClosedCb){        
        genro.src.getNode()._('div', '_dlg_lightbox');
        var node = genro.src.getNode('_dlg_lightbox').clearValue().freeze();
        onClosedCb = onClosedCb?funcCreate(onClosedCb):null;
        var dlg = node._('dialog',{_class:'lightboxDialog',nodeId:'_dlg_lightbox',connect_hide:function(){
            if(onClosedCb){
                onClosedCb.call(this);
            }
            genro.src.getNode('_dlg_lightbox').clearValue();
        }});
        var closecb = function(){
            if(genro.wdgById("_dlg_lightbox")){
                genro.wdgById("_dlg_lightbox").hide();
            }
        };
        dlg._('div',{_class:'dlg_closebtn',connect_onclick:closecb,top:'-20px',right:'-20px'});
        if(typeof(kwOrCb)=='function'){
            kwOrCb(dlg,closecb);
        }else{
            dlg._(objectPop(kwOrCb,'tag'),kwOrCb);
        }
        node.unfreeze();
        genro.wdgById('_dlg_lightbox').show();
    },

    lightboxVideo:function(url,kw){
        this.lightboxDialog(function(dlg){
            kw = kw || {};
            var caption = objectPop(kw,'caption');
            
            var box = dlg._('div',{padding:'10px',background:'white',rounded:6});
            if(caption){
                dlg._('div',{innerHTML:caption,text_align:'center',color:'#999',font_weight:'bold'});
            }
            box._('htmliframe',objectUpdate({src:url,height:'500px',width:'600px',border:'0',nodeId:'_videoiframe_'},kw))
        },function(){
            genro.domById('_videoiframe_').setAttribute('src','');
        });
    },     


    alert:function(msg, title, buttons, resultPath, kw) {
        var root = genro.src.getNode();
        if(!root){
            //
            genro.bp(true);
            alert(msg);
            return;
        }
        var alertCode = '_dlg_alert_'+this.alert_count;
        root._('div', alertCode);
        title = title || '';
        buttons = buttons || {confirm:'OK'};
        //var kw = objectUpdate({'width':'20em'}, kw);
        kw = kw || {};
        var confirmCb = objectPop(kw,'confirmCb');
        var that = this;
        var node = genro.src.getNode(alertCode).clearValue().freeze();
        var dlg = node._('dialog', objectUpdate({nodeId:alertCode, title:title, _class:'dlg_alert',
                                                connect_show:function(){
                                                    that.alert_count+=1;
                                                },connect_hide:function(){
                                                    that.alert_count-=1;
                                                },
                                                toggle:"fade", toggleDuration:250},kw))._('div', {_class:'dlg_ask',
            action:function(){
                genro.wdgById(alertCode).hide();
                if(resultPath){
                    genro.fireEvent(resultPath,this.attr.actCode);
                }
                if(confirmCb){
                    funcApply(confirmCb);
                }
            }

        });
        dlg._('div', {'innerHTML':msg,'_class':'selectable dlg_ask_msg'});
        var btnBox = dlg._('div', {'_class':'dialog_bottom dlg_ask_btnBox'});
        for (var btn in buttons) {
            btnBox._('button', {'_class':'dlg_ask_btn','label':buttons[btn],'actCode':btn});
        }
        node.unfreeze();
        genro.wdgById(alertCode).show();
    },

    serverMessage: function(msgpath) {
        var msgnode = genro.getDataNode(msgpath);
        var msgtext = msgnode.getValue();
        var msgattr = msgnode.attr;
        //genro._data.setItem(msgpath, null, null, {'doTrigger':false});
        genro.src.getNode()._('div', '_dlg_alert');
        var node = genro.src.getNode('_dlg_alert').clearValue().freeze();
        var title = msgattr['title'] || 'Message from ' + msgattr['from_user'];
        genro.dlg.alert(msgtext,title)
    },

    ask: function(title, msg, buttons, resultPathOrActions,kw) {
        var alertCode = '_dlg_ask_'+this.alert_count;

        genro.src.getNode()._('div', alertCode);
        kw = kw || {};
        let closable = objectPop(kw,'closable');
        buttons = buttons || {confirm:_T('Confirm'),cancel:_T('Cancel')};
        var action,actions;
        var that = this;
        var node = genro.src.getNode(alertCode).clearValue().freeze();
        if (typeof(resultPathOrActions) == 'string') {
            var resultPath = resultPathOrActions;
            actions = {};
            action = "genro.wdgById('"+alertCode+"').hide();genro.fireEvent('" + resultPath + "',this.attr.actCode);";
        }
        else {
            actions = resultPathOrActions || {};
            action = "genro.wdgById('"+alertCode+"').hide();if (this.attr.act){funcCreate(this.attr.act).call();};";
        }
        var dlg = node._('dialog', {nodeId:alertCode,title:title,_class:'dlg_alert',closable:closable,
                                    connect_show:function(){
                                        that.alert_count+=1;
                                    },connect_hide:function(){
                                        that.alert_count-=1;
                                    },centerOn:'_pageRoot'})._('div', {_class:'dlg_ask','action':action});
        dlg._('div', {'content':_T(msg),'_class':'selectable dlg_ask_msg',width:kw.width});
        var btnBox = dlg._('div', {'_class':'dialog_bottom dlg_ask_btnBox'});
        objectKeys(buttons).forEach(function(btn){
            btnBox._('button', {'_class':'dlg_ask_btn','label':buttons[btn],'actCode':btn,'act':actions[btn]});
        });
        node.unfreeze();
        genro.wdgById(alertCode).show();
    },

    batchMonitor:function(thermopath) {
        thermopath = thermopath || '_thermo';
        genro.src.getNode()._('div', '_thermo_floating');
        var node = genro.src.getNode('_thermo_floating').clearValue().freeze();
        var floatingPars = {};
        floatingPars.title = 'public floating';
        floatingPars._class = 'shadow_4';
        floatingPars.nodeId = 'batchMonitor';
        floatingPars.datapath = thermopath;
        floatingPars.top = '80px';
        floatingPars.left = '20px';
        floatingPars.width = '400px';
        floatingPars.closable = true;
        floatingPars.resizable = true;
        floatingPars.dockable = false;
        floatingPars.resizeAxis = 'y';
        floatingPars.maxable = false;
        floatingPars.duration = 400;
        var floating = node._('floatingPane', floatingPars);
        var container = floating._('div', {datapath:'.data','margin_bottom':'12px'});
        var create_thermoline = function(node, kw, i) {
            var innerpane = kw.pane._('div', {datapath:'.' + node.label});
            innerpane._('div', {innerHTML:'^.?message',font_size:'8px',text_align:'center',color:'black'});
            innerpane._('progressBar', {progress:'^.?progress',maximum:'^.?maximum',indeterminate:'^.?indeterminate',
                places:'^.?places',width:'100%',height:'10px',font_size:'9px'});

        };
        var create_thermopane = function(node, kw, i) {
            var innerpane = kw.pane._('div', {_class:'thermopane',border:'1px solid gray',
                margin:'2px',datapath:'.' + node.label});
            var titlediv = innerpane._('div', {background:'gray',color:'white',font_size:'9px',padding:'2px',height:'8px'});
            titlediv._('div', {innerHTML:'^.?thermotitle','float':'left'});
            titlediv._('a', {innerHTML:'Stop','float':'right'});
            var pane = innerpane._('div', {datapath:'.lines',padding:'3px'});
            var lines = node.getValue().getItem('lines');
            if (lines) {
                lines.forEach(create_thermoline, null, {'pane':pane});
            }
        };
        var thermobag = genro._(thermopath + '.data');
        thermobag.forEach(create_thermopane, null, {'pane':container});
        node.unfreeze();
        var bm = genro.wdgById('batchMonitor');
        dojo.connect(bm, 'close', function() {
            genro.setData('_thermo.monitor', false);
        });
        genro.setData('_thermo.monitor', true);
    },

    message: function(msg, position, level, duration) {
        var level = level || 'message';
        var duration = duration || 4000;
        if(genro.toast){
            genro.toast.show({message: msg, level: level, duration: duration});
        }else{
            this.messanger.forcedPos = position;
            if(level=='error'){
                if(!dojo.query('.countBoxErrors').length){
                    return;
                }
            }
            dojo.publish("standardMsg", [
                {message: msg, type: level, duration: duration}
            ]);
        }
    },
    


    _resolveDialogRoot:function(rootNode, label){
        if(!rootNode){
            genro.src.getNode()._('div',label);
            return genro.src.getNode();
        }
        const skipTags = new Set(['dataformula', 'datascript', 'datacontroller',
                                'datarpc', 'button', 'slotbutton', 'lightbutton']);
        let roottag = rootNode.attr.tag.toLowerCase();
        while(skipTags.has(roottag)){
            rootNode = rootNode.getParentNode();
            roottag = rootNode.attr.tag.toLowerCase();
        }
        rootNode._('div',label,{_attachTo:'mainWindow',parentForm:false});
        return rootNode;
    },

    _groupletForm:function(name, kw,rootNode){
        kw = kw || {};
        let dlgKw = objectExtract(kw,'dialog_*');
        objectUpdate(dlgKw,objectExtract(kw,'title,closable,animateResize'));
        const dlgId = 'grouplet_dlg_' + name;
        const formId = 'grouplet_form_' + name;
        const pkey = objectPop(kw,'pkey');
        const table = kw.table;
        kw.formId = formId;
        kw.form_modalForm = true;
        dlgKw.nodeId = dlgId;
        // Check if dialog already exists to reuse it
        let dlgNode = genro.nodeById(dlgKw.nodeId);

        if(!dlgNode){
            if(table && pkey){
                kw.store_handler = kw.store_handler || 'record';
            }
            // Configure dialog defaults
            dlgKw.autoSize = false;
            dlgKw.closable = dlgKw.closable !== undefined ? dlgKw.closable : true;
            dlgKw.animateResize = dlgKw.animateResize !== undefined ? dlgKw.animateResize : true;
            rootNode = this._resolveDialogRoot(rootNode, 'root_'+dlgId);
            const node = rootNode.getValue().getNode('root_'+dlgId).clearValue();
            const dlg = node._('dialog', dlgId,dlgKw);
            const loadChunk = pkey ? `genro.formById("${formId}").goToRecord("${pkey}")` : `genro.formById("${formId}").load()`;
            kw.grouplet__onRemote = `setTimeout(() => {genro.nodeById('${dlgId}').widget.adjustDialogSize();${loadChunk};}, 1);`;
            const onSavedCb = objectPop(kw,'onSavedCb');
            const confirmLabel = objectPop(kw, 'confirmLabel') || _T('Confirm');
            const cancelLabel = objectPop(kw, 'cancelLabel') || _T('Cancel');
            dlg._('GroupletForm', kw);
            const hideDlg = function(){ genro.nodeById(dlgId).widget.hide(); };
            genro.formById(formId).subscribe('onSaved',function(kw){
                if(onSavedCb){ onSavedCb(kw); }
                hideDlg();
            });
            genro.formById(formId).subscribe('onDismissed',hideDlg);
            const bottom = dlg._('flexbox', {_class:'dialog_bottom',flex_direction:'row-reverse',padding_bottom:'5px'});
            bottom._('Button', {'label':confirmLabel, action:function(){
                genro.formById(formId).save();
            }});
            bottom._('Button', {'label':cancelLabel, action:function(){
                genro.formById(formId).abort();
            }});
            dlgNode = dlg.getParentNode();
            dlgNode.widget.show();
        }else{
            
            dlgNode.widget.show();
            genro.formById(formId).load(pkey ? {destPkey:pkey} : null);
        }
    },
    



    memoryDataEditor:function(name, kw,sourceNode){
        kw = kw || {};
        // memory + SubForm are GroupletForm defaults:
        // load_memory copies fields from parent form, save_memory writes them back
        this._groupletForm(name, kw,sourceNode);
    },

    documentDataEditor:function(name, kw,sourceNode){
        kw = kw || {};
        kw.pkey = objectPop(kw, 'path') || kw.pkey;
        kw.store_handler = 'document';
        kw.storeType = 'Item';
        this._groupletForm(name, kw,sourceNode);
    },

    recordDataEditor:function(name, kw, sourceNode){
        kw = kw || {};
        kw.store_handler = 'record';
        kw.storeType = 'Item';
        this._groupletForm(name, kw,sourceNode);
    },

    // Creates and shows a dialog with remote content
    // - name: unique identifier for the dialog
    // - remote: the remote method to call for content
    // - remoteKw: parameters passed to the remote call (prefixed with 'remote_')
    // - dlgKw: dialog widget configuration options
    remoteDialog:function(name, remote, remoteKw, dlgKw,remoteRootCb){
        remoteKw = remoteKw || {};
        dlgKw = dlgKw || {};
        dlgKw.nodeId = 'remote_dlg_' + name;

        // Check if dialog already exists to reuse it
        let dlgNode = genro.nodeById(dlgKw.nodeId);

        if(!dlgNode){
            // Configure dialog defaults
            dlgKw.autoSize = false;
            dlgKw.closable = dlgKw.closable !== undefined ? dlgKw.closable : true;

            const dlg = genro.src.create('dialog', dlgKw, '_rmt_dlg');

            // Build remote call parameters with 'remote_' prefix
            let kw = {remote: remote};
            for(const k in remoteKw){
                kw['remote_' + k] = remoteKw[k];
            }

            // Adjust dialog size after remote content loads
            kw.remote__onRemote = function(){
                setTimeout(() => dlgNode.widget.adjustDialogSize(), 1);
            };
            remoteRootCb = remoteRootCb || function(dlg, content_remotekw){
                content_remotekw.min_height = '1px';
                content_remotekw.min_width = '1px';
                dlg._('div', content_remotekw);
            };
            remoteRootCb(dlg,kw);
            dlgNode = dlg.getParentNode();
        }

        dlgNode.widget.show();
    },
    
    askParameters:function(cb,ask_params,parameters,sourceNode,argnames,argvalues){
        var promptkw = objectUpdate({},ask_params);
        let doAsk = true;
        if(ask_params._if){
            doAsk = funcApply('return '+ask_params._if,parameters,sourceNode);
        }
        var default_result = {};
        parameters = objectUpdate({},parameters);
        if(promptkw.fields){
            promptkw.fields = promptkw.fields.map(function(kw){
                kw = objectUpdate({},kw);
                if(kw.dtype && !kw.tag){
                    kw.tag = genro.wdg.wdgByDtype(kw.dtype);
                }
                if(kw['name'] in parameters){
                    kw['default_value'] = parameters[kw['name']];
                    default_result[kw['name']] = parameters[kw['name']];
                }
                if(!('_autoselect' in kw)){
                    kw._autoselect = true;
                }
                kw['value'] = '^.'+kw['name'];
                return kw;
            })
            promptkw.widget = objectPop(promptkw,'fields');
        }
        if(!doAsk){
            if(objectNotEmpty(default_result)){
                parameters._askResult = default_result;
            }
            funcApply(cb, parameters, sourceNode,argnames,argvalues);
            return;
        }
        promptkw.action = function(result){
            if(result && result.len()){
                result = result.asDict();
                objectUpdate(parameters,result);
                parameters._askResult = result;
            }
            funcApply(cb, parameters, sourceNode,argnames,argvalues);
        }
        genro.dlg.prompt(_T(objectPop(promptkw,'title','!!Parameters')),promptkw,sourceNode);
    },

    prompt: function(title, kw,sourceNode) {
        kw = kw || {};
        var dlg_kw = objectExtract(kw,'dlg_*');
        var msg = kw.msg;
        var confirmCb = kw.action || '';
        var cancelCb = kw.cancelCb;
        var wdg = kw.widget || 'textbox';
        var remote = kw.remote;
        var dflt = kw.dflt;
        var cols = objectPop(kw,'cols') || 1;
        var formlet = objectPop(kw,'formlet');
        if(isNullOrBlank(formlet)){
            formlet = genro.startArgs.useFormletsInJsFb;
        }
        genro.dlg.prompt_counter = genro.dlg.prompt_counter || 0;
        genro.dlg.prompt_counter++;
        var prompt_datapath = kw.datapath || 'gnr.promptDlg.prompt_'+genro.dlg.prompt_counter;
        if(sourceNode){
            prompt_datapath = sourceNode.absDatapath(prompt_datapath);
        }
        var promptvalue_path = prompt_datapath+'.promptvalue';
        let nodePromptValue = genro.getDataNode(promptvalue_path);
        let kept_value = nodePromptValue?nodePromptValue.attr.kept_value:null;
        if(kept_value){
            dflt = dflt || new gnr.GnrBag();
            for(let keykept in kept_value){
                let _keep = kept_value[keykept]
                dflt.setItem(keykept,_keep,{'_keep':_keep});
            }
        }
        genro.setData(promptvalue_path,dflt || null);
        dlg_kw = objectUpdate({_showParent:true,width:'280px',datapath:prompt_datapath,_class:'dlg_prompt',autoSize:true},dlg_kw);
        var dlg = genro.dlg.quickDialog(title,dlg_kw,sourceNode);
        if(!sourceNode){
            sourceNode = dlg.getParentNode();
        }
        var mandatory = objectPop(kw,'mandatory');
        var actionCb = function(command){
                        var error_message;
                        command = command || this.attr.command;
                        if(command=='confirm'){
                            var validDojo = true;
                            dlg.center.walk(function(n){
                                if(n.widget && n.widget.isValid && n.widget.isValid()===false){
                                    validDojo = false;
                                }
                            });
                            if(!validDojo){
                                return;
                            }
                            var v = genro.getData(promptvalue_path);                            
                            if(mandatory && isNullOrBlank(v)){
                                return;
                            }
                            error_message = funcApply(confirmCb,{value:genro.getData(promptvalue_path)},(sourceNode||this));
                            if(!error_message){
                                var kept_value = {};
                                if (v instanceof gnr.GnrBag){
                                    for(let n of v.getNodes()){
                                        if(n.attr._keep){
                                            kept_value[n.label] = n.getValue();
                                        }
                                    }
                                }
                                genro.setData(promptvalue_path,null,objectNotEmpty(kept_value)?{kept_value:kept_value}:null,false);
                            }
                        }else if(command == 'cancel' && cancelCb){
                            error_message = funcApply(cancelCb,{},(sourceNode||this));
                        }
                        if(error_message){
                            genro.dlg.floatingMessage(dlg.center.getParentNode(),{message:error_message,messageType:'error'});
                        }
                        else{
                            dlg.close_action();
                            genro.dlg.prompt_counter--;
                            if(!genro.dlg.prompt_counter){
                                setTimeout(function(){
                                    genro._data.popNode('gnr.promptDlg');
                                },genro.dlg._quickDialogDestroyTimeout+1);
                            }
                        }
                    };
        var bar = dlg.bottom._('slotBar',{slots:'*,cancel,confirm',action:actionCb});
        bar._('button','cancel',{'label':_T('Cancel'),command:'cancel'});
        var confirmbtnKW = {'label':_T('Confirm'),command:'confirm'};
        if(mandatory){
            confirmbtnKW.disabled = '^.promptvalue?=(#v==null) || (#v=="")';
        }
        bar._('button','confirm',confirmbtnKW);
        var kwbox = {};
        if(remote){
            kwbox.padding = '10px';
            kwbox.remote = remote;
            objectUpdate(kwbox,objectExtract(kw,'remote_*',false,true));
            kwbox.remote_valuepath = '.promptvalue';
            kwbox.remote__onRemote = function(){
                setTimeout(function(){
                    dlg.getParentNode().widget.adjustDialogSize();
                },1);
            };
            dlg.center._('div',kwbox);
        }else if(typeof(wdg)=='function'){
            kwbox.datapath = '.promptvalue';
            wdg.call(sourceNode,dlg.center._('div',kwbox)); // nn ho un sourcenode
        }else if(wdg=='multiValueEditor'){
            dlg.center._('multiValueEditor',objectUpdate({value:'^.promptvalue',height:'250px',width:'350px'},objectExtract(kw,'wdg_*')));
        }
        else{
            kwbox.padding = formlet? null : '10px';
            kwbox.width = formlet? null : dlg_kw.width;
            var box = dlg.center._('div',kwbox);
            var fb;

            var onEnter ='onEnter' in kw? funcCreate(kw.onEnter,null,sourceNode):null;
            var lblKw = formlet? {} : {lbl_color:'#666',lbl_text_align:'right'};
            if(msg){
                box._('div',{innerHTML:msg,color:'#666',_class:'selectable',
                             margin_bottom:formlet?null:'10px',
                             padding:formlet?'0 var(--formlet-padding)':null});
            }
            if(typeof(wdg)=='string'){
                fb = genro.dev.formbuilder(box,cols,{formlet:formlet,border_spacing:'1px',onEnter:onEnter,width:'100%',fld_width:'100%'});
                fb.addField(wdg,objectUpdate(objectUpdate({value:'^.promptvalue',lbl:kw.lbl},lblKw),objectExtract(kw,'wdg_*')));
            }else{
                fb = genro.dev.formbuilder(box,cols,{formlet:formlet,border_spacing:'4px',width:'100%',onEnter:onEnter,fld_width:'100%',datapath:'.promptvalue'});
                wdg.forEach(function(n){
                    n = objectUpdate({},n);
                    var w = objectPop(n,'wdg','textbox');
                    fb.addField(w,objectUpdate(objectUpdate({},lblKw),n));
                });
            }
        }
        dlg.show_action(function(){
            setTimeout(function(){
                var inputNodes = dojo.query('input',dlg.getParentNode().widget.domNode) || [];
                if(inputNodes.length){
                    inputNodes[0].focus();
                }
            },500);
        });
    },

    paletteMap:function(kw) {
        kw = kw || {};
        kw.paletteCode = kw.paletteCode || 'mapViewer';
        var paletteWdg = genro.wdgById(kw.paletteCode+'_floating');
        if(!paletteWdg){
            var node = objectPop(kw,'sourceNode');
            if(!node){
                genro.src.getNode()._('div', '_map_palette');
                node = genro.src.getNode('_map_palette').clearValue();     
            }
            node.freeze();
            kw.dockTo = kw.dockTo || 'dummyDock:open';
            var paletteNode = node._('PaletteMap',kw).getParentNode();
            node.unfreeze();
            paletteWdg = paletteNode.getWidget();
        }else{
            paletteWdg.show();
        }
    },
    
    request: function(title, msg, buttons, resultPath, valuePath) {
        genro.src.getNode()._('div', '_dlg_request');
        var buttons = buttons || {confirm:_T('Confirm'),cancel:_T('Cancel')};
        var node = genro.src.getNode('_dlg_request').clearValue().freeze();
        var dlg = node._('dialog', {nodeId:'_dlg_request',title:title})._('div', {_class:'dlg_ask',
            'action':"genro.wdgById('_dlg_request').hide();genro.setData('" + resultPath + "',this.attr.actCode);"});
        dlg._('div', {'content':msg,'_class':'selectable dlg_ask_msg'});
        dlg._('textBox', {'value':'^' + valuePath});
        var btnBox = dlg._('div', {'_class':'dialog_bottom dlg_ask_btnBox'});
        for (var btn in buttons) {
            btnBox._('button', {'_class':'dlg_ask_btn','label':buttons[btn],'actCode':btn});
        }
        node.unfreeze();
        genro.wdgById('_dlg_request').show();
    },
    floating: function(kw) {
        var float_id = kw.nodeId;
        genro.src.getNode()._('div', '_gnr_float_' + float_id);
        var node = genro.src.getNode('_gnr_float_' + float_id).clearValue();
        return node._('floatingPane', kw);
    },

    quickTooltipPane: function(kw,contentCb,contentCbKw) {
        kw = objectUpdate({},kw);
        kw.evt = kw.evt || false;
        var nodeId = kw.nodeId  || 'td_'+'tempTooltip';
        var quickRoot = '_dlgTooltip_quick_'+ nodeId;
        genro.src.getNode()._('div',quickRoot);
        var node = genro.src.getNode(quickRoot).clearValue();
        var domNode = objectPop(kw,'domNode');
        var openerId = kw.openerId || nodeId+'_opener';
        kw.openerId = openerId;
        node.freeze();
        if(domNode){
            
            kw.onCreated = function(){
                setTimeout(function(){
                    genro.publish(openerId+'_open',{domNode:domNode});
                },1);
            };
        }
        var fields = objectPop(kw,'fields');
        var cols = objectPop(kw,'cols',1);
        var formlet = objectPop(kw,'formlet');

        var tp = node._('tooltipPane',kw);
        if(fields){
            if(fields instanceof Array){
                tp = tp._('div',{_class:'quickTooltipContainer'});
                var fb = genro.dev.formbuilder(tp,cols,{formlet:formlet,border_spacing:'4px',width:'100%',fld_width:'100%'});
                fields.forEach(function(n){
                    n = objectUpdate({},n);
                    var w = objectPop(n,'wdg','textbox');
                    fb.addField(w,objectUpdate({},n));
                });
            }
        }else if(contentCb){
            contentCbKw = contentCbKw || {};
            contentCbKw.tooltipOpenerId = openerId;
            contentCb(tp,contentCbKw);
        }
        node.unfreeze();
        return tp;
    },

    docUrl: function(address, kw) {
        // the page of a doc address (sys/ep_doc), asked by this page
        return genro.addParamsToUrl('/sys/ep_doc', objectUpdate({address: address,
            language: genro.getData('gnr.language'), _calling_page_id: genro.page_id}, kw || {}));
    },

    docAssetUrl: function(address, name) {
        return this.docUrl(address) + '&asset=' + (name || '');
    },

    _docPost: function(params) {
        const body = new URLSearchParams(objectUpdate({language: genro.getData('gnr.language'),
                                                       _calling_page_id: genro.page_id}, params));
        return fetch('/sys/ep_doc', {method: 'POST', body: body, credentials: 'same-origin'});
    },

    docTrack: function(domNode, address) {
        // an icon of a doc address: shown when the doc exists, and red where it
        // is empty to a documenter in documentation mode. The addresses of the
        // page go to sys/ep_doc in one request
        domNode.setAttribute('data-doc-address', address);
        domNode.classList.add('doc_icon');
        const states = this._docStates = this._docStates || {};
        if (address in states) {
            this.docApplyState(domNode);
            return;
        }
        states[address] = null;
        (this._docPending = this._docPending || new Set()).add(address);
        if (!this._docPendingTimer) {
            this._docPendingTimer = setTimeout(() => this._docIndex(), 0);
        }
    },

    _docIndex: function() {
        const addresses = [...this._docPending];
        this._docPending = new Set();
        this._docPendingTimer = null;
        return this._docPost({_index: 1, addresses: addresses.join(',')})
            .then((response) => response.ok ? response.json() : null)
            .catch(() => null)
            .then((result) => {
                result = result || {docs: {}, editable: []};
                addresses.forEach((address) => {
                    this._docStates[address] = {exists: address in result.docs,
                                                editable: result.editable.indexOf(address) >= 0,
                                                manual: (result.manual || []).indexOf(address) >= 0};
                });
                this.docApplyStates();
            });
    },

    docApplyStates: function() {
        document.querySelectorAll('[data-doc-address]').forEach((domNode) => this.docApplyState(domNode));
    },

    docApplyState: function(domNode) {
        const state = (this._docStates || {})[domNode.getAttribute('data-doc-address')] || {};
        const docMode = !!genro.getData('gnr.docModeVisible');
        const documented = !!state.exists || !!state.manual;
        domNode.classList.toggle('doc_icon--shown', documented || (!!state.editable && docMode));
        domNode.classList.toggle('doc_icon--empty', !documented);
    },

    docSource: function(address, cb) {
        // {exists, editable, title, html, markdown, language, mtime, manual} of a
        // doc address, fetched once per page; null when it is not for this user
        const sources = this._docSources = this._docSources || {};
        if (!(address in sources)) {
            sources[address] = fetch(this.docUrl(address, {_fragment: 1}), {credentials: 'same-origin'})
                .then((response) => response.ok ? response.json() : null)
                .catch(() => null);
        }
        return sources[address].then(cb);
    },

    helpPanel: function(address, kw, source) {
        // the help of an address, on the right of the page (a help panel): the
        // manual's section with a link to it, then the customer's note, with
        // Edit for a documenter. One panel per page, its topic changes on the
        // next click; the close button or Esc closes it. Its left edge drags
        // its width, kept in the browser; ⤢ widens it
        this._helpPanelArgs = [address, kw || {}, source || {}];
        this._helpPanelManualUrl = null;
        this._renderHelpPanel();
    },

    showManual: function(address, kw, source, url) {
        // the manual's page in the help panel, widened: the page is never left,
        // whatever the browser makes of a new window
        this._helpPanelArgs = [address, kw || {}, source || {}];
        this._helpPanelManualUrl = url;
        this._helpPanelWide = true;
        this._renderHelpPanel();
    },

    _renderHelpPanel: function() {
        const [address, kw, source] = this._helpPanelArgs;
        const manualUrl = this._helpPanelManualUrl;
        const width = this._helpPanelWidth || this._storedHelpPanelWidth();
        genro.src.getNode()._('div', '_doc_help_panel_');
        const node = genro.src.getNode('_doc_help_panel_').clearValue();
        node.freeze();
        const panel = node._('div', {_class: 'doc_help_panel' + (this._helpPanelWide ? ' doc_help_panel--wide' : ''),
                                     width: !this._helpPanelWide && width ? width + 'px' : null,
                                     role: 'complementary', 'aria_label': _T('!!Help')});
        panel._('div', {_class: 'doc_help_panel_resize', title: _T('!!Drag to resize'),
                        connect_onpointerdown: (e) => this._resizeHelpPanel(e)});
        const head = panel._('div', {_class: 'doc_help_panel_head'});
        if (manualUrl) {
            head._('div', {_class: 'doc_help_panel_tool', innerHTML: '&#8592; ' + _T('!!Help'),
                           title: _T('!!Back to the help'), connect_onclick: () => {
                               this._helpPanelManualUrl = null;
                               this._renderHelpPanel();
                           }});
        }
        head._('div', {_class: 'doc_help_panel_title', innerHTML: this._docHelpTitle(kw, source)});
        if (manualUrl) {
            head._('a', {_class: 'doc_help_panel_tool', href: manualUrl, target: '_blank', rel: 'noopener',
                         innerHTML: '&#8599;', title: _T('!!Open in a new window')});
        }
        head._('div', {_class: 'doc_help_panel_tool', innerHTML: this._helpPanelWide ? '&#8690;' : '&#10530;',
                       title: this._helpPanelWide ? _T('!!Narrow') : _T('!!Widen'), connect_onclick: () => {
                           this._helpPanelWide = !this._helpPanelWide;
                           this._renderHelpPanel();
                       }});
        head._('div', {_class: 'doc_help_panel_close', innerHTML: '&times;', title: _T('!!Close'),
                       connect_onclick: () => this.closeHelpPanel()});
        if (manualUrl) {
            // no same-origin and no top navigation: the manual can neither
            // reach this page nor replace it; externalSite keeps the page id
            // off its url, where it would also break the section's anchor
            panel._('iframe', {_class: 'doc_help_panel_frame', src: manualUrl, externalSite: true,
                               sandbox: 'allow-scripts allow-popups allow-popups-to-escape-sandbox'});
        } else {
            this._docHelpBody(panel._('div', {_class: 'doc_help_panel_body'}), address, kw, source);
        }
        node.unfreeze();
        this._helpPanelAddress = address;
        if (this._helpEscape) return;
        // Esc closes the panel and nothing else: a dialog above the page (the
        // note's editor among them) keeps its own Esc
        this._helpEscape = (e) => {
            if (e.key !== 'Escape' || (e.target && e.target.closest && e.target.closest('.dijitDialog'))) return;
            e.stopPropagation();
            e.preventDefault();
            this.closeHelpPanel();
        };
        document.addEventListener('keydown', this._helpEscape, true);
    },

    _resizeHelpPanel: function(e) {
        const panel = e.currentTarget.parentNode;
        const handle = e.currentTarget;
        e.preventDefault();
        handle.setPointerCapture(e.pointerId);
        panel.classList.add('doc_help_panel--resizing');
        const move = (evt) => {
            const width = Math.round(Math.min(Math.max(window.innerWidth - evt.clientX, 320), window.innerWidth * 0.9));
            panel.classList.remove('doc_help_panel--wide');
            panel.style.width = width + 'px';
            this._helpPanelWide = false;
            this._helpPanelWidth = width;
        };
        const up = () => {
            handle.removeEventListener('pointermove', move);
            handle.removeEventListener('pointerup', up);
            panel.classList.remove('doc_help_panel--resizing');
            try {
                genro.setInStorage('local', 'docHelpPanelWidth', this._helpPanelWidth);
            } catch (error) {
                // a browser with no storage keeps the width for this page only
            }
        };
        handle.addEventListener('pointermove', move);
        handle.addEventListener('pointerup', up);
    },

    _storedHelpPanelWidth: function() {
        try {
            return genro.getFromStorage('local', 'docHelpPanelWidth') || null;
        } catch (error) {
            return null;
        }
    },

    helpTooltip: function(domNode, address, kw, source) {
        // the help of an address in a popup at its icon, for a field or a part
        // of a page: what the help panel shows. One popup for the page, moved to
        // the icon clicked; a click outside or Esc closes it
        kw = kw || {};
        source = source || {};
        this.quickTooltipPane({nodeId: 'doc_help_tooltip', domNode: domNode, _class: 'doc_help_tooltip'}, (pane) => {
            const box = pane._('div', {_class: 'doc_help_tooltip_box'});
            box._('div', {_class: 'doc_help_tooltip_title', innerHTML: this._docHelpTitle(kw, source)});
            this._docHelpBody(box._('div', {_class: 'doc_help_tooltip_body'}), address, kw, source);
        });
        if (this._tooltipEscape) return;
        // the focus is in the popup: Esc is heard on the document while it is open
        this._tooltipEscape = (e) => {
            if (e.key !== 'Escape') return;
            this.closeHelpTooltip();
        };
        document.addEventListener('keydown', this._tooltipEscape, true);
    },

    closeHelpTooltip: function() {
        if (!this._tooltipEscape) return;
        document.removeEventListener('keydown', this._tooltipEscape, true);
        this._tooltipEscape = null;
        genro.publish('doc_help_tooltip_opener_close');
    },

    _docHelpTitle: function(kw, source) {
        return this._docTitleHtml(kw, {title: (source.manual && source.manual.title) || source.title});
    },

    _docHelpBody: function(body, address, kw, source) {
        // the manual's section with a link to it, then the customer's note, with
        // Edit for a documenter: the content of the help panel and of the popup
        const manual = source.manual;
        // the server sends only http(s) urls under the manual's site: a url of any
        // other shape is not followed
        const manualUrl = manual && /^(https?:\/\/|\/(?!\/))/i.test(manual.url || '') ? manual.url : null;
        if (manual) {
            body._('div', {_class: 'doc_help_manual', innerHTML: manual.html});
        }
        if (manualUrl) {
            // the manual's page in the help panel: the page stays where it is
            body._('a', {_class: 'doc_help_link', href: manualUrl, target: '_blank', rel: 'noopener',
                         innerHTML: _T('!!Open in the manual') + ' &#8599;',
                         connect_onclick: (e) => {
                             e.preventDefault();
                             this.closeHelpTooltip();
                             this.showManual(address, kw, source, manualUrl);
                         }});
        }
        if (source.exists) {
            const note = body._('div', {_class: 'doc_help_note'});
            if (manual) note._('div', {_class: 'doc_help_note_title', innerHTML: _T('!!Notes')});
            note._('div', {_class: 'doc_help_note_body',
                           innerHTML: kw.fill ? kw.fill(source.html) : source.html});
        } else if (!manual) {
            body._('div', {_class: 'doc_help_empty', innerHTML: _T('!!No documentation available')});
        }
        if (source.editable) {
            body._('a', {_class: 'doc_help_edit', href: '#',
                         innerHTML: source.exists ? _T('!!Edit the note') : _T('!!Add a note'),
                         connect_onclick: (e) => {
                             e.preventDefault();
                             this.closeHelpTooltip();
                             this.docEdit(address, kw, source);
                         }});
        }
    },

    closeHelpPanel: function() {
        const node = genro.src.getNode('_doc_help_panel_');
        if (node) node.clearValue();
        this._helpPanelAddress = null;
        this._helpPanelManualUrl = null;
        if (this._helpEscape) {
            document.removeEventListener('keydown', this._helpEscape, true);
            this._helpEscape = null;
        }
    },

    _docTitleHtml: function(kw, source) {
        // kw.title is the caller's markup (a label, a card title); the doc's
        // own title is text a documenter wrote, never markup
        if (kw.title) return kw.title;
        return String((source && source.title) || '').replace(/&/g, '&amp;').replace(/</g, '&lt;')
            .replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    },

    openDoc: function(domNode, address, kw) {
        // the "?" of an address. kw: title, fill (a note's html filled with the
        // caller's data), placeholders (the variables the editor offers),
        // tooltip (a popup at the icon instead of the help panel). An address
        // with neither manual nor note opens the editor to a documenter
        kw = kw || {};
        return this.docSource(address, (source) => {
            if (source && !source.exists && !source.manual && source.editable) {
                this.docEdit(address, kw, source);
                return;
            }
            if (kw.tooltip) {
                this.helpTooltip(domNode, address, kw, source);
                return;
            }
            this.helpPanel(address, kw, source);
        });
    },

    docEdit: function(address, kw, source) {
        // the doc in the user's language: another language's text is the
        // starting point of a translation, saved as a new file
        const language = genro.getData('gnr.language');
        const assets = this.docAssetUrl(address);
        const title = kw.title || source.title;
        genro.setData('gnr.docEditor.markdown', (source.markdown || '').split('](assets/').join('](' + assets));
        const dlg = this.quickDialog(_T('!!Documentation') + ' · ' + this._docTitleHtml(kw, source) + ' (' + language + ')',
                                     {width: '760px', closable: true});
        const placeholders = kw.placeholders ? kw.placeholders() : [];
        dlg.center._('MDEditor', {nodeId: 'doc_editor_md', value: '^gnr.docEditor.markdown',
            height: '440px', width: '740px',
            initialEditType: 'wysiwyg', usageStatistics: false,
            hooks: {addImageBlobHook: (blob, callback) => {
                this.docUploadImage(address, blob).then((link) => {
                    if (link) callback(assets + link.slice('assets/'.length), '');
                });
            }}});
        if (placeholders.length) {
            dlg.center._('div', {_class: 'doc_editor_placeholders',
                                 innerHTML: _T('!!Variables') + ': ' + placeholders.map((p) => '$' + p).join(' ')});
        }
        const save = (force) => {
            // the editor writes its datapath on blur, which a click on Save may precede
            const editorNode = genro.nodeById('doc_editor_md');
            const current = editorNode && editorNode.externalWidget
                ? editorNode.externalWidget.getMarkdown() : genro.getData('gnr.docEditor.markdown');
            const markdown = (current || '').split(assets).join('assets/');
            const params = {_save: 1, address: address, markdown: markdown, title: title};
            if (source.exists && source.language === language) params.base_mtime = source.mtime;
            if (force) params.force = 1;
            this._docPost(params).then((response) => {
                if (response.status === 409) {
                    this.ask(_T('!!Documentation'), _T('!!Somebody saved this doc while you were editing it'),
                             {overwrite: _T('!!Overwrite'), cancel: _T('!!Cancel')},
                             {overwrite: () => save(true)});
                    return;
                }
                if (!response.ok) {
                    genro.publish('floating_message', {message: _T('!!The doc was not saved'), messageType: 'error'});
                    return;
                }
                delete this._docSources[address];
                const state = this._docStates[address] || {};
                this._docStates[address] = {exists: !!markdown.trim(), editable: true, manual: !!state.manual};
                this.docApplyStates();
                dlg.close_action();
                if (this._helpPanelAddress === address) {
                    this.docSource(address, (fresh) => this.helpPanel(address, kw, fresh));
                }
            });
        };
        dlg.bottom._('button', 'save', {float: 'right', label: _T('!!Save'), action: () => save(false)});
        dlg.bottom._('button', 'cancel', {float: 'right', label: _T('!!Cancel'), action: () => dlg.close_action()});
        dlg.show_action();
        return dlg;
    },

    docUploadImage: function(address, blob) {
        // an image pasted or dropped in the editor, stored next to the doc
        return new Promise((resolve) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result);
            reader.onerror = () => resolve(null);
            reader.readAsDataURL(blob);
        }).then((dataUrl) => dataUrl ? this._docPost({_asset: 1, address: address, dataUrl: dataUrl}) : null)
          .then((response) => response && response.ok ? response.json() : null)
          .then((result) => result && result.link);
    },

    quickDialog: function(title,kw,rootNode) {
        kw = objectUpdate({_class:'dlg_prompt'},kw);
        var quickRoot = '_dlg_quick_'+genro.getCounter();
        rootNode = this._resolveDialogRoot(rootNode, quickRoot);
        var node = rootNode.getValue().getNode(quickRoot).clearValue();
        node.freeze();
        let kwdimension = objectExtract(kw,'height,width,background,padding');
        let bottom_position_kw = {}
        if(kw.closable){
            kw.connect_hide = function(){
                var that = this;
                setTimeout(function(){
                    that._destroy();
                },genro.dlg._quickDialogDestroyTimeout);
            };
        }
        var dlg = node._('dialog', objectUpdate({title:title},kw));
        if(kw.windowRatio || kw.parentRatio || kw.fullScreen){
            let bc = dlg._('BorderContainer');
            if(kw.dialog_bottom!==false){
                dlg.bottom = bc._('contentPane', 'bottom',{_class:'dialog_bottom',region:'bottom'});
            }
            dlg.center = bc._('contentPane', 'center',{_class:'pbl_dialog_center',region:'center'});
        }else{
            kwdimension['_class'] = 'dlg_body';
            let box = dlg._('div',kwdimension);
            let center = box._('div', {_class:'pbl_dialog_center'});
            if(kw.dialog_bottom!==false){
                dlg.bottom = box._('div', {_class:'dialog_bottom'});
            }
            dlg.center = center;
        }

        dlg.close_action = function() {
            dlg.getParentNode().widget.hide(); 
            setTimeout(function(){
                if(rootNode){
                    rootNode.getValue().popNode(quickRoot);
                }else{
                    var ndlg =dlg.getParentNode();
                    if(ndlg){
                        ndlg.getParentNode()._value.popNode(ndlg.label);
                    }
                }
            },genro.dlg._quickDialogDestroyTimeout);
            
        };
        dlg.show_action = function(onShowCb) {
            var node = this.getParentNode().getParentNode();
            node.unfreeze();
            var wdg = this.getParentNode().widget;
            genro.callAfter(function(){
                wdg.show();
                if(onShowCb){
                    onShowCb();
                }
            },1);
        };
        return dlg;
    },

    multiUploaderDialog:function(title,kw,sourceNode) {
        var uploaderKw = objectExtract(kw,'nodeId,height,width,uploadPath,onUploadedMethod,onUploadingMethod,onResult,label');
        kw.closable = true;
        var dlg = this.quickDialog(title,kw,sourceNode);
        uploaderKw.height = uploaderKw.height || '300px';
        uploaderKw.width =uploaderKw.width || '500px';
        uploaderKw.nodeId =uploaderKw.nodeId || 'multiuploader_'+genro.getCounter();
        var onResult = objectPop(uploaderKw,'onResult') || function(result){};
        uploaderKw.onResult = function(result){
            funcApply(onResult,{result:result},this);
            dlg.close_action();
        };
        uploaderKw.storepath = uploaderKw.storepath || '^gnr.multiupload_store';
        genro.setData('gnr.multiupload_store',new gnr.GnrBag());
        var g = dlg.center._('DropUploaderGrid',uploaderKw);
        dlg.show_action();
        var actionCb = function(){
            genro.nodeById(uploaderKw.nodeId).publish('doUpload');
        };
        dlg.bottom._('button','confirm',{float:'right',action:actionCb,label:kw.buttonLabel || _T('Upload files')});
        return dlg;
    },

    
    zoomPaletteFromSourceNode:function(sourceNode,evt){
        var zoomAttr =sourceNode.evaluateOnNode(sourceNode.attr._zoomKw);
        var attr = sourceNode.currentAttributes();
        objectUpdate(zoomAttr,objectExtract(attr,'_zoomKw_*'));
        zoomAttr.evt = evt;
        this.makeZoomElement(zoomAttr);
    },

    makeZoomElement:function(kw) {
        var mode = objectPop(kw,'mode') || 'palette';
        if(mode=='palette'){
            this.zoomPalette(kw);
        }else if(mode=='page' && genro.mainGenroWindow){
            var pageKw = {};
            kw['main_call'] = 'main_form';
            pageKw['file'] = this._prepareThIframeUrl(kw);
            pageKw['label'] = kw.title;
            pageKw['subtab'] = true;
            genro.mainGenroWindow.genro.publish('selectIframePage',pageKw);
        }
        else if(mode=='window' && genro.root_page_id){
            var pageKw = {};
            kw['main_call'] = 'main_form';
            pageKw['file'] = this._prepareThIframeUrl(kw);
            pageKw['label'] = kw.title;
            genro.mainGenroWindow.genro.publish('newBrowserWindowPage',pageKw);
        }
    },
    
    iframePalette:function(kw){
        var paletteCode=kw.paletteCode || 'external_'+genro.getCounter();
        var wdg = genro.wdgById(paletteCode+'_floating');
        if(wdg){
            wdg.show();
            wdg.bringToTop();
            return;
        }
        var zoomUrl = objectPop(kw,'url');
        genro.src.getNode()._('div',paletteCode,{_class:'hiddenDock'});
        var node = genro.src.getNode(paletteCode).clearValue();
        node.freeze();
        var paletteAttr = {'paletteCode':paletteCode,title:kw.title,overflow:'hidden',
                                                      dockTo:false,//'*:open',
                                                      width:'1px',height:'1px'
                                                     // palette_transition:'all .7s'
                                                      };
        if(kw.evt){
            paletteAttr.top=_px(evt.clientY);
            paletteAttr.left=_px(evt.clientX);
        }
        paletteAttr.palette_selfsubscribe_resize = "$1.top='100px';this.widget.setBoxAttributes($1);";
        objectUpdate(paletteAttr,kw);
        var palette = node._('palettePane',paletteCode,paletteAttr);
        palette._('iframe','iframeNode',{'src':zoomUrl,height:'100%',width:'100%',border:0}); 
        node.unfreeze();
        return palette; 
    },

    zoomFromCell:function(evt){
        var view = dijit.getEnclosingWidget(evt.target);
        view.content.decorateEvent(evt);
        var cellIndex = evt.cellIndex;
        var rowIndex = evt.rowIndex;
        var grid = view.grid;
        var structbag = grid.structbag();
        var cellattr = structbag.getNode('view_0.rows_0.#'+cellIndex).attr;
        var zoomAttr = objectExtract(cellattr,'zoom_*',true);
        let row = grid.rowByIndex(rowIndex);
        zoomAttr['pkey'] = row[(zoomAttr['pkey'] ? zoomAttr['pkey'] : grid._identifier).replace(/\./g, '_').replace(/@/g, '_')];
        zoomAttr['main_call'] = 'main_form';
        zoomAttr['evt'] = evt;
        zoomAttr['title'] = row[(cellattr['caption_field'] || cellattr['field']).replace(/\W/g, '_')]
        zoomAttr['url_th_linker'] =zoomAttr.linker || true;
        zoomAttr['paletteCode']  = zoomAttr['pkey']+(zoomAttr['formResource'] || '');
        zoomAttr = grid.sourceNode.evaluateOnNode(zoomAttr);
        var mode = objectPop(zoomAttr,'mode') || 'palette';

        if(mode=='palette'){
            this.zoomPalette(zoomAttr);
        }else if(mode=='page' && genro.root_page_id){
            var pageKw = {};
            pageKw['file'] = this._prepareThIframeUrl(zoomAttr);
            pageKw['label'] = zoomAttr.title;
            pageKw['subtab'] = true;
            genro.mainGenroWindow.genro.publish('selectIframePage',pageKw);
        }
        else if(mode=='window' && genro.root_page_id){
            var pageKw = {};
            pageKw['file'] = this._prepareThIframeUrl(zoomAttr);
            pageKw['label'] = zoomAttr.title;
            genro.mainGenroWindow.genro.publish('newBrowserWindowPage',pageKw);
        }
    },

    zoomPage:function(kw){
        kw = kw || {};
        kw.main_call = kw.main_call || 'main_form';
        kw['file'] = this._prepareThIframeUrl(kw);
        kw['label'] = kw.title;
        kw['subtab'] = true;
        genro.mainGenroWindow.genro.publish('selectIframePage',kw)
    },

    floatingEditor:function(sourceNode,kw){
        kw = kw || {};
        var paletteCode = kw.paletteCode || 'floatingEditor_'+sourceNode.getStringId();
        var wdg = genro.wdgById(paletteCode+'_floating');
        if (wdg){
            wdg.show();
            wdg.bringToTop();
            return;
        }
        genro.src.getNode()._('div',paletteCode,{_class:'hiddenDock'});
        var node = genro.src.getNode(paletteCode).clearValue();
        node.freeze();
        var kw = kw || {};
        var paletteAttr = {'paletteCode':paletteCode,title:'Editor',
                            overflow:'hidden',
                            dockTo:'dummyDock:open',
                            width:'800px',height:'400px',
                            maxable:true};
        var palette = node._('palettePane',paletteCode,paletteAttr);
        var valuepath = kw.valuepath || sourceNode.attr.innerHTML || sourceNode.attr.value;
        valuepath = '^'+sourceNode.absDatapath(valuepath);
        palette._('joditEditor',objectUpdate(kw,{value:valuepath,height:'100%'}));
        node.unfreeze(); 
    },


    dialogEditor:function(sourceNode,kw){
        var kw = kw || {};
        var dlg_kw = {closable:true,width:'800px',autoSize:true,dialog_bottom:false};
        var dlg = genro.dlg.quickDialog('Editor',objectUpdate(dlg_kw,kw));
        var valuepath = kw.valuepath || sourceNode.attr.innerHTML || sourceNode.attr.value;
        valuepath = '^'+sourceNode.absDatapath(valuepath);
        dlg.center._('joditEditor',objectUpdate(kw,{value:valuepath}));
        dlg.show_action()
    },

    thIframePalette:function(kw,openKw){
        if(objectPop(kw,'rootPalette')){
            kw.th_from_package = genro.getData("gnr.package")
            kw.url_forced_parent_page_id = genro.page_id;
            return genro.mainGenroWindow.genro.dlg.thIframePalette(kw,openKw);
        }
        var table = kw.table;
        var paletteCode= kw.paletteCode || 'th_'+table.replace('.','_')+(kw.formResource || '')+(kw.main_call  || '');
        var paletteNode = genro.nodeById(paletteCode+'_floating');
        openKw = openKw || {};

        var openKw = objectUpdate(openKw,objectExtract(kw,'default_*',false,true));
        if(kw.pkey){
            openKw.pkey = objectPop(kw,'pkey');
        }
        if(paletteNode){
            paletteNode.widget.show();
            paletteNode.widget.bringToTop();
        }else{
            var zoomUrl = this._prepareThIframeUrl(kw); 
            genro.src.getNode()._('div',paletteCode,{_class:'hiddenDock'});
            var node = genro.src.getNode(paletteCode).clearValue();
            node.freeze();
            var default_height = '300px';
            var default_width = '500px';
            var palette_height = objectPop(kw,'palette_height');
            var palette_width =  objectPop(kw,'palette_width');
            var sizeFromContent =  objectPop(kw,'sizeFromContent');
            var fixedTitle =  objectPop(kw,'fixedTitle');

            var paletteKwargs = objectExtract(kw,'palette_*',false,true);
            var dockTo = kw.dockTo===false?false: (kw.dockTo || 'dummyDock:open');
            var paletteAttr = {'paletteCode':paletteCode,title:kw.title || 'Palette:'+table,
                                                        overflow:'hidden',
                                                          dockTo: dockTo,
                                                          width:sizeFromContent?'1px':(palette_width || default_width),
                                                          height:sizeFromContent?'1px':(palette_height || default_height),
                                                          fixedPosition:true
                                                         // palette_transition:'all .7s'
                                                          };
            
            objectUpdate(paletteAttr,paletteKwargs);
            var palette = node._('palettePane',paletteCode,paletteAttr);
            var onSavedCb = objectPop(kw,'onSavedCb');
            var iframeNode = palette._('iframe',{'src':zoomUrl,height:'100%',width:'100%',border:0,onStarted:function(){
                
                var paletteNode = palette.getParentNode();
                var wdg = paletteNode.getWidget();
                if(this._genro._rootForm){
                    if(sizeFromContent){
                        palette_height = palette_height || this._genro.getData('gnr.rootform.size.height') || default_height;
                        palette_width = palette_width || this._genro.getData('gnr.rootform.size.width') || default_width;
                    }
                    if(kw.main_call=='main_form'){
                        this._genro._rootForm.subscribe('onDismissed',function(){if(!dockTo){wdg.close();}else{wdg.hide();}})
                    }
                    if(!fixedTitle){
                        this._genro._rootForm.subscribe('onChangedTitle',function(kw){wdg.setTitle(kw.title)});
                    }
                }else if(kw.lookup){
                    this._genro.nodeById('lookup_root').subscribe('lookup_cancel',function(){wdg.close();});
                }
                if(onSavedCb){
                    this._genro._rootForm.subscribe('onSaved',function(kw){
                        onSavedCb(kw);
                    });
                }
                if(sizeFromContent && !wdg._size_from_cache){
                    wdg.setBoxAttributes({height:palette_height || default_height,width:palette_width || default_width});
                }

            }}).getParentNode();         
            node.unfreeze(); 
            var paletteNode = genro.nodeById(paletteCode+'_floating');
            paletteNode._iframeNode = iframeNode;
        }
        if(objectNotEmpty(openKw)){
            openKw.topic = openKw.topic || 'main_form_open';
            paletteNode._iframeNode.domNode.gnr.postMessage(paletteNode._iframeNode,openKw);
        }
        return paletteNode;
    },

    _prepareThIframeUrl:function(kw){
        var prefix = kw.lookup? '/sys/lookuptables/':'/sys/thpage/';
        var zoomUrl = kw.zoomUrl || prefix+kw.table.replace('.','/');
        zoomUrl = genro.buildContextUrl(zoomUrl);
        var urlKw = objectExtract(kw,'url_*');
        urlKw.th_public = objectPop(kw,'public') || false;
        if(kw.pkey){
            urlKw.th_pkey = kw.pkey; 
        }
        if(kw.formResource){
            urlKw.th_formResource = kw.formResource;
        }
        if(kw.viewResource){
            urlKw.th_viewResource = kw.viewResource;
        }
        if(kw.main_call){
            urlKw['main_call'] = kw.main_call;
        }
        if (kw.readOnly){
            urlKw['readOnly'] = kw.readOnly;
        }
        objectUpdate(urlKw,objectExtract(kw,'current_*',false,true));
        if(!('th_from_package' in kw)){
            urlKw['th_from_package'] = kw.th_from_package || genro.getData("gnr.package");
        }
        
        urlKw['_parent_page_id'] = objectPop(urlKw,'forced_parent_page_id') || genro.page_id;
        
        return genro.addParamsToUrl(zoomUrl,urlKw); 
    },

    zoomPalette:function(kw,openKw){
        var evt = objectPop(kw,'evt');
        if(evt){
            kw.palette_top = _px(evt.clientY);
            kw.palette_left = _px(evt.clientX);
            kw.sizeFromContent = true;
        }
        return this.thIframePalette(kw,openKw);
    },



    quickPalette:function(paletteCode,kw,content){
        var kw = kw || {};
        kw = objectUpdate({paletteCode:paletteCode,dockTo:'dummyDock:open'},kw);
        var wdg = genro.wdgById(paletteCode+'_floating');
        var evt = kw.evt;
        if(wdg){
            wdg.show();
            wdg.bringToTop();
            return;
        }
        genro.src.getNode()._('div',paletteCode,{_class:'hiddenDock'});
        var node = genro.src.getNode(paletteCode).clearValue();
        node.freeze();
        if(evt){
            kw.top=_px(evt.clientY);
            kw.left=_px(evt.clientX);
        }
        var palette = node._('palettePane',paletteCode,kw);
        if(content){
            if(typeof(content)=='string'){
                palette._('div',{innerHTML:content});
            }else if(content instanceof gnr.GnrDomSourceNode){
                palette.setItem(content.label,content._value,content.attr);
            }else if(typeof(content)=='function'){
                content(palette);
            }else{
                var tag = objectPop(content,'tag') || 'div';
                palette._(tag,content);
            }
            
        }
        node.unfreeze();
        return palette.getParentNode();
    },

    lazyTip:function(domNode,rpcmethod){
        var kw = {};
        var k = 0;
        for (var i=2; i<arguments.length;i++){
            kw['p_'+k] = arguments[i];
            k++;
        }


        var to = setTimeout(function(){
            var result = genro.serverCall(rpcmethod,kw);
            domNode.setAttribute('title',result);
            domNode.setAttribute('onmouseover','');
        },1000);
        domNode.onmouseout = function(){
            clearTimeout(to);
        };
    },
    

    listChoice: function(title, msg, buttons, resultPath, valuePath, storePath) {
        genro.src.getNode()._('div', '_dlg_listChoice');
        var buttons = buttons || {confirm:_T('Confirm'),cancel:_T('Cancel')};
        var node = genro.src.getNode('_dlg_listChoice').clearValue().freeze();
        var dlg = node._('dialog', {nodeId:'_dlg_listChoice',title:title})._('div', {_class:'dlg_ask',
            'action':"genro.wdgById('_dlg_listChoice').hide();genro.setData('" + resultPath + "',this.attr.actCode);"});
        dlg._('div', {'content':msg,'_class':'selectable dlg_ask_msg'});
        dlg._('filteringSelect', {'value':'^' + valuePath, 'storepath':storePath, 'ignoreCase':true});
        var btnBox = dlg._('div', {'_class':'dialog_bottom dlg_ask_btnBox'});
        for (var btn in buttons) {
            btnBox._('button', {'_class':'dlg_ask_btn','label':buttons[btn],'actCode':btn});
        }
        node.unfreeze();
        genro.wdgById('_dlg_listChoice').show();
    },

    uploaderDialog:function(title,method,kw){
        var kw = kw || {};
        var dlg_kw = objectUpdate({closable:true,autoSize:true,dialog_bottom:false},objectExtract(kw,'dlg_*'));
        var dlg = genro.dlg.quickDialog(title,dlg_kw);
        kw.label = _T(kw.label || '!!Drop the file to import here');
        kw.onUploadedMethod = method;
        kw.onResult = function(handler){
            var result = handler.currentTarget.responseText;
            if(kw.onImport){
                kw.onImport(result);
            }
            if(kw.resultPath){
                genro.setData(kw.resultPath,result);
            }
            dlg.close_action();
        };
        dlg._('div',{padding:'10px'})._('dropUploader',(objectUpdate({progressBar:true,width:'300px'},kw)))
        dlg.show_action();
    },

    _modalUploader_uploader:function(sc,kw,dlg){
        let uploaderBc = sc._('borderContainer','uploaderPane',{pageName:'uploaderPane'});
        let defaultLabel = '!!Drop the file to import here or dblclick to open the file explorer';
        if(genro.isMobile){
            defaultLabel = '!!Press to open the file explorer';
        }
        kw.label = `<div style="font-size:1.1em;">${_T(kw.label || defaultLabel)}</div>`;
        kw.position = 'absolute';
        kw.top = 0;
        kw.bottom = 0
        kw.left = 0;
        kw.right = 0;
        kw._class='center_box'
        kw.dropArea__class = 'center_box'
        kw.dropArea_position = 'absolute';
        kw.dropArea_top = '10px';
        kw.dropArea_bottom = '10px';
        kw.dropArea_left = '10px';
        kw.dropArea_right = '10px';
        kw.dropArea_border = '2px dotted silver';
        kw.dropArea_border_radius = '10px';
        kw.onResult = function(handler){
            let scNode = sc.getParentNode()
            scNode.widget.switchPage(1);
            let preview_url =handler.currentTarget.responseText;
            preview_url = genro.addParamsToUrl(preview_url,{_nocache:genro.time36Id()});
            scNode.setRelativeData('.preview_url',preview_url);
        };
        bar = uploaderBc._('contentPane',{'region':'bottom',_class:'dialog_bottom'})._('slotBar','bar',{slots:'5,back,*'})
        bar._('slotButton','back',{label:_T('Close'),action:function(){
            dlg.close_action();
        }});
        uploaderBc._('contentPane',{region:'center'})._('dropUploader','uploader',{progressBar:true,...kw});

    },

    _modalUploader_preview:function(sc,dlg,sourceNode,kw){
        let bc = sc._('borderContainer','previewPane',{pageName:'previewPane'});
        let bottom = bc._('contentPane',{region:'bottom',_class:'dialog_bottom'});
        let center = bc._('contentPane',{region:'center',overflow:'hidden'})
        center._('iframe',{documentClasses:true,height:'100%',width:'100%',
                border:0,src:'^.preview_url'}
        );
        bar = bottom._('slotBar','bar',{slots:'5,back,*,confirm,5'})
        bar._('slotButton','back',{label:_T('Change file'),action:function(){
            sc.getParentNode().widget.switchPage(0);
        }});
        bar._('slotButton','confirm',{label:_T('Confirm'),action:function(){
            let preview_url = sc.getParentNode().getRelativeData('.preview_url');
            let l =preview_url.split('?')[0].split('/');
            let filename = l[l.length-1];
            console.log('filename',filename)
            var sn = sourceNode || sc.getParentNode();
            var uploadFullpath = kw.uploadPath+'/'+filename;
            genro.lockScreen(true,'moveUploadedFileToDestination');
            genro.serverCall(kw.method || 'moveUploadedFileToDestination',
                {_sourceNode:sn,temp_path:uploadFullpath,
                    dest_stn:kw.dest_stn,
                    ...objectExtract(kw,'dest_fld,dest_record_pkey',true),
                    ...objectExtract(kw,'rpc_*',true)},
                function(dest_stn){
                    genro.lockScreen(false,'moveUploadedFileToDestination');
                    if(kw.onConfirm){
                        funcApply(kw.onConfirm,{temp_path:uploadFullpath,dest_stn:dest_stn},sn);
                    }
                    dlg.close_action();
                }
            )
        }})

    },

    modalUploaderDialog:function(title,kw,sourceNode){
        kw = kw || {};
        let prompt_datapath = objectPop(kw,'datapath') || 'gnr.promptDlg.prompt_'+genro.dlg.prompt_counter;
        if(sourceNode){
            prompt_datapath = sourceNode.absDatapath(prompt_datapath);
        }
        
        kw.uploadPath = kw.uploadPath || 'page:modalUploader';
        let dlg_kw = {closable:true,windowRatio:.9,dialog_bottom:false,datapath:prompt_datapath,
                    _class:'dlg_uploader',
                    _workspace:true,...objectExtract(kw,'dlg_*')};
        let sizekw = objectExtract(dlg_kw,'height,width');
        if(objectNotEmpty(sizekw)){
            objectPop(dlg_kw,'windowRatio');
        }
        let dlg = genro.dlg.quickDialog(title,dlg_kw);
        var sc = dlg.center._('stackContainer',{...sizekw});
        this._modalUploader_uploader(sc,kw,dlg)
        this._modalUploader_preview(sc,dlg,sourceNode,kw)
        dlg.show_action();
    },

    upload: function(title, method, resultPath, remotekw, label, cancel, send, fireOnSend) {
        /* first 3 params are mandatory */
        //DEPRECATED
        label = label || 'Browse...';
        cancel = cancel || 'Cancel';
        send = send || 'Send';
        var title = title;
        genro.src.getNode()._('div', '_dlg_ask');
        var node = genro.src.getNode('_dlg_ask').clearValue().freeze();
        var dlgRoot = node._('div');
        var baseId = node.getValue().getNodes()[0].getStringId();
        var kw = {width:'340px',height:'25px',margin:'15px',
            label:label,
            cancel:cancel,
            id:baseId + '_uploader',
            method:method,
            onUpload:'genro.setData("' + resultPath + '", $1);'};
        if (remotekw) {
            for (var par in remotekw) {
                kw['remote_' + par] = remotekw[par];
            }
        }

        var dlg = dlgRoot._('dialog', {id:baseId + '_dlg',title:title})._('div', {_class:'dlg_ask'});
        dlg._('div')._('fileInput', kw);

        var cb = function() {
            var dlgid = baseId + '_dlg';
            var uploaderid = baseId + '_uploader';
            dijit.byId(dlgid).onCancel();
            if (fireOnSend) {
                genro.fireEvent(fireOnSend);
            }
            dijit.byId(uploaderid).uploadFile();
        };

        dlg._('div')._('button', {label:send,margin_right:'15px',margin_bottom:'1px',
            onClick:cb});
        node.unfreeze();
        dijit.byId(baseId + '_dlg').show();
    }
});

