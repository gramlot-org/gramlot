/*
 *-*- coding: UTF-8 -*-
 *--------------------------------------------------------------------------
 * package       : Genro js - see LICENSE for details
 * module GnrDomSource : Genro clientside structure implementation for web elements
 * Copyright (c) : 2004 - 2007 Softwell sas - Milano
 * Written by    : Giovanni Porcari, Francesco Cavazzana
 *                 Saverio Porcari, Francesco Porcari
 *--------------------------------------------------------------------------
 *This library is free software; you can redistribute it and/or
 *modify it under the terms of the GNU Lesser General Public
 *License as published by the Free Software Foundation; either
 *version 2.1 of the License, or (at your option) any later version.

 *This library is distributed in the hope that it will be useful,
 *but WITHOUT ANY WARRANTY; without even the implied warranty of
 *MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *Lesser General Public License for more details.

 *You should have received a copy of the GNU Lesser General Public
 *License along with this library; if not, write to the Free Software
 *Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
 */



//######################## class BagNode##########################
dojo.declare("gnr.GnrDomSourceNode", gnr.GnrBagNode, {
    constructor:function(){
        var mobile_kw = objectExtract(this.attr,'mobile_*');
        if(genro.isMobile && objectNotEmpty(mobile_kw)){
            objectUpdate(this.attr,mobile_kw);
        }
    },

    application:function() {
        return this.getParentBag().getRoot().application;
    },
    freeze:function() {
        this._isFreezed = true;
        return this;
    },
    unfreeze:function(noRebuild) {
        this._isFreezed = false;
        if (!noRebuild) {
            this.rebuild();
        }
    },
    isFreezed:function(){
        var parentNode = this.getParentNode();
        return this._isFreezed?true:parentNode?parentNode.isFreezed():false;
    },
    
    getBuiltObj:function() {
        return this.getWidget(true) || this.getDomNode();
    },
    
    getParentBuiltObj:function() {
        var parentNode = this.getParentNode();
        if (parentNode) {
            return parentNode.getBuiltObj();
        }
    },

    getDomNode:function() {
        if (this.domNode) {
            return  this.domNode;
        }
        if (this.widget) {
            return  this.widget.focusNode || this.widget.containerNode || this.widget.domNode;
        }
        return this.getParentNode()?this.getParentNode().getDomNode():null;

    },
    
    getWidget:function(notEnclosed) {
        if(this.domNode && !notEnclosed){
            return dijit.getEnclosingWidget(this.domNode);
        }
        var curr = this;
        var currvalue;
        while(curr && !curr.widget && !curr.domNode){
            currvalue = curr.getValue();
            if(currvalue instanceof gnr.GnrBag){
                curr = currvalue.getNode('#0');
            }else{
                return;
            }
        }
        return curr?curr.widget:null;
    },
    
    
    _relativeGetter:function(prefix){
        var that = this;
        return function(path){
            return that.getRelativeData(prefix? prefix+path:path);
        };
    },
    
    getParentWidget:function(tagToFind) {
        var tag=tagToFind?tagToFind.toLowerCase():none;
        var parentNode = this.getParentNode();
        if (parentNode) {
            return (parentNode.widget && (!tag || ((parentNode.attr.tag ||'' ).toLowerCase()==tag)))?parentNode.widget : parentNode.getParentWidget(tagToFind);
        }
    },
    destroy:function() {
        if (this.widget) { /* this is a widget*/
            this.widget.destroyRecursive();
        }
        else if (this.domNode) {
            var widgets = dojo.query('[widgetId]', this.domNode);
            widgets = widgets.map(dijit.byNode);     // Array
            dojo.forEach(widgets, function(widget) {
                widget.destroy();
            });
            while (this.domNode.childNodes.length > 0) {
                dojo._destroyElement(this.domNode.childNodes[0]);
            }
            dojo._destroyElement(this.domNode);
        }
    },

    getTriggerReason:function(pathToCheck,kw){
        if(kw.reason == 'autocreate'){
            return;
        }
        if(!pathToCheck){
            return;
        }
        var eventpath = kw._eventpath !== undefined ? kw._eventpath :
                        (kw._eventpath = kw.pathlist.slice(1).join('.'));
        var isValuePath = (pathToCheck.indexOf('?') < 0);
        if (pathToCheck.indexOf('#parent') > 0) {
            pathToCheck = gnr.bagRealPath(pathToCheck);
        }
        if (!isValuePath) {
            if ((kw.updattr) || (kw.evt=='fired') ||(pathToCheck.indexOf('?=') >= 0)) {
                pathToCheck = pathToCheck.split('?')[0];
            }
        }
        if (pathToCheck == eventpath) {
            if(isValuePath && kw.updattr && !kw.updvalue){
                return;
            }
            return 'node';
        }else if (pathToCheck.indexOf(eventpath + '.') == 0) { 
            return 'container';
        }
        else if (eventpath.indexOf(pathToCheck + '.') == 0) {
            return 'child';
        }
    },

    trigger_data:function(prop, kw) {
        var trigger_reason = this.getTriggerReason(this.attrDatapath(prop),kw)
        if (trigger_reason) {
            if ((kw.evt == 'fired') && (trigger_reason == 'child')) {
                // pass fired event on child datapath: get only parent changes for variable datapaths
            } else if (kw.evt == 'invalid') {
                if (this.widget) {
                    this.widget.focus();
                }
            } else if (this._dataprovider /*&& (kw.evt!='del')*/) { //VERIFICARE perché erano escusi gli eventi DEL
                if(prop=='_timing'){
                    this.setTiming(kw.value);
                }else{
                    this.setDataNodeValue(kw.node, kw, trigger_reason);
                }
            }
            else {
                if (kw.reason != this ) {
                    this.updateAttrBuiltObj(prop, kw, trigger_reason);
                }
            }
        }
    },
    fireNode: function(runKwargs,kw, trigger_reason) {
        return this.setDataNodeValue(runKwargs,kw,trigger_reason);
    },

    pasteFromClipboard: async function(path,mode){
        path = path || this.attr.value || this.attr.storepath || this.attr.innerHTML
        const clipboardText = await navigator.clipboard.readText();
        if(!clipboardText){
            return;
        }
        let value = clipboardText;
        if(mode=='xlsx'){
            let sheetjs = await genro.plugin('sheetjs');
            value = sheetjs.bagFromXLSXText(clipboardText);
        }else if(mode=='bag' && clipboardText[0]=='<'){
            value = new gnr.GnrBag(clipboardText);
        }
        this.setRelativeData(path,value);
    },
    
    copyInClipboard:function(path){
        let value;
        if(path){
            value = this.getRelativeData(path);
        }else{
            let attribute = this.attr.value && 'value' 
            || this.attr.storepath && 'storepath' 
            || 'innerHTML';
            value = this.getAttributeFromDatasource(attribute);
        }
        if(value instanceof gnr.GnrBag){
            value = value.toXml();
        }
        genro.textToClipboard(value);
    },
    setDataNodeValue:function(nodeOrRunKwargs, kw, trigger_reason, subscription_args) {
        if(nodeOrRunKwargs===null){
            nodeOrRunKwargs = {}
        }
        var currentAttributes = this.currentAttributes();
        var delay = currentAttributes._delay;
        if(delay == 'auto'){
            delay = null;//genro.rpc.rpc_level>2? genro.rpc.rpc_level * 100 : null;
        }
        if (delay) {
            if (this.pendingFire) {
                clearTimeout(this.pendingFire);
            }
            this.pendingFire = setTimeout(dojo.hitch(this, 'setDataNodeValueDo', nodeOrRunKwargs, kw, trigger_reason,subscription_args),delay);
        } else if(this.attr._ask){
            let subscriptions = objectExtract(this.attr, 'subscribe_*',true);
            if((kw && kw.reason == 'autocreate' ) || (trigger_reason != 'node' && !(trigger_reason in subscriptions))){
                return; //askmode
            }
            if(typeof(this.attr._ask)=='string'){
                if(!this.attr._ask_if ||  funcApply('return ('+this.attr._ask_if+');',currentAttributes,this) ){
                    var that = this;
                    var _ask_onCancel= this.attr._ask_onCancel || function(){};
                    _ask_onCancel = funcCreate(_ask_onCancel,'kwargs',this);
                    genro.dlg.ask(currentAttributes._ask_title || 'Warning',currentAttributes._ask,null,
                                {confirm:function(){that.setDataNodeValueDo(nodeOrRunKwargs, kw, trigger_reason, subscription_args);},
                                cancel:function(){_ask_onCancel(currentAttributes)}});
                }else{
                    this.setDataNodeValueDo(nodeOrRunKwargs, kw, trigger_reason, subscription_args);
                }
            }else{
                var runKwargs = (nodeOrRunKwargs instanceof gnr.GnrBagNode)?{}:nodeOrRunKwargs;
                var currAttr = this.currentAttributes();
                objectUpdate(currAttr,runKwargs);
                if(subscription_args && typeof(subscription_args[0])=='object'){
                    objectUpdate(currAttr,subscription_args[0]);
                }
                genro.dlg.askParameters(function(_askResult){
                    objectUpdate(runKwargs,_askResult);
                    runKwargs._askResult = _askResult;        
                    this.setDataNodeValueDo(runKwargs, kw, trigger_reason, subscription_args);
                },this.attr._ask,currAttr,this);
            }
        }
        else{
            return this.setDataNodeValueDo(nodeOrRunKwargs, kw, trigger_reason, subscription_args);
        }
    },

    setDataNodeValueDo:function(nodeOrRunKwargs, kw, trigger_reason, subscription_args) {
        var node;
        var runKwargs;
        var isFiredNode = !(nodeOrRunKwargs instanceof gnr.GnrBagNode)
        if(isFiredNode){
            runKwargs = nodeOrRunKwargs;
        }else{
            node = nodeOrRunKwargs;
        }
        var attributes = objectUpdate({}, this.attr);

        var strippedKw = objectPop(attributes,'_strippedKwargs');

        var _userChanges = objectPop(attributes, '_userChanges');
        var _trace = objectPop(attributes, '_trace');
        var _trace_level = objectPop(attributes, '_trace_level') || 0;
        if ((kw && kw.reason == 'autocreate' ) || ( _userChanges && trigger_reason != 'node')) {
            return;
        }
        objectExtract(attributes, 'subscribe_*');
        var tag = objectPop(attributes, 'tag').toLowerCase();
        var path = objectPop(attributes, 'path');
        if(path=='dummy'){
            path = null;
        }
        objectPop(attributes, '_onStart');
        objectPop(attributes, '_onBuilt');
        objectPop(attributes, '_fired_onStart');
        objectPop(attributes, 'datapath');
        var destinationPath, dataNode;
        if (path) { // if it has a result path set it to the returned value
            destinationPath = this.absDatapath(path);
            dataNode = genro.getDataNode(destinationPath, true);
        }
        objectPop(attributes, '_init');
        objectPop(attributes, '_delay');
        var _if = objectPop(attributes, '_if');
        var _else = objectPop(attributes, '_else');
        var expr;
        if (tag == 'dataformula') {
            expr = objectPop(attributes, 'formula');
        } else if ((tag == 'datacontroller') || (tag == 'datascript')) {
            expr = objectPop(attributes, 'script');
        } else {
            expr = objectPop(attributes, 'method');
            expr = this.getAttributeFromDatasource('method');
        }
        if (_trace) {
            console.log("TRACE " + tag + "(" + _trace + ")");
            if (_trace_level >= 2) {
                console.log("trigger_reason=" + trigger_reason);
                console.log("kw=");
                console.log(kw);
            }
            if (_trace_level >= 3) {
                console.log("expr=");
                console.log(expr);
            }
        }
        var argValues = [node, {'kw':kw, 'trigger_reason':trigger_reason},trigger_reason];
        var argNames = ['_node', '_triggerpars','_reason']; //_node is also in _triggerpars.kw.node: todo remove (could be used as $1)
        var kwargs = {};
        var strippedKwargs = {};
        if(strippedKw){
            strippedKw.split(',').forEach(function(attr){
                if (!(attr in attributes)){
                    argNames.push(attr);
                    argValues.push(null);
                }
            })
        }
        if (subscription_args) {
            argNames.push(trigger_reason);
            argValues.push(subscription_args);
            if ((subscription_args.length == 1) && (typeof(subscription_args[0]) == 'object')) {
                for (let k in subscription_args[0]) {
                    argNames.push(k);
                    argValues.push(subscription_args[0][k]);
                    kwargs[k] = subscription_args[0][k];
                }
                argNames.push('_subscription_kwargs');
                argValues.push(subscription_args[0]);
                kwargs['_subscription_kwargs'] = subscription_args[0];
            }
        }
        var val;
        if (_trace && (_trace_level > 0)) {
            console.log('Arguments:');
        }
        for (var attrname in attributes) {
            argNames.push(attrname);
            val = this.getAttributeFromDatasource(attrname);
            argValues.push(val);
            kwargs[attrname] = val;
            if (_trace && (_trace_level > 0)) {
                console.log("--- " + attrname + " ---");
                console.log(val);
            }
        }
        if(runKwargs){
            for (let k in runKwargs) {
                argNames.push(k);
                argValues.push(runKwargs[k]);
                kwargs[k] = runKwargs[k];
            }
            argNames.push('_runKwargs');
            argValues.push(runKwargs);
        }
        //objectUpdate(kwargs,runKwargs);
        var if_result = true;
        if (_if) {
            if_result = funcCreate('return (' + _if + ')', argNames.join(',')).apply(this, argValues);
            if (_trace && (_trace_level > 0)) {
                console.log("_if=" + if_result);
            }
        }
        if (tag == 'dataformula' || tag == 'datascript' || tag == 'datacontroller' || tag == 'datarpc') {
            var val;
            if (! if_result) {
                if (!_else) {
                    return;
                }
                expr = _else;
            }
            if (tag == 'datarpc' && (expr != _else)) {
                var doCall = true;
                var domsource_id = this.getStringId();
                var method = expr;
                var httpMethod = objectPop(kwargs, 'httpMethod');
                httpMethod = httpMethod || (objectPop(kwargs, '_POST') === false? 'GET' : 'POST');

                var _onResult = objectPop(kwargs, '_onResult');
                var _onError = objectPop(kwargs, '_onError');
                var _lockScreen = objectPop(kwargs, '_lockScreen');
                var _execClass = objectPop(kwargs, '_execClass');
                objectPop(kwargs, 'nodeId');
                var _onCalling = objectPop(kwargs, '_onCalling');
                var origKwargs = objectUpdate({}, kwargs);
                if (_onResult) {
                    _onResult = funcCreate(_onResult, 'result,kwargs,old', this);
                }
                if (_onError) {
                    _onError = funcCreate(_onError, 'error,kwargs', this);
                }
                var cb = function(result, error) {
                    error = error || result?result.error:null;
                    if (_lockScreen) {
                        genro.lockScreen(false, domsource_id,_lockScreen);
                    }
                    if(_execClass){
                        genro.dom.removeClass(dojo.body(),_execClass);
                    }
                    if (error) {
                        if (_onError) {
                            _onError(error, origKwargs);
                        }
                        //else {
                        //    genro.dlg.alert(error, 'Server error');
                        //}
                    }
                    else {
                        var oldValue;
                        if (dataNode) {
                            oldValue = dataNode.getValue();
                            dataNode.setValue(result);
                            dataNode._rpcNode_id = this._id;
                        }
                        if (_onResult) {
                            _onResult(result, origKwargs, oldValue);
                        }
                    }
                    return result
                };
                if(_execClass){
                    genro.dom.addClass(dojo.body(),_execClass);
                }
                if (_onCalling) {
                    doCall = funcCreate(_onCalling, (['kwargs'].concat(argNames)).join(',')).apply(this, ([kwargs].concat(argValues)));
                }
                objectExtract(kwargs, '_*');
                if (doCall !== false) {
                    if (_lockScreen) {
                        genro.lockScreen(true, domsource_id,_lockScreen);
                    }   
                    if (!this._deferredRegister){
                        this._deferredRegister ={};
                    }   
                    kwargs['_sourceNode'] = this;
                    var deferred = genro.rpc.remoteCall(method, kwargs, null, httpMethod, null, cb);
                    if(deferred){
                        this._deferredRegister[deferred.id]= deferred;
                        this._lastDeferred = deferred;
                        var that = this;
                        deferred.addCallback(function(result){
                            that._lastRpcTs = new Date();
                            delete that._deferredRegister[deferred.id];
                            return result;
                        });
                        if(this._callbacks){
                            this._callbacks.forEach(function(n){
                                var kw = objectUpdate({},kwargs);
                                kw['_isFiredNode'] = isFiredNode;
                                genro.rpc.addDeferredCb(deferred,n.getValue(),objectUpdate(kw,n.attr),that);
                            });
                        }
                    }
                    return deferred;
                }
            }
            else {
                var result;
                if (!expr) {
                    result = new gnr.GnrBag(kwargs);
                } else {
                    expr = (tag == 'dataformula') ? 'return ' + expr : expr;
                    var f = funcCreate(expr, (['_kwargs'].concat(argNames)).join(','));
                    result = f.apply(this, ([kwargs].concat(argValues)));
                }
                if (destinationPath) { // if it has a dataNode set it to the returned value
                    this.setRelativeData(destinationPath,result);
                    //dataNode.setValue(result);
                }
            }
        }
        else {
            if (if_result) {
                method = expr;
                var cacheTime = objectPop(attributes, 'cacheTime', -1);
                var isGetter = objectPop(attributes, 'isGetter', false);
                attributes.sync = ('sync' in attributes) ? attributes.sync : true;
                attributes['_sourceNode'] = this;
                var resolvedValue = this._resolvedValue;
                var resolver = genro.rpc.remoteResolver(method, attributes, {'cacheTime':cacheTime,
                    'isGetter':isGetter});
                // the resolver already took its own copy of the parameters: a GnrDomSourceNode
                // left in node.attr breaks any serialization of that node (e.g. a record cluster).
                objectExtract(attributes, '_*');
                dataNode.setValue(resolver, true, attributes);
                if(resolvedValue){
                    dataNode._status = 'loaded';
                    dataNode.setValue(resolvedValue,'resolver');
                    dataNode._resolver.lastUpdate = new Date();
                    delete this._resolvedValue;
                }
            }
        }
        
    },
    setAttributeInDatasource: function(attrname, value, doTrigger, attributes) {
        doTrigger = (doTrigger == null) ? this:doTrigger;
        var path = this.attrDatapath(attrname);
        if (isBag(attributes)) {
            attributes = attributes.asDict();
        }
        if (path == null || (value == null && !objectNotEmpty(attributes) && !genro._data.getNode(path))) {
            return; //nothing to publish: an attribute never set needs no datanode
        }
        if (objectNotEmpty(attributes)) {
            // attributes can be a live store row: without a copy of its container values too
            // the datastore node would alias them and no comparison could detect a change
            var snapshot = {};
            for (var k in attributes) {
                var v = attributes[k];
                if (isBag(v)) {
                    v = v.deepCopy();
                } else if (v != null && v.constructor === Object) {
                    v = objectUpdate({}, v);
                }
                snapshot[k] = v;
            }
            attributes = snapshot;
        }
        genro._data.setItem(path, value, attributes, {'doTrigger':doTrigger,'lazySet':true});
    },
    defineForm: function(formId, formDatapath, controllerPath, pkeyPath,kw) {
        this.form = new gnr.GnrFrmHandler(this, formId, formDatapath, controllerPath, pkeyPath,kw);
    },
    hasDynamicAttr: function(attr) {
        return (this._dynattr && (attr in this._dynattr));
    },

    getRelativeData: function(path, autocreate, dflt) {
        var path = this.absDatapath(path);
        var value;
        if (path != null) {
            if (autocreate) {
                var node = genro._data.getNode(path, false, autocreate, dflt);
                value = genro._data.getItem(path,null,null,{'_sourceNode':this});
               //if (path.indexOf('?') >= 0) {
               //    value = genro._data.getItem(path);
               //} else if (node) {
               //    value = node.getValue(null, {'_sourceNode':this});
               //}
            } else {
                value = genro._data.getItem(path,null,null,{'_sourceNode':this});
               //if (path.indexOf('?') >= 0) {
               //    value = genro._data.getItem(path);
               //} else {
               //    var node = genro._data.getNode(path);
               //    if (node) {
               //        value = node.getValue(null, {'_sourceNode':this});
               //    }
               //}

            }
        }
        return value;
    },
    fireEvent:function(path, value, attributes, reason, delay) {
        this.setRelativeData(path, value || true, attributes, true, reason, delay);
    },
     
    setRelativeData: function(path, value, attributes, fired, reason, delay,_kwargs) {
        // var reason=reason || this
        if (delay) {
            setTimeout(dojo.hitch(this, 'setRelativeData', path, value, attributes, fired, reason,null,_kwargs), delay);
        } else {
            reason = reason == null ? true : reason;
            var oldpath = path;
            path = this.absDatapath(path);
            if (fired) {
                genro._firingNode = this;
                genro._data.fireItem(path, value, attributes, {'doTrigger':reason});
                genro._firingNode = null;
            } else {
                genro._data.setItem(path, value, attributes, objectUpdate({'doTrigger':reason,lazySet:true},_kwargs));
            }
        }
    },
    getAttributeFromDatasource: function(attrname, autocreate, dflt) {
        attrname = attrname || 'value';
        var value = this.attr[attrname];
        value = this.currentFromDatasource(value, autocreate, dflt);
        if (((attrname == 'innerHTML')) && (this.attr.mask || this.attr.format || (value instanceof gnr.GnrBag)) ) {
            var kw = objectUpdate({},this.attr);
            objectPop(kw,attrname);
            value = genro.formatter.asText(value, this.evaluateOnNode(kw));
        }
        return value;
    },
    
    currentFromDatasource: function(value, autocreate, dflt) {
        var path;
        if (typeof(value) == 'string') {
            if (this.isPointerPath(value)) {
                if (value.indexOf('==') == 0) {
                    var argNames = [];
                    var argValues = [];
                    for (var attr in this.attr) {
                        var attrval = this.attr[attr];
                        if ((typeof(attrval) != 'string') || (attrval.indexOf('==') != 0)) { // if it is not a formula: for avoid infinite loop
                            argNames.push(attr);
                            argValues.push(this.getAttributeFromDatasource(attr));
                        }
                    }
                    try {
                        value = funcCreate('return ' + value.slice(2), argNames.join(',')).apply(this, argValues);
                    } catch(e) {
                        if (console != undefined) {
                            console.log('ERROR in ' + value);
                            console.log(e);
                            console.log('arguments: ');
                            for (var i = 0; i < argNames.length; i++) {
                                console.log(argNames[i] + " = " + argValues[i]);
                            }
                        }
                        throw e;
                    }
                } else {
                    value = this.getRelativeData(value, autocreate, dflt);
                }
            }
        }
        return value;
    },
    isLostNode: function() {
        //true when this node no longer belongs to the live source tree:
        //remote content rebuilds tear nodes down while their widgets may
        //still fire async callbacks (validate, label fetch, late onChange)
        var currbag = this._parentbag;
        while (currbag && currbag._parentnode) {
            currbag = currbag._parentnode._parentbag;
        }
        return currbag !== genro.src._main;
    },
    attrDatapath: function(attrname,targetNode) {
        targetNode = targetNode || this;
        if (!attrname) {
            return targetNode.absDatapath();
        }
        var attrvalue = this.attr[attrname];
        var path = null;
        if (typeof(attrvalue) == 'string') {
            if (this.isPointerPath(attrvalue)) {
                attrvalue = attrvalue.slice(1);
            }
            path = targetNode.absDatapath(attrvalue);
        }
        return path;
    },
    isPointerPath: function(path) {
        return path? ((path.indexOf('^') === 0) || (path.indexOf('=') === 0)):false;
    },
    nodeById:function(nodeId){
        return genro.nodeById(nodeId,this); 
    },
    
    wdgById:function(nodeId){
        return genro.wdgById(nodeId,this); 
    },
    
    domById:function(nodeId){
        return genro.domById(nodeId,this); 
    },
    
    getPathId:function(){
        return stringHash(this.getFullpath());
    },
    
    symbolicDatapath:function(path) {
        var attachpath;
        var pathlist = path.split('.');
        var nodeId = pathlist[0].slice(1);
        var relpath = pathlist.slice(1).join('.');
        if(nodeId in genro._aliasDatapaths){
            return genro._aliasDatapaths[nodeId]+'.'+relpath;
        }
        if(nodeId=='ROW'){
            return this.widget?this.widget.cellCurrentDatapath(path):null;
        }
        if(nodeId=='WORKSPACE'){
            var node=this.attributeOwnerNode('_workspace');
            genro.assert(node,'with WORKSPACE path you need an ancestor node with attribute _workspace');
            if(node.attr._workspace_path){
                return node.absDatapath(node.attr._workspace_path)+'.'+relpath;
            }
            var wsname = node.attr._workspace===true?(node.attr.nodeId || (node.attr.tag+'_'+node.getPathId())):node.attr._workspace;
            return 'gnr.workspace.'+wsname+'.'+relpath;
        }
        if(nodeId=='DATA'){
            return relpath;
        }
        var currNode = this.nodeById(nodeId); 
        if (!currNode) {
            console.error('not existing nodeId:' + nodeId);
        }
       
        if(relpath=='*S'){
            return currNode.getFullpath().replace('main.','*S.');
        }
        path = currNode.absDatapath(relpath ? '.' + relpath : '');
        return path;

    },
    absDatapath: function(path) {
        path = path || '';
        if (this.isPointerPath(path)) {
            path = path.slice(1);
        }
        if (path.indexOf('#') === 0) {
            return this.symbolicDatapath(path);
        }
        if(path=='.'){
            return this.absDatapath();
        }
        var currNode = this;
        var datapath;
        while (currNode && ((!path) || path.indexOf('.') == 0)) {
            datapath = currNode.attr.datapath;
            if(typeof(datapath)=='function'){
                datapath = datapath.call(currNode,datapath);
            }
            if (datapath) {
                if (this.isPointerPath(datapath)) {
                    datapath = currNode.getAttributeFromDatasource('datapath');
                    if (!datapath) {
                        return null;
                    }
                }
                if (datapath.indexOf('#') == 0) {
                    datapath = currNode.symbolicDatapath(datapath);
                }
                path = datapath + path;
            }
            currNode = currNode.getParentNode();
        }
        if (path.indexOf('.') == 0) {
            console.error('unresolved relativepath ' + path);
            if (genro.isDeveloper) {
                debugger;
            }
        }
        path = path.replace('.?', '?');
        if (path.indexOf('#parent') > 0) {
            path = gnr.bagRealPath(path);
        }
        return path;
    },


    onHelperClick:function(helperButtonNode){
        if(genro.isDeveloper && genro.getData('gnr.developerToolsVisible')){
            var dflt = this.getHelperValue()
            var that = this;
            genro.dlg.prompt(_T('Edit help'),{
                widget:'simpleTextArea',wdg_height:'200px',wdg_margin_right:'10px',
                action:function(value){
                    that.saveHelper(value);
                },dflt:dflt,onEnter:null});
        }else{
            let helperValue = this.getHelperValue()
        }
    },
    saveHelper:function(value,custom){
        let inAttr = this.getInheritedAttributes();
        custom = custom===false?false:inAttr.resourceClass!==null;
        let table = inAttr.table;
        let kw = {table:table || genro.getData('gnr.pagename'),value:value,helpcode:this.attr.helpcode,customizationPackage:this.attr.helpcode_package};
        if (table && custom){
            kw.name = `th_${table.split('.')[1]}_${inAttr.resourceClass}`;
        }
        genro.setData(this.getHelperPath(custom),value)
        this.updateHelperClasses(custom);
        genro.serverCall('saveHelperValue',kw,function(){
        });
    },

    updateHelperClasses:function(){
        let helperValue = this.getHelperValue();
        genro.dom.setClass(this,'emptyhelper',!helperValue);
    },

    getHelperValue:function(){
        let inAttr = this.getInheritedAttributes();
        let table = inAttr.table;
        let defaultValue = this.getRelativeData(this.getHelperPath())
        if(table && inAttr.resourceClass){
            return this.getRelativeData(this.getHelperPath(true)) || defaultValue;
        }
        return defaultValue;
    },

    getHelperPath:function(custom){
        let helpcode = this.attr.helpcode;
        return `gnr.helpers.${this.getHelperFolder(custom)}.${helpcode}?${genro.getData('gnr.language')}`;
    },

    getHelperFolder:function(custom){
        let inAttr = this.getInheritedAttributes();
        let table = inAttr['table'];
        let resourceClass = inAttr.resourceClass;
        if(table){
            let tablename = table.split('.')[1];
            if(custom){
                return `${table}.th_${tablename}_${resourceClass}`;
            }
            return `${table}.tbl_${tablename}`;
        }
        return genro.getData('gnr.pagename');
    },

    connect: function(target, eventname, handler) {
        var eventname = ((!eventname) || eventname == 'action') ? target.gnr._defaultEvent : eventname;
        var handler = dojo.hitch(this, funcCreate(handler));
        //var that=this;
       //var h = handler;
       //var handler = function(evt){
       //    funcApply(h, objectUpdate({evt:evt},that.currentAttributes()),that,['evt'],[evt]);
       //}        
        
       if (target.domNode) {/* connect to a widget*/
            if (eventname in target) {
                dojo.connect(target, eventname, handler);
            } else {
                dojo.connect(target.domNode, eventname, handler);
            }
        }
        else {/* connect to a domnode*/
            dojo.connect(target, eventname, handler);
        }
    },
    updateContent: function(kw) {
        if (this._resolver) {
            var mode = kw ? 'reload' : null;
            this.getValue(mode, kw);
            this.widget.resize();
        }
    },
    setRemoteContent:function(kwargs) {
        kwargs.sync = ('sync' in kwargs) ? kwargs.sync : true;
        var cacheTime = objectPop(kwargs, 'cacheTime');
        var resolver = new gnr.GnrRemoteResolver(kwargs, false, cacheTime);
        resolver.updateAttr = true;
        this.setResolver(resolver);
    },
    _bld_data: function() {
    },
    _bld_dataremote: function() {
    },
    _bld_dataformula: function() {
    },
    _bld_datascript: function() {
    },
    _bld_datacontroller: function() {
    },
    _bld_datarpc: function() {
        this._callbacks = this.getValue();
        this._value = null;
    },

    _bld_script: function() {
        if (this.attr.src) {
            genro.dom.loadJs(this.attr.src);
        } else {
            dojo.eval(this.getValue());
        }

    },
    _bld_stylesheet:function() {
        if (this.attr.href) {
            genro.dom.loadCss(this.attr.href, this.attr.cssTitle);
        } else {
            genro.dom.addStyleSheet(this.getValue(), this.attr.cssTitle);
        }
    },

    _bld_css:function() {
        genro.dom.addCssRule(this.getValue());
    },
    _bld_remote:function() {
        var kwargs = objectUpdate({}, this.attr);
        objectPop(kwargs, 'tag');
        this.getParentNode().setRemoteContent(kwargs);
    },

    registerDynAttr: function(attr) {
        this._dynattr = this._dynattr || {};
        this._dynattr[attr] = null;
    },
    registerNodeDynAttr: function(returnCurrentValues) {
        this._resetDynAttributes();
        var attributes = {};
        var attrvalue;
        for (var attr in this.attr) {
            attrvalue = this.attr[attr];
            attributes[attr] = attrvalue;
            if ((typeof(attrvalue) == 'string') && this.isPointerPath(attrvalue)) {
                if ((attrvalue.indexOf('^') == 0)) {
                    this.registerDynAttr(attr);
                }
                if (returnCurrentValues) {
                    attributes[attr] = this.getAttributeFromDatasource(attr);
                }
                if(attrvalue.indexOf('==')==0){
                    this._formulaAttributes = this._formulaAttributes || {};
                    this._formulaAttributes[attr] = attrvalue.slice(2);
                }
            }
        }
        return attributes;
    },
    onNodeCall:function(func,kw){
        kw = objectUpdate(objectUpdate({},this.attr),kw); 
        return funcApply(func,this.evaluateOnNode(kw),this);
    },
    
    evaluateOnNode: function(pardict,filterCb) {
        // given an object representing dynamic parameters
        // get current values relative to this node
        // eg. values starting with ^. are datapath relative to the current node
        var result = {};
        for (var attr in pardict) {
            var v = pardict[attr];
            if(filterCb && typeof(v)=='string' && this.isPointerPath(v) && !filterCb(v)){
                result[attr] = v;
            }else{
                result[attr] = this.currentFromDatasource(v);
            }
            
        }
        return result;
    },

    normalizeKwargs:function(str){
        return this.evaluateOnNode(normalizeKwargs(objectUpdate({},this.attr),str));
    },

    currentAttributes: function() {
        var attributes = {};
        for (var attr in this.attr) {
            attributes[attr] = this.getAttributeFromDatasource(attr);
        }
        return attributes;
    },
    rebuild: function() {
        this.setValue(this._value);
    },
    build: function(destination, ind) {
        genro.src.stripData(this);
        if(this.attr._attachPoint){
            var _attachPoint = this.attr._attachPoint.split('.');
            while (_attachPoint.length>0){
                destination = destination[_attachPoint.shift()];
            }
        }
        if (!this.attr.tag) {
            //console.warn('notag in build domsource',arguments.callee);
            this._buildChildren(destination);
            return;
        }
        var handler=genro.wdg.getHandler(this.attr.tag);
        if(handler && handler._onBuilding){
            handler._onBuilding(this);
        }
        if(this.attr.parentForm===false){
            this.form = null;
        }else{
            this._registerInForm();
        }
        this._isBuilding = true;
        try{
            var aux = '_bld_' + this.attr.tag.toLowerCase();
            if (aux in this) {
                this[aux].call(this);
            }else{
                var attributes = this.registerNodeDynAttr(true);
                this._appliedClass = attributes._class;
                var tag=objectPop(attributes,'tag');
                this._doBuildNode(tag, attributes, destination, ind);
                this._setDynAttributes();
            }
        }finally{
            //left set, nodeTrigger would ignore this node from now on
            this._isBuilding = false;
        }
    },
    _buildChildren: function(destination) {
        if (this.attr.remote) {
            var that = this;
            this.watch('isVisibile',function(){return genro.dom.isVisible(that);},function(){
                setTimeout(function(){
                    that.updateRemoteContent();
                },1);
            });
        }
        var content = this.getValue('static');
        if (content instanceof gnr.GnrDomSource) {
            content.forEach(function(node){
                node.buildLblWrapper();
                node.build(destination, -1);
            },'static');
        }
    },
    _registerInForm:function(){
        var formHandler = this.getFormHandler();
        if(formHandler){
            this.form = formHandler;
            if(this.attr.parentForm!==false){
                formHandler.registerChild(this);
                genro.src.formsToUpdate[this.form.formId]=this.form;
            }
        }else if(typeof(this.attr.parentForm)!='string'){
            //cache the negative result too: descendants stop at this node
            //instead of walking the whole ancestor chain again
            this.form = null;
        }
    },
    _registerNodeId: function(nodeId) {
        nodeId = this.attr.nodeId || nodeId;
        if (nodeId) {
            var reg_node = genro.src._index[nodeId];
            if(reg_node){
                genro.assert(reg_node===this,'duplicate nodeId:'+nodeId);

            }
            genro.src._index[nodeId] = this;
        }
    },
    _onDeleting:function(){
        if(this.form){
            this.form.unregisterChild(this);
        }
        if (this._timing){
            clearInterval(this._timing);
        }
        if(this._shortcuts){
            this._shortcuts.forEach(function(kw){
                var args = kw.args;
                kw.element.removeEventListener(args[0],args[1],args[2]);
            });
        }
        if(this.watches){
            for(var w in this.watches){
                var interval = this.watches[w];
                if(interval){
                    clearInterval(interval);
                }
            }
        }
    
    },
    
    _doBuildNode: function(tag, attributes, destination, ind) {
        var bld_attrs = objectExtract(attributes, 'onCreated,gnrId,tooltip,nodeId');
        var connections = objectExtract(attributes, 'connect_*');
        if (objectPop(attributes, 'autofocus')) {
            attributes.subscribe_onPageStart = "this.widget.focus()";
        }
        var subscriptions = objectExtract(attributes, 'subscribe_*');
        var selfsubscription = objectExtract(attributes, 'selfsubscribe_*');
        var formsubscription = objectExtract(attributes, 'formsubscribe_*');
        
        var attrname;
        ind = ind || 0;
        var newobj = genro.wdg.create(tag, destination, attributes, ind, this);
        for (var selfsubscribe in selfsubscription){
            this.subscribe(selfsubscribe,selfsubscription[selfsubscribe]);
        }
        if(this.form){
            var topic_pref = 'form_'+this.form.formId+'_';
            for (var formsubscribe in formsubscription){
                subscriptions[topic_pref+formsubscribe] = formsubscription[formsubscribe];
            }
        }

        if (newobj === false) {
            this._buildChildren(destination);
            return;
        }
        if (bld_attrs.onCreated) {
            funcCreate(bld_attrs.onCreated, 'widget,attributes').call(this, newobj, attributes);
        }
        this._registerNodeId(bld_attrs.nodeId);
        if (bld_attrs.gnrId) {
            this.setGnrId(bld_attrs.gnrId, newobj);
        }

        for (var eventname in connections) {
            this.connect(newobj, eventname, connections[eventname]);
        }
        for (var subscription in subscriptions) {
            var handler = funcCreate(subscriptions[subscription]);
            this.registerSubscription(subscription, this, handler);
        }
        if (this.attr._lazyBuild){
            var that = this;
            var cbtest;
            cbtest= function(){
                return genro.dom.isVisible(that) || that._buildNow;
            }
            this.watch('lazyBuildWait',cbtest,
                    function(){
                        that.lazyBuildFinalize(newobj);
                    });
        }else{
            this._buildChildren(newobj);
        }
        if ('startup' in newobj) {
            newobj.startup();
        }
        if ((typeof(this.attr.value) == 'string') && (this.isPointerPath(this.attr.value))) {
            newobj.gnr.connectChangeEvent(newobj);
        }

        if (bld_attrs.tooltip) {
            genro.wdg.create('tooltip', null, {label:bld_attrs.tooltip,tooltip_type:'help'}).connectOneNode(newobj.domNode || newobj);
        }
        if (genro.src._started && this.widget){
            var validations = objectExtract(this.attr, 'validate_*',true);
            if (this.validationsOnChange && objectNotEmpty(validations)){
                this.resetValidationError();
                var newval = this.validationsOnChange(this, attributes.value,true)['value'];
                this.updateValidationStatus();
            }
        }
        this._built = true;
        this.onNodeBuilt(newobj);
        return newobj;
    },

    buildNow:function(){
        this._buildNow=true;
    },
    
    onNodeBuilt:function(newobj){
        return;
    },
    
    delayedCall:function(cb,delay,code){
        code = code || 'delayedCall';
        var handlerName = '_dc_'+code;
        delay = delay || 1;
        if(this[handlerName]){
            clearTimeout(this[handlerName]);
        }
        this[handlerName] = setTimeout(cb,delay);
    },
    
    _resetDynAttributes : function() {
        if (this._dynattr) {
            delete this._dynattr;
        }
        var stringId = this.getStringId();
        var nodeSubscribers = genro.src._subscribedNodes[stringId];
        if (nodeSubscribers) {
            for (var attr in nodeSubscribers) {
                dojo.forEach(nodeSubscribers[attr],function(n){
                    genro.src.unsubscribeHandle(n);
                });
            }
            delete genro.src._subscribedNodes[stringId];
        }
    },
    registerSubscription:function(topic,scope,handler,reason){
        var stringId = this.getStringId();
        reason = reason || topic;
        var subDict=genro.src._subscribedNodes[stringId];
        if(!subDict){
            subDict = {};
            genro.src._subscribedNodes[stringId] = subDict;
        }
        if(!(topic in subDict)){
            subDict[reason] = [];
        }
        subDict[reason].push(dojo.subscribe(topic, scope, handler));
    },
    unregisterSubscription:function(reason){
        var stringId = this.getStringId();
        var subDict=genro.src._subscribedNodes[stringId];
        if(!subDict){
            return;
        }
        if(reason in subDict){
            var l = objectPop(subDict,reason);
            if(l){
                dojo.forEach(l,function(s){genro.src.unsubscribeHandle(s)});
            }
        }
    },
    
    _setDynAttributes : function() {
        var stringId = this.getStringId();
        if (this._dynattr) {
            var nodeSubscribers = genro.src._subscribedNodes[stringId] || {};
            var path,fn,prop;
            for (var attr in this._dynattr) {
                nodeSubscribers[attr] = [this._subscriptionHandle(attr)];
            }
            genro.src._subscribedNodes[stringId] = nodeSubscribers;
        }
    },
    _subscriptionHandle:function(attr) {
        return genro.src.triggerIndex.add({node:this, attr:attr},
                                          this._stableTriggerPath(attr));
    },

    _stableTriggerPath: function(attr) {
        // absolute datapath to index this ^attr subscription under, or null
        // when the resolution may change over time (the trie entry would go
        // stale): those subscriptions stay in the floating set.
        var attrvalue = this.attr[attr];
        if (typeof(attrvalue) != 'string' || attrvalue.charAt(0) != '^') {
            return null;
        }
        var path = attrvalue.slice(1);
        if (path.indexOf('#parent') >= 0) {
            return null;
        }
        var stable;
        if (path.charAt(0) == '#') {
            stable = this._stableSymbolicStart(path);
        } else if (!path || path.charAt(0) == '.') {
            stable = this._stableDatapathChain();
        } else {
            stable = true;
        }
        if (!stable) {
            return null;
        }
        var abspath = this.attrDatapath(attr);
        if (!abspath || abspath.indexOf('#') >= 0) {
            return null;
        }
        return abspath;
    },

    _stableSymbolicStart: function(path, fromChain) {
        // #FORM/#ANCHOR resolve on an ancestor node: when that ancestor
        // rebuilds, this whole subtree re-registers, so the resolution is as
        // stable as the ancestor datapath chain. Any other symbolic head
        // (#ROW, #WORKSPACE, aliases, generic nodeId) can move independently.
        var head = path.split('.')[0].slice(1);
        if (head == 'DATA') {
            return true;
        }
        var target;
        if (head.indexOf('FORM') === 0) {
            target = this.attributeOwnerNode('formId,_fakeform');
        } else if (head.indexOf('ANCHOR') === 0) {
            target = this.attributeOwnerNode('_anchor');
        } else {
            return false;
        }
        if (!target) {
            return false;
        }
        if (fromChain && target === this) {
            // symbolic datapath resolving onto its own node: resolving it would
            // recurse forever, here and in absDatapath
            console.error('self referencing symbolic datapath ' + path + ' on ' + this.getFullpath());
            return false;
        }
        return target._stableDatapathChain();
    },

    _stableDatapathChain: function() {
        var curr = this;
        while (curr) {
            var datapath = curr.attr.datapath;
            if (datapath) {
                if (typeof(datapath) != 'string' || this.isPointerPath(datapath)) {
                    return false;
                }
                if (datapath.charAt(0) == '#') {
                    if (datapath.indexOf('#parent') >= 0) {
                        return false;
                    }
                    return curr._stableSymbolicStart(datapath, true);
                }
                if (datapath.charAt(0) != '.') {
                    return true; //absolute datapath shields the upper chain
                }
            }
            curr = curr.getParentNode();
        }
        return true;
    },
    setGnrId:function(gnrId, obj) {
        var idLst = gnrId.split('.');
        var curr = genro;
        for (var i = 0; i < idLst.length - 1; i++) {
            var id = idLst[i];
            if (!curr[id]) {
                curr[id] = {};
            }
            ;
            curr = curr[id];
        }
        curr[idLst[idLst.length - 1]] = obj;
    },
    
    publish:function(msg,kw,recursive){
        var topic = (this.attr.nodeId || this.getStringId()) +'_'+msg;
        dojo.publish(topic,[kw]);
        if (recursive){
            var children =this.getValue('static');
            if (children instanceof gnr.GnrDomSource){
                children.walk(function(n){
                    if(!n._built){
                       return true;
                    }
                    n.publish(msg,kw);
                });
            }
        }
    },
    subscribe:function(command,handler,subscriberNode){
        var that=this;
        var h = handler;
        handler = function(){
            var argNames = [];
            var argValues = [];
            for (var i=0; i < arguments.length; i++) {
                argValues.push(arguments[i]);
                argNames.push('p_'+i);
            }
            funcApply(h, that.currentAttributes(),that,argNames,argValues);
        };
        var topic = (this.attr.nodeId || this.getStringId()) +'_'+command;
        subscriberNode = subscriberNode || this;
        subscriberNode.registerSubscription(topic,this,handler);
    },
    lazyBuildFinalize:function(widget){
        var content = this.getValue();
        if (content instanceof gnr.GnrBag){
            var nodes = content._nodes;
            content._nodes = [];
            dojo.forEach(nodes,function(n){
                content.setItem(n.label,n);
            });
        }
        
        //if ('onLazyContentCreated' in widget) {
        //    widget.onLazyContentCreated();
        //}
        if(this.attr._onLazyBuilt){
            funcApply(this.attr._onLazyBuilt,null,this);
        }
    },

    getFrameNode:function(){
        if(this.attr.tag.toLowerCase()=='framepane'){
            return this;
        }
        var parent = this.getParentNode();
        if(parent){
            return parent.getFrameNode();
        }
    },
    
    getFormHandler:function(){
        if ('form' in this){
            return this.form;
        }        
        else if (this.attr.parentForm){
            if(typeof(this.attr.parentForm)=='string'){
                return genro.formById(this.attr.parentForm);
            }
        }
        
        var parent = this.getParentNode();
        if (parent) {
            return parent.getFormHandler();
        }else if (genro.parentIframeSourceNode){
            return genro.parentIframeSourceNode.getFormHandler();
        }
    },
    
    inheritedAttribute:function(attr){
        var node = this.attributeOwnerNode(attr);
        if(node){
            return node.getAttributeFromDatasource(attr);
        }
    },
    
    setHiderLayer:function(set,kw){
        if(!set){
            this.unwatch('isVisibile');
            this.getValue().popNode('hiderNode');
        }else if (!this.getValue().getNode('hiderNode')){
            var that = this;
            this.watch('isVisibile',
                        function(){return genro.dom.isVisible(that);},
                        function(){genro.dom.makeHiderLayer(that,kw);});
        }        
    },

    updateAttrBuiltObj:function(attr, kw, trigger_reason) {
        var re= new RegExp('\\b'+attr+'\\b');
        var isInFormula = false;
        if(this._formulaAttributes){
            for(var formulaAttribute in this._formulaAttributes){
                if(this._formulaAttributes[formulaAttribute].match(re)){
                    this.doUpdateAttrBuiltObj(formulaAttribute,kw,trigger_reason);
                    isInFormula = true;
                }
            }
        }
        if (!isInFormula){
            this.doUpdateAttrBuiltObj(attr,kw,trigger_reason);
        }

    },
    doUpdateAttrBuiltObj:function(attr, kw, trigger_reason) {
        if(stringStartsWith(attr,'attr_')){
            var valuepath = this.attr.value || this.attr.src ||this.attr.innerHTML;
            if(valuepath){
                var updattr = {};
                updattr[attr.slice(5)] = kw.value;
                genro.getDataNode(this.absDatapath(valuepath)).updAttributes(updattr);
            }
        }
        if(this._original_attributes){
            this.setAttr(this._original_attributes,true);
            this._original_attributes=null;
        }
        var autocreate = kw.reason =='autocreate';
        attr = attr || 'value';
        var path;
        var value = null;
        var attr_lower = attr.toLowerCase();
        var valueNode = kw.node;
        if(trigger_reason=='container' && attr=='value' && kw.evt=='upd'){
            var vpath = this.attr.value;
            if (this.isPointerPath(vpath)){
                valueNode = genro._data.getNode(this.absDatapath(vpath),null,true);
                if (valueNode){
                    var wdg_prefix = vpath.indexOf('?')<0?'wdg_*':'wdg_'+vpath.split('?')[1]+'_*';
                    var wdg_modifiers = objectExtract(valueNode.attr,wdg_prefix);
                    if(objectNotEmpty(wdg_modifiers)){
                        this._original_attributes = objectUpdate({},this.attr);
                        this.updAttributes(wdg_modifiers,true);
                    }
                }
            }
        }
        // a row inserted or deleted under the bound path leaves that path in place
        if (!(kw.evt == 'ins' || kw.evt == 'del') || trigger_reason == 'child') {
            value = this.getAttributeFromDatasource(attr, true);
        }
        //value = (value != null) ? value : '';
        if(attr_lower=='disabled'){
            return this.setDisabled(value);
        }
        if (attr == 'datapath') {
            var absDatapath = this.absDatapath();
            if (absDatapath) {
                genro.fireDataTrigger(absDatapath);
            }
        }
        else if (attr == 'zoomFactor') {
            if (this.setZoomFactor) {
                this.setZoomFactor(value);
            }
        }
        else if (this.externalWidget) {
            if ('gnr_' + attr in this.externalWidget) {
                this.externalWidget['gnr_' + attr](value, kw, trigger_reason);
            }else{
                this.rebuild();
            }
            return;
        }
        else if (attr == '_class') {
            var oldvalue = ('oldvalue' in kw) ? kw.oldvalue : kw.changedAttr ? kw.oldattr[kw.changedAttr] : null;

            var domnode;
            if (this.widget) {
                domnode = this.widget.domNode;
            }
            else {
                domnode = this.domNode;
            }
            if (this._appliedClass !== undefined) {
                genro.dom.removeClass(domnode, this._appliedClass);
            }
            else if (oldvalue) {
                var old_class;
                if (oldvalue instanceof gnr.GnrBag) {
                    var q = kw.pathlist.length;
                    var p = this.absDatapath(this.attr._class).split('.').slice(q - 1);
                    old_class = oldvalue.getItem(p.join('.'));
                } else {
                    old_class = oldvalue;
                }
                genro.dom.removeClass(domnode, old_class);
            }
            genro.dom.addClass(domnode, value);
            this._appliedClass = value;
        }
        else if (attr=='style'){
            genro.dom.style(this,value);
        }
        else if (attr=='placeholder'){
            (this.widget? this.widget.focusNode:this.domNode).setAttribute('placeholder',value || '');
        }
        else if (attr.indexOf('remote_') === 0) {
            this.updateRemoteContent(this);
        }
        else if (this.widget) {
            /* if(attr.indexOf('remote_')==0){
             this.updateRemoteContent(this);
             }*/
            if (attr.indexOf('__') === 0) {
                return;
            }
            else if (attr_lower == 'readonly') {
                this.widget.setAttribute(attr, value ? true : false);
            }
            else if ((attr == 'storepath') && (this.attr.storepath.indexOf('^') == 0)) {
                this.rebuild();
            }
            else if (attr.indexOf('validate_') === 0) {
                //this.validationsOnChange(this, this.getAttributeFromDatasource('value'));
                if ((trigger_reason == 'node') || (kw.reason=='resolver')){
                    this.resetValidationError();
                    var currval = this.getAttributeFromDatasource('value');
                    var newval = this.validationsOnChange(this, currval,true)['value'];
                    this.updateValidationStatus();
                    this.setAttributeInDatasource('value', newval);
                }
            }else if (attr.indexOf('condition_') === 0){
                if('setCondition' in this.widget){
                    if ((trigger_reason == 'node') || (kw.reason=='resolver')){
                        this.widget.setCondition(value,kw);
                    }
                }
            }
            else {
                var setter = 'set' + stringCapitalize(attr);
                if(!(setter in this.widget)){
                    setter = 'catch_'+attr.split('_')[0];
                }
                if (setter in this.widget) {
                    var trgevt = kw.evt;
                    if (attr != 'value') {
                        dojo.hitch(this.widget, setter)(value, kw, attr);
                        return;
                    }
                    var formHandler = this.getFormHandler();

                    this.resetValidationError();     // reset validationError when data from bag is set in widget
                    if(formHandler && trigger_reason=='container' && this.attr.default_value && formHandler.isNewRecord() && (value==null) ){
                        value = this.attr.default_value;
                    }
                    if ('_lastValueReported' in this.widget) {    // VERIFICARE DOJO 1.2
                        this.widget._lastValueReported = value; // see dijit.form._formWidget setValue
                    }                                           // force _lastValueReported to get onChange event
                    kw = false;
                    if (this.attr['protected']) {
                        var parentAttr = this.getRelativeData('.?');
                        if ('_newrecord' in parentAttr) {
                            if(!parentAttr['_newrecord']){
                                this.widget.setAttribute('readOnly', true);
                                var wdg = this.widget;
                                dojo.connect(wdg.domNode,'ondblclick',function(e){
                                    wdg.setAttribute('readOnly',false);
                                });
                                dojo.connect(wdg,'onBlur',function(){
                                    wdg.setAttribute('readOnly',true);
                                });
                            }
                        }
                    }
                    if(!this.widget._ignoreDataChanges){
                        this.widget.setValue(value,kw);
                    }
                    if (trgevt != 'del') {
                        if(this.hasValidations()){
                            var formHandler = this.getFormHandler();
                            if (formHandler && !autocreate) {
                                formHandler.validateFromDatasource(this, value, trigger_reason);
                            }
                        }
                        var valueAttr = valueNode?valueNode.attr:null;
                        var sourceNodeValueAttr = objectExtract(this.attr,'attr_*',true);
                        if(objectNotEmpty(sourceNodeValueAttr)){
                            objectUpdate(valueAttr,this.evaluateOnNode(sourceNodeValueAttr));
                        }
                        if(this.attr.format || this.attr.mask){
                            var valueToFormat = value;
                            var nattr = this.currentAttributes();
                            if(this.widget.getDisplayedValue){
                                var _displayedValue = this.widget.getDisplayedValue();
                                if(_displayedValue!=value){
                                    if(isNullOrBlank(_displayedValue) && isNullOrBlank(value)){
                                        delete valueAttr._displayedValue;
                                    }else{
                                        valueAttr['_displayedValue'] = _displayedValue;
                                    }
                                }
                                if(typeof(value)=='string' || nattr.dtype=='T'){
                                    valueToFormat = _displayedValue;
                                }
                            }
                            valueNode.updAttributes({_formattedValue:genro.formatter.asText(valueToFormat, nattr)},this);
                        }

                    }
                } 
                else if (genro.dom.isStyleAttr(attr)) {
                    this.widget.domNode.setAttribute('style',objectAsStyle(genro.dom.getStyleDict(this.currentAttributes())));
                }
                
                
                else {
                    this.rebuild();
                }
            }
        }
        else if (this.domNode) {
            var domnode = this.domNode;
            var setter = 'set' + stringCapitalize(attr);
            if (setter in domnode.gnr) {
                dojo.hitch(domnode.gnr, setter)(domnode, value, kw);
            }
            else if (attr == 'visible') {
                dojo.style(domnode, 'visibility', (value ? 'visible' : 'hidden'));
                return;
            }
            else if (attr == 'hidden') {
                this.setHidden(value);
                return;
            }
            else if (attr == 'value') {
                if ('value' in domnode) {
                    domnode.value = value;
                }
                else {
                    //genro.debug('unable to use datasource for node:'+this.getFullpath());
                }
            }
            else if (attr == 'innerHTML') {
                domnode.innerHTML = value;
            }
            else if ( ('template' in this.attr) && ( (attr == 'datasource') || attr.indexOf('tpl_')==0 )) {
                var ih = dataTemplate(this.getAttributeFromDatasource('template'), this, this.attr.datasource);
                if(this.isPointerPath(this.attr.innerHTML)){
                    this.setRelativeData(this.attr.innerHTML,ih);
                }else{
                    this.domNode.innerHTML = ih;
                }
            }
            else if (genro.dom.isStyleAttr(attr)) {
                genro.dom.style(domnode,genro.dom.getStyleDict(this.currentAttributes()));
                //domnode.setAttribute('style',objectAsStyle(genro.dom.getStyleDict(this.currentAttributes())));
            }
            else if (attr in domnode){
                domnode[attr] = value;
            }
            else {
                var attrdict = {};
                this.setAttr(attrdict, this, true);
                //this.setAttr({attr:value}, this, true);

                //domnode.setAttribute(attr,value);
            }
        }else if(this.gnrwdg){
            var handler = this.gnrwdg['set' + stringCapitalize(attr)];
            if(!handler && (attr in this.gnrwdg['catchers'])){
                handler = this.gnrwdg[this.gnrwdg['catchers'][attr]];
            }
            if(handler){
                handler.call(this.gnrwdg,value,kw,trigger_reason);
            }
        }
    },
    
    _dataControllerSubscription:function(subscriptions){
        for (var subscription in subscriptions) {
            var cb = function(node, trigger_reason) {
                    var reason = trigger_reason;
                    node.registerSubscription(subscription, node, function() {
                        node.setDataNodeValue(null, {}, reason, arguments);
                    });
                };
            cb(this, subscription);
        }
    },
    setTiming:function(timing) {
        if (this._timing) {
            clearInterval(this._timing);
        }
        if (timing > 0) {
            var timerFunc = dojo.hitch(this, 'setDataNodeValue');
            this._timing = setInterval(timerFunc, timing * 1000);
        }

    },
    
    setHidden:function(hidden,_fromGroup){
        let labelWrapper = this.getLabelWrapper();
        if(labelWrapper){
            labelWrapper.setHidden(hidden);
        }
        // the table formbuilder collects the group cells in _hiddenTargets; a formlet
        // has no cells, so the members are its siblings carrying the same hiddenGroup
        if(!_fromGroup && this.attr.hiddenGroup && !this._hiddenTargets){
            this._setHiddenGroup(hidden,labelWrapper);
        }
        var parent = this.widget && this.widget.parentBorderContainer;
        var animatedRegion = parent && parent._drawerAnimations &&
                parent._drawerAnimations[this.widget.region];
        if (animatedRegion) {
            parent._stopDrawerAnimation(this.widget.region, true);
        }
        var targets = this._hiddenTargets || [this.domNode || this.widget.domNode];
        var statusChanged = false;
        targets.forEach(function(domNode){
            let wasHidden = domNode.style.display === 'none';
            let prevHeight = domNode.offsetHeight;
            domNode.style.display = hidden ? 'none' : '';
            if(wasHidden !== hidden && domNode.offsetHeight !== prevHeight){
                statusChanged = true;
            }
        });
        if (animatedRegion) {
            parent._layoutChildren(this.widget.region);
        }
        if(statusChanged){
            genro.fakeResize()
        }
    },
    
    _setHiddenGroup:function(hidden,labelWrapper){
        let own = labelWrapper || this;
        let container = own.getParentNode();
        let siblings = container && container.getValue('static');
        if(!(siblings instanceof gnr.GnrDomSource)){
            return;
        }
        for(let node of siblings.getNodes()){
            // a labeled member is hidden through its labledbox, which holds the whole cell
            let memberAttr = (node._contentNode || node).attr;
            if(node!==own && memberAttr.hiddenGroup===this.attr.hiddenGroup && (node.domNode || node.widget)){
                node.setHidden(hidden,true);
            }
        }
    },

    updateRemoteContent:function(forceUpdate,async) {
        var _onRemote = false;
        var currentValue = this.getValue('static');
        if (currentValue && currentValue.len() > 0 && !forceUpdate) {
            return;
        }
        if(this._remotebuilding){
          //a dyn attr changed while a remote fetch is in flight: remember
          //it, the running call re-fetches on landing with fresh attrs
          this._pendingRemoteUpdate = true;
          return;
        }
        //taken before anything that can re-enter: a sync rpc on the way
        //(_T below) lets dojo deliver an async response whose triggers
        //would otherwise start a second fetch racing this one
        this._remotebuilding = true;
        try{
            var remoteAttr = this.evaluateOnNode(objectExtract(this.attr,'remote_*',true));
            async = objectPop(remoteAttr,'_async',async);
            if(this._lastRemoteAttr && this.attr._cachedRemote && objectIsEqual(this._lastRemoteAttr,remoteAttr)){
                return this._releaseRemoteUpdate(async);
            }
            this._lastRemoteAttr = remoteAttr;
            if(remoteAttr._if){
                var condition = funcApply('return (' + remoteAttr._if + ')',remoteAttr,this);
                if(!condition){
                    if ('_else' in remoteAttr){
                        var elseval=remoteAttr._else;
                        if (elseval && typeof(elseval)=='string'){
                            elseval=funcCreate(elseval).call(this);
                        }
                        this.mergeRemoteContent(elseval);
                    }
                    return this._releaseRemoteUpdate(async);
                }
            }
            var kwargs = {};
            for (var attrname in remoteAttr) {
                var value = remoteAttr[attrname];
                if (value instanceof Date) {
                    var abspath = this.absDatapath(this.attr['remote_'+attrname]);
                    var node = genro._data.getNode(abspath);
                    value = asTypedTxt(value, node.attr.dtype);
                }
                if (attrname.indexOf('_') != 0) {
                    kwargs[attrname] = value;
                } else if (attrname == '_onRemote') {
                    _onRemote = funcCreate(value, attrname._onRemote, this);
                }
            }
            var method = this.attr.remote;
            var that = this;
            kwargs.sync = !async;
            if(objectPop(remoteAttr,'sendInheritedAttributes')){
                kwargs._inheritedAttributes = this.getInheritedAttributes();
            }
        
            if(remoteAttr._waitingMessage){
                var waitingMessage = remoteAttr._waitingMessage===true?_T('Loading content'):remoteAttr._waitingMessage;
                waitingMessage = '<div style="height:130px;opacity:.8;" class="waiting"></div>'+'<div style="font-size:13px">'+waitingMessage+'</div>'
                this.setHiderLayer(true,{message:waitingMessage});
                kwargs.sync = false;
            }
            return genro.rpc.remoteCall(method, kwargs, null, 'POST', null,
                function(result) {
                    //that.setValue(result);
                    if(result.error){
                        genro.dlg.alert('Error in remote '+result.error,'Error');
                    }else{
                        that.watch('checkPendingRequirs',function(){
                            return !objectNotEmpty(genro.dom.pendingHeaders);
                        },function(){
                            if(remoteAttr._waitingMessage){
                                that.setHiderLayer(false);
                            }
                            var t0 = new Date();
                            //console.log('before building dom');
                            that.mergeRemoteContent(result);
                            //console.log('after building dom stuck time',new Date()-t0);
                            if (_onRemote) {
                                _onRemote();
                            }
                            genro.fakeResize();
                        });
                    }
                    that._releaseRemoteUpdate(async);
                    return result;
                });
        }catch(e){
            this._releaseRemoteUpdate(async);
            throw e;
        }
    },

    _releaseRemoteUpdate:function(async){
        delete this._remotebuilding;
        if(this._pendingRemoteUpdate){
            delete this._pendingRemoteUpdate;
            this.updateRemoteContent(true,async);
        }
    },

    getValidationError: function() {
        if (this._validations) {
            return this._validations.error;
        }
    },
    getValidationWarnings: function() {
        if (this._validations) {
            return this._validations.warnings;
        }
    },
    isValidationRequired: function() {
        if ((this._validations) && (this._validations.required)) {
            return true;
        }
    },
    hasValidationWarnings: function() {
        if ((this._validations) && (objectNotEmpty(this._validations.warnings))) {
            return true;
        }
    },
    hasValidationError: function() {
        if ((this._validations) && (this._validations.error)) {
            return true;
        }
    },
    resetValidationError: function() {
        if (this._validations) {
            this._validations.error = null;
            this._validations.warnings = [];
            this._validations.required = null;
            this.updateValidationClasses();
        }
    },
    setValidationError: function(validation_result) {
        this._validations.error = validation_result.error;
        this._validations.warnings = validation_result.warnings;
        this._validations.required = validation_result.required;
        this.updateValidationClasses();
    },

    setValidations: function() {
        this._validations = {};
    },

    hasValidations: function() {
        if (this._validations) {
            return true;
        }
    },
    getElementLabel:function(){
        //a formlet lbl lives on the labledbox wrapper (buildLblWrapper); '&nbsp;' is its placeholder
        var wrapper = this.getLabelWrapper();
        var wrapperLabel = wrapper ? wrapper.getAttributeFromDatasource('label') : null;
        if(wrapperLabel=='&nbsp;'){
            wrapperLabel = null;
        }
        var raw = this.attr.error_label || this.attr._valuelabel || this.attr.field_name_long || this.attr.name_long || wrapperLabel || stringCapitalize(this.label);
        if(raw && raw.indexOf('<') >= 0){
            var tmp = document.createElement('div');
            tmp.innerHTML = raw;
            raw = tmp.textContent.trim();
        }
        return raw;
    },

    unwatch:function(watchId){
        if (this.watches && this.watches[watchId]){
            clearInterval(this.watches[watchId]);
            delete this.watches[watchId];
        }
    },
    
    watch: function(watchId,conditionCb,action,delay){
        delay=delay || 200;
        if(this.watches && (watchId in this.watches)){
            this.unwatch(watchId);
        }
        if (conditionCb()){
            action();
        }else{
            this.watches=this.watches || {};
            var that = this;
            this.watches[watchId] = setInterval(
                function(){
                    if (conditionCb()){
                        that.unwatch(watchId);
                        action();
                    }
            },delay);
        }
    },
    
    updateValidationStatus: function(kw) {
        if (this.isLostNode()) {
            return;
        }
        if (this.widget) {
            if(this.widget.validate){
                this.widget.validate();
            }
            this.updateValidationClasses();
            this.widget.state = this.hasValidationError() ? 'Error' : null;
            if(this.widget._setStateClass){
                this.widget._setStateClass();
            }
            if(this.form){
                this.form.updateInvalidField(this, this.attrDatapath('value'));
            }
        }
    },
    checkOnChildBuilding:function(){
        let parentNode = this.getParentNode();
        if(parentNode.widget || parentNode.domNode){
            let parentHandler = parentNode.widget?parentNode.widget.gnr : parentNode.domNode.gnr;
            if(parentHandler && parentHandler.onChildBuilding){
                parentHandler.onChildBuilding(parentNode,this);
            }
        }
    },

    buildLblWrapper:function(){
        let lbl = objectPop(this.attr,'lbl');
        if(!lbl){
            // Unlabeled action widgets in a formlet grid get an invisible
            // placeholder label (same height as the sibling labels) so they
            // line up with the field inputs. lbl=false opts out.
            if(lbl===false || !this._formletNeedsPlaceholderLbl()){
                return this;
            }
            lbl = '&nbsp;';
            this.attr.box__class = this.attr.box__class?
                this.attr.box__class+' formlet_placeholder_label' : 'formlet_placeholder_label';
        }
        let inherited_attr = this.getInheritedAttributes();
        let label_attr = {};
        let wrp_attr = objectExtract(inherited_attr,'wrp_*');
        wrp_attr._labelWrapperId = genro.time36Id();
        let attr = objectUpdate({},this.attr);
        let side = objectPop(inherited_attr,'lbl_side') || 'top';
        for(let k in attr){
            if(k.startsWith('lbl_')){
                label_attr[`label_${k.slice(4)}`] = objectPop(inherited_attr,k);
            }
        }
        label_attr.label = lbl;
        objectExtract(attr,'lbl_*');
        objectExtract(attr,'wrp_*');
        let box_l_kw = objectExtract(attr,'box_l_*',null,true);
        let box_c_kw = objectExtract(attr,'box_c_*',null,true);
        let box_kw = objectExtract(attr,'box_*');
        attr._labelWrapper = wrp_attr._labelWrapperId;
        wrp_attr.side = side;
        wrp_attr._itemId = objectPop(attr,'_itemId');
        let tag = objectPop(attr,'tag');
        let children = this.getValue();
        this._value = null;
        wrp_attr.helpcode = objectPop(attr,'helpcode');
        wrp_attr.helpcode_package = objectPop(attr,'helpcode_package')
        wrp_attr.docAddress = objectPop(attr,'docAddress');
        wrp_attr.tag = 'labledbox'
        let gridbox_itemattr = objectExtract(attr,'grid_column,grid_row,colspan,rowspan');
        this.attr = {...wrp_attr,...box_kw,...label_attr,...box_l_kw,...box_c_kw,...gridbox_itemattr};
        let original_label = this.label;
        this.label = wrp_attr._itemId || 'labled_'+original_label;
        let content = this._(tag,original_label,attr,{doTrigger:false});
        this._contentNode = content.getParentNode();
        if(children){
            for(let childNode of children.getNodes()){
                content.addItem(childNode.label,childNode.getValue(),childNode.attr,{doTrigger:false});
                childNode.setParentBag(content)
            }
        }
        return this._contentNode;
    },

    _formletNeedsPlaceholderLbl:function(){
        // Placeholder only for button-like widgets that sit as direct children
        // of a grid formlet (not formlet_wrap) with labels on top/bottom and
        // at least one labeled sibling: a buttons-only formlet keeps its
        // natural height, containers and custom tags are never wrapped.
        const placeholderTags = ['button','togglebutton','dropdownbutton','lightbutton','checkbox'];
        if(placeholderTags.indexOf((this.attr.tag||'').toLowerCase())<0){
            return false;
        }
        let parentNode = this.getParentNode();
        let parentClass = (parentNode && parentNode.attr && parentNode.attr._class) || '';
        if(!/(^|\s)formlet(\s|$)/.test(parentClass) || /(^|\s)formlet_wrap(\s|$)/.test(parentClass)){
            return false;
        }
        let side = this.getInheritedAttributes().lbl_side || 'top';
        if(side!='top' && side!='bottom'){
            return false;
        }
        // a single column formlet has no sibling on the same row to line up with
        let columns = parentNode.attr.grid_template_columns || parentNode.attr.columns || parentNode.attr.cols;
        if(isNullOrBlank(columns) || /^\s*(1|1fr|repeat\(\s*1\s*,\s*1fr\s*\))\s*$/.test(String(columns))){
            return false;
        }
        let siblings = parentNode.getValue('static');
        if(!(siblings instanceof gnr.GnrDomSource)){
            return false;
        }
        for(let node of siblings.getNodes()){
            // siblings already wrapped by buildLblWrapper have tag 'labledbox',
            // the ones still to be processed keep their lbl attribute
            if(node!==this && node.attr && (node.attr.lbl || node.attr.tag=='labledbox')){
                return true;
            }
        }
        return false;
    },

    getLabelWrapper:function(){
        if (this.attr._labelWrapper){
            return this.attributeOwnerNode('_labelWrapperId',this.attr._labelWrapper)
        }
    },

    updateValidationClasses: function() {
        let labelWrapper = this.getLabelWrapper();
        if(labelWrapper){
            genro.dom.setClass(labelWrapper,'innerLblWrapper_error',this.hasValidationError())
        }
        if (this.widget.cellNode) {
            var domnode = this.widget.cellNode;
        } else {
            var domnode = this.widget.focusNode; //(this.widget.stateNode||this.widget.domNode);
        }
        if (this.isValidationRequired()) {
            genro.dom.addClass(domnode, 'gnrrequired');
        } else {
            genro.dom.removeClass(domnode, 'gnrrequired');
        }
        this._updateErrorTooltip();
    },

    _updateErrorTooltip: function(){
        var domNode = this.widget.domNode;
        if(!domNode){
            return;
        }
        var errMsg = this._validations && this._validations.error;
        var errText = errMsg ? this._resolveErrorMessage(errMsg) : null;
        domNode._gnrErrorText = errText || null;
        if(errText){
            domNode.setAttribute('data-error', errText);
            this._bindErrorTooltipEvents(domNode);
        }else{
            domNode.removeAttribute('data-error');
            dijit.hideTooltip(domNode);
        }
    },

    _bindErrorTooltipEvents: function(domNode){
        if(domNode._gnrErrorTooltipBound){
            return;
        }
        var that = this;
        var showError = function(){
            if(!domNode._gnrErrorText){
                return;
            }
            if(!dijit._masterTT){
                dijit._masterTT = new dijit._MasterTooltip();
            }
            // the master tooltip is shared: only the error tooltip enters slower
            var fadeIn = dijit._masterTT.fadeIn;
            var duration = fadeIn.duration;
            fadeIn.duration = that._errorTooltipFade;
            dijit.showTooltip(
                '<span class="gnrErrorTooltip">' + domNode._gnrErrorText + '</span>',
                domNode
            );
            fadeIn.duration = duration;
        };
        domNode.addEventListener('mouseenter', function(){
            clearTimeout(domNode._gnrErrorTooltipTimer);
            domNode._gnrErrorTooltipTimer = setTimeout(showError, that._errorTooltipDelay);
        });
        domNode.addEventListener('mouseleave', function(){
            clearTimeout(domNode._gnrErrorTooltipTimer);
            dijit.hideTooltip(domNode);
        });
        domNode._gnrErrorTooltipBound = true;
    },

    _errorTooltipDelay: 1500,
    _errorTooltipFade: 400,

    _errorFallbacks: {
        'notnull':  '!!Required field',
        'missing':  '!!Required field',
        'error':    '!!Invalid value',
        'too long': '!!Value too long',
        'too short':'!!Value too short',
        'wrong length': '!!Wrong length',
        'query_error':  '!!Lookup error',
        'invalidItem':  '!!Invalid selection'
    },

    _resolveErrorMessage: function(errMsg){
        let msg = typeof errMsg === 'string' ? errMsg : (errMsg.msg || errMsg.toString());
        let fallback = this._errorFallbacks[msg];
        if(fallback){
            return _T(fallback);
        }
        return _T(msg.indexOf('!!') < 0 ? '!!' + msg : msg);
    },

    isDisabled:function(){
        return this.getAttributeFromDatasource('disabled');
    },

    setDisabled:function(reason){
        var value = reason ? true : false;
        this.disabled = reason || false;
        if(this.widget){
            if (dijit.form._FormWidget.prototype.setDisabled == this.widget.setDisabled) {
                this.widget.setAttribute('disabled', value);
            } else if (this.widget.setDisabled) {
                this.widget.setDisabled(value);
            }
        }else if(this.externalWidget){
            this.externalWidget.gnr_setDisabled(value);
        }else if(this.gnrwdg && this.gnrwdg.setDisabled){
            this.gnrwdg.setDisabled(value);
        }
        else if(this.domNode){

            genro.dom.setDomNodeDisabled(this.domNode,value);
        }
    },

    setSource: function(path, /*gnr.GnrDomSource*/ source) {
        var content = this.getValue();
        var child;
        if (!content) {
            content = new gnr.GnrDomSource();
            this.setValue(content, false);
        } else {
            if (!(content instanceof gnr.GnrDomSource)) {
                this.setValue(content, false);
            }
        }
        child = content.setItem(path, source.getNodes()[0]);
        return child;
    },

    replaceContent:function(value){
        var currval = this._value;
        if(currval instanceof gnr.GnrDomSource){
            dojo.forEach(currval._nodes,function(n){
                currval.popNode(n.label);
            });
        }else{
            currval = new gnr.GnrDomSource();
            this._value = currval;
            currval.setBackRef(this, this._parentbag);
        }
        if(value){
                dojo.forEach(value._nodes,function(n){
                var node = value.popNode(n.label);
                currval.setItem(node.label,node);
            });
        }
        
    },

    mergeRemoteContent:function(value){
        var mergetable = this.attr.tag=='tbody';
        var currval = this._value;
        if(currval instanceof gnr.GnrDomSource){
            dojo.forEach(currval._nodes,function(n){
                if(!mergetable || stringStartsWith(n.label,'remote_merged_')){
                    currval.popNode(n.label);
                }
            });
        }else{
            currval = new gnr.GnrDomSource();
            this._value = currval;
            currval.setBackRef(this, this._parentbag);
        }
        if(value){
            if(mergetable){
                var valueNode = value.getNodeByAttr('tag','tbody');
                if (!valueNode){
                    return;
                }
                value = valueNode._value;
            }
            dojo.forEach(value._nodes,function(n){
                var node = value.popNode(n.label);
                var label = mergetable?'remote_merged_'+node.label:node.label;
                currval.setItem(label,node);
            });
        }
    },
    
    _ : function(tag, name, attributes, extrakw) {
        var content = this.getValue();
        var child;
        if (!(content instanceof gnr.GnrDomSource)) {
            content = new gnr.GnrDomSource();
            this.setValue(content, false);
        }
        child = content._(tag, name, attributes, extrakw);
        return child;
    },
    _destroy: function() {
        return this.getParentBag().popNode(this.label);
    },
    getChild:function(childpath){
        var v = this._value;
        if(!v || !(v.getChild)){
             var clist = childpath.split('/')
             if(clist[0]=='parent'){
                 var node = this.getParentNode().getParentNode();
                 v = node.getValue();
             }
        }
        return v.getChild(childpath);
    }

});

dojo.declare("gnr.GnrStructData", gnr.GnrBag, {
    // constructor: function(source){
    //     this._validationPrefix = 'structvalidate_';
    // }
});

dojo.declare("gnr.GnrDomSource", gnr.GnrStructData, {
    _validationPrefix: 'structvalidate_',
    _nodeFactory:gnr.GnrDomSourceNode,

    _ : function(tag, name/*optional*/, attributes/*Object*/, extrakw) {
        var tag_UpperLower = null;
        var content;
        extrakw = extrakw || {};
        tag = tag.toLowerCase();
        if (tag) {
            var tagHandler = genro.wdg.getHandler(tag);
            if(!tagHandler && this.getParentNode()){
                var parentTag = this.getParentNode().attr.tag;
                var parentTagHandler = genro.wdg.getHandler(parentTag);
                if(parentTagHandler && parentTagHandler.subtags && tag.toLowerCase() in parentTagHandler.subtags){
                    tag = parentTag.toLowerCase()+'_'+tag;
                }
            }
            if (name instanceof Object) {
                extrakw = attributes || {};
                var attributes = name || {};
                var name = '';
                if('childname' in attributes){
                    name = name || objectPop(attributes,'childname');
                }
            }
            var attributes = attributes || {};
            tag = objectPop(attributes,'tag')|| tag;
            if (attributes && ('remote' in attributes) && (attributes.remote!='remoteBuilder')) {
                if (typeof(attributes.remote)=="string"){
                attributes['remote_handler'] = attributes.remote;
                }
                else if (attributes.remote instanceof Object){
                    attributes['remote_handler'] = objectPop(attributes.remote, 'method');
                    for (var prop in attributes.remote){
                        attributes['remote_'+prop]=attributes.remote[prop];
                    };
                }
                attributes.remote = 'remoteBuilder';
            }
            name = name || '*_?';
            name = name.replace('*', tag).replace('?', this.len());
            if (attributes.content) {
                content = attributes.content;
                delete attributes.content;
            }
            if (content == null) {
                content = new gnr.GnrDomSource();
            }
            attributes.tag = tag;
            var handler=genro.wdg.getHandler(tag);
            if(handler && handler.onStructChild){
                handler.onStructChild(attributes,this);
            }
            var nIndex = this.index(name);
            if(nIndex>=0){
                this.popNode(name);
                extrakw._position = nIndex;
            }
            this.setItem(name, content, attributes, extrakw);
            return content;
        }

    },

    component: function() {
        if (this.component != null) {
            return this._component;
        } else if (this.parent != null) {
            return this.parent.component();
        }
    },
    getChild:function(childpath){
        childpath = childpath.split('/');
        var curr = this;
        var node = null;
        var childname, ownerNode;
        for (var i=0;i<childpath.length;i++){
            childname = childpath[i];
            if(!(curr instanceof gnr.GnrBag)){
                return null; //a step of the path is not a container: no child there
            }
            if (childname=='parent'){
                ownerNode = curr.getParentNode();
                node = ownerNode?ownerNode.getParentNode():null;
            }else if(childname.indexOf('#')==0){
                ownerNode = curr.getParentNode();
                node = ownerNode?ownerNode.nodeById(childname.slice(1)):null;
            }
            else{
                node = null;
                curr.forEach(function(n){
                    if(n.attr._childname==childname){
                        node = n;
                    }
                },'static');
                if(!node){
                    node = curr.walk(function(n){
                           if('_childname' in n.attr){
                               return n.attr._childname==childname?n:true;
                             }
                          },'static');
                    if(node===true){
                        node = null;
                    }
                }
            }
            if(!node){
                return null;
            }
            //every step moves into the found node, so that paths deeper than
            //one named level (e.g. 'parent/parent/r_0_l/c_0') are resolved
            curr = node.getValue();
        }
        return node;
    }
});

