/*
 *-*- coding: UTF-8 -*-
 *--------------------------------------------------------------------------
 * package       : Genro js - see LICENSE for details
 * module genro_src : Genro clientside Source Bag handler
 * Copyright (c) : 2004 - 2007 Softwell sas - Milano
 * Written by    : Giovanni Porcari, Francesco Cavazzana
 *                 Saverio Porcari, Francesco Porcari
 *--------------------------------------------------------------------------
 *This library is free software; you can redistribute it and/or
 *modify it under the terms of the GNU Lesser General Public
 *License as published by the Free Software Foundation; either
 *version 2.1 of the License, or (at your option) any later version.

 *This library is distributed in the hope that it will be useful,
 *but WITHOUT ANY WARRANTY; without even the implied warranty of
 *MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 *Lesser General Public License for more details.

 *You should have received a copy of the GNU Lesser General Public
 *License along with this library; if not, write to the Free Software
 *Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
 */


//######################## genro  #########################

dojo.declare("gnr.GnrTriggerIndex", null, {
    // Routes datastore change events to the source nodes that subscribed a
    // dynamic attribute (^path). Subscriptions resolving to a stable absolute
    // datapath are indexed in a trie keyed by the path segments, so an event
    // only reaches the nodes registered on the event path, on one of its
    // ancestors or inside its subtree. Subscriptions whose path can change
    // over time (pointer or symbolic datapaths) stay in the floating set and
    // are checked on every event, as every subscription was before.
    constructor: function() {
        this.root = this._newTrieNode(null, null);
        this.floating = new Set();
    },
    _newTrieNode: function(parent, key) {
        return {parent: parent, key: key, children: Object.create(null), subs: null};
    },
    add: function(sub, path) {
        sub._gnrTriggerIndex = true;
        if (!path) {
            this.floating.add(sub);
            return sub;
        }
        let trienode = this.root;
        for (let key of path.split('?')[0].split('.')) {
            trienode = trienode.children[key] ||
                       (trienode.children[key] = this._newTrieNode(trienode, key));
        }
        (trienode.subs = trienode.subs || []).push(sub);
        sub._trienode = trienode;
        return sub;
    },
    remove: function(sub) {
        sub._removed = true;
        let trienode = sub._trienode;
        if (!trienode) {
            this.floating.delete(sub);
            return;
        }
        sub._trienode = null;
        let i = trienode.subs.indexOf(sub);
        if (i >= 0) {
            trienode.subs.splice(i, 1);
        }
        while (trienode.parent && !(trienode.subs && trienode.subs.length) &&
               !objectNotEmpty(trienode.children)) {
            delete trienode.parent.children[trienode.key];
            trienode = trienode.parent;
        }
    },
    publish: function(kw) {
        //snapshot first: a notified node can rebuild and change subscriptions
        let targets = [...this.floating];
        let trienode = this.root;
        let pathlist = kw.pathlist; //first segment is the datastore root 'main'
        for (let i = 1; i < pathlist.length && trienode; i++) {
            if (trienode.subs) {
                targets.push(...trienode.subs);
            }
            trienode = trienode.children[pathlist[i]];
        }
        if (trienode) {
            this._collect(trienode, targets);
        }
        for (let sub of targets) {
            if (sub._removed) {
                continue;
            }
            if (sub.node.isLostNode()) {
                console.error('trigger index: subscription of a discarded source node',
                              sub.node.attr.tag, sub.attr, this._subPath(sub));
                this.remove(sub);
                continue;
            }
            sub.node.trigger_data(sub.attr, kw);
        }
    },
    _subPath: function(sub) {
        let keys = [];
        for (let trienode = sub._trienode; trienode && trienode.parent; trienode = trienode.parent) {
            keys.unshift(trienode.key);
        }
        return keys.length ? keys.join('.') : null;
    },
    _collect: function(trienode, targets) {
        if (trienode.subs) {
            targets.push(...trienode.subs);
        }
        for (let key in trienode.children) {
            this._collect(trienode.children[key], targets);
        }
    }
});

dojo.declare("gnr.GnrSrcHandler", null, {

    constructor: function(application) {
        this.triggerIndex = new gnr.GnrTriggerIndex();
        this.application = application;
        //this.builder = new gnr.GnrDomBuilder(this);
        this._main = new gnr.GnrDomSource();
        this._main.application = this.application;
        this._main.setBackRef();
        this._main.subscribe('sourceTriggers', {'any':dojo.hitch(this, "nodeTrigger")});
        this._subscribedNodes = {};
        this._started=false;
        this._index = {};
        this.pendingBuild = [];
        this.afterBuildCalls = [];
        this.building = false;
        this.datatags = {'data':null,'dataformula':null,'datascript':null,
            'datarpc':null,'dataremote':null,'datacontroller':null};
        this.layouttags = {'contentpane':null,'bordercontainer':null,'stackcontainer':null,
            'tabcontainer':null,'accordioncontainer':null,'newincludedview':null,'framepane':null};
        this.highlightedNode = null;

    },
    getMainSource:function(cb){
        return genro.rpc.remoteCall('main',objectUpdate({timeout:50000},genro.startArgs), 'bag',null,null,cb);
    },


    updatePageSource:function(nodeId){
        nodeId = nodeId || '_pageRoot';
        this.getMainSource(function(newpage){
            var newcontent = newpage._value.getNodeByAttr('nodeId',nodeId);
            genro.nodeById(nodeId).mergeRemoteContent(newcontent.getValue());
        });
    },

    highlightNode:function(sourceNode) {
        if (typeof(sourceNode) == 'string') {
            sourceNode = this.sourceRoot.getValue().getNode(sourceNode);
        }
        if (this.highlightedNode) {
            domnode = this.highlightedNode.getDomNode();
            if (domnode) {
                genro.dom.removeClass(domnode, 'gnrhighlight');
            }
        }
        this.highlightedNode = sourceNode;
        if (sourceNode) {
            domnode = this.highlightedNode.getDomNode();
            if (domnode) {
                genro.dom.addClass(domnode, 'gnrhighlight');
            }
        }
    },
    onBuiltCall:function(cb,delay){
        if(delay){
            delay = typeof(delay) == 'number'?delay:1;
        }
        this.afterBuildCalls.push(delay? function(){setTimeout(cb,delay);}:cb);
    },
    
    nodeTrigger:function(kw) {
        if (kw.node._isBuilding){
            return;
        }
        if (kw.node.isFreezed()){
            //the rebuild waits for unfreeze, but a replaced or popped content is
            //already detached: what the unfreeze rebuild cannot do for it later
            //has to happen now. The rebuild runs on the new value, so it never
            //sees this content again, and externalWidgets hang off no dijit
            //parent, so no destroyRecursive reaches them either
            if (kw.evt == 'del') {
                this.cleanupNodeSubscriptions(kw.node);
                kw.node._onDeleting();
                this._onDeletingContent(kw.node._value);
                this.deleteChildrenExternalWidget(kw.node);
                if (kw.node.externalWidget && kw.node.externalWidget.destroy) {
                    kw.node.externalWidget.destroy();
                }
            } else if (kw.evt == 'upd' && kw.oldvalue !== kw.node._value) {
                //the discarded content only: this node is not dying, it is
                //frozen and rebuilds on unfreeze, and tearing it down here
                //would take it off screen before that
                this.cleanupContentSubscriptions(kw.oldvalue);
                this._onDeletingContent(kw.oldvalue);
                this.deleteContentExternalWidget(kw.oldvalue);
            }
            return;
        }
        this.pendingBuild.push(kw);
        if (!this.building) {
            this.building = true;
            while (this.pendingBuild.length > 0) {
                kw = this.pendingBuild.pop();
                try {
                    dojo.hitch(this, '_trigger_' + kw.evt)(kw);
                } catch (e) {
                    //the queue holds the work of other callers too: a failed
                    //build must not stop it, nor leave building set for the
                    //whole page. Rethrown on its own it stays an uncaught error
                    setTimeout(function() { throw e; }, 0);
                }
            }
            this.building = false;
        }
    },
    _awaitsBuild:function(sourceNode) {
        return this.pendingBuild.some(function(kw) {
            return kw.evt == 'ins' && (kw.node === sourceNode || sourceNode.isChildOf(kw.node));
        });
    },
    _trigger_ins:function(kw) {//da rivedere
        //console.log('trigger_ins',kw);
        if(kw.reason=='autocreate' || kw.node.isLostNode()){
            return;
        }
        var node = kw.node;
        var where = objectPop(node.attr, '_parentDomNode');
        if (!where) {
            var wherenode = kw.where.getParentNode();
            if (wherenode) {
                where = wherenode.widget || wherenode.domNode;
                if (!where) {
                    //queued after its parent (LIFO): the parent's build makes it
                    if (this._awaitsBuild(wherenode)) {
                        return;
                    }
                    console.error('Missing destination node in trigger_ins',kw);
                }
            } else {
                where = dojo.byId(genro.domRootName);
                node.domNode = where;
            }
        }

        var ind = kw.ind;
        this.buildNode(node, where, ind);
        if(where.onChangedContent){
            where.onChangedContent(node);
        }
        else if(where._checkIfSingleChild){
            where._checkIfSingleChild();
            where.resize();
        }
    },
    
    _trigger_upd:function(kw) {//da rivedere
        //console.log('trigger_upd',kw);
        var updatingNode = kw.node;
        //not built yet: its queued insertion builds the new value, while
        //getDomNode would hand over the first built ancestor to replace
        if (!updatingNode.widget && !updatingNode.domNode && this._awaitsBuild(updatingNode)) {
            return;
        }
        genro.assert(!updatingNode._isComponentNode);
        if (kw.oldvalue !== kw.node._value) {
            //on a same-bag rebuild the content is kept, not discarded: its
            //data* nodes are already stripped and would never resubscribe
            this.cleanupContentSubscriptions(kw.oldvalue);
        }
        updatingNode._onDeleting();
        if(updatingNode.externalWidget && updatingNode.externalWidget.destroy){
            updatingNode.externalWidget.destroy();
        }
        var destination = kw.node.getParentBuiltObj();
        if (!destination) {
            console.log('missing destination in rebuild');
        }
        this._onDeletingContent(kw.oldvalue);
        var domNode = kw.node.getDomNode();//get the domnode
        var newNode = document.createElement('div');
        var widget = kw.node.widget;
        var ind = -1;
        var selectedIndex = null;
        if (widget) {
            if (widget.sizeShare) {
                kw.node.attr.sizeShare = widget.sizeShare;
            }
            if (destination.getChildren) {
                var children = destination.getChildren();
                ind = children.indexOf(widget);
                if (destination.getSelectedIndex) {
                    selectedIndex = destination.getSelectedIndex();
                }
                if ('removeChild' in destination) {
                    destination.removeChild(widget);
                }
                this.widgetDestroyAndUnlink(widget);
                //widget.destroyRecursive();
            } else if(destination._singleChild){
                destination.destroyDescendants();
            }
            else {
                this.widgetDestroyAndUnlink(widget);
                //kw.node.widget = null;
                //widget.destroyRecursive();
                if (domNode.parentNode) {
                    domNode.parentNode.replaceChild(newNode, domNode);
                }
            }
        } else {
            if (domNode.parentNode) {
                domNode.parentNode.replaceChild(newNode, domNode);
                ind = newNode;
            }

            var widgets = dojo.query('[widgetId]', domNode);
            while (widgets.length > 0) {
                widgets = widgets.map(dijit.byNode);
                this.widgetDestroyAndUnlink(widgets[0]);
                //widgets[0].destroyRecursive();
                widgets = dojo.query('[widgetId]', domNode);
            }
            // Array
            //dojo.forEach(widgets, function(widget){ widget.destroyRecursive(); });
            while (domNode.childNodes.length > 0) {
                dojo._destroyElement(domNode.childNodes[0]);
            }
        }
        if(!kw.node._value){
            return;
        }
        this.buildNode(kw.node, destination, ind);
        if(destination._checkIfSingleChild){
            destination._checkIfSingleChild();
        }
        if (selectedIndex) {
            destination.setSelected(selectedIndex);
        }
    },

    unsubscribeHandle:function(handle){
        if (handle && handle._gnrTriggerIndex) {
            this.triggerIndex.remove(handle);
        } else {
            dojo.unsubscribe(handle);
        }
    },

    widgetDestroyAndUnlink:function(widget){
        var sourceNode = widget.sourceNode;
        if(sourceNode){
            delete sourceNode.widget;
        }
        widget.domNode = widget.domNode || {};
        widget.destroyRecursive();
    },
    
    _onDeletingContent:function(oldvalue){
        if(oldvalue instanceof gnr.GnrBag){
            oldvalue.walk(function(n){
               if(n._onDeleting){
                   n._onDeleting();
               }
            },'static');
        }
    },
    
    _trigger_del:function(kw) {//da rivedere
        var deletingNode = kw.node;
        this.cleanupNodeSubscriptions(deletingNode);
        deletingNode._onDeleting();
        if(deletingNode._isComponentNode){
            this.deleteNodeContent(deletingNode);
        }else{
            this._onDeletingContent(deletingNode._value);
            this.deleteChildrenExternalWidget(deletingNode);
            var widget = deletingNode.widget;
            var domNode = deletingNode.domNode;
            var externalWidget = deletingNode.externalWidget;
            if (widget) {
                var parentWdg = widget.getParent?widget.getParent():null;
                if(parentWdg && parentWdg.onDestroyingChild){
                    parentWdg.onDestroyingChild(widget);
                }
                if(!widget.containerNode){
                    if(deletingNode._value && deletingNode._value.len()>0){
                        this.deleteDomNodeContent(widget.domNode);
                    }
                }
                this.widgetDestroyAndUnlink(widget);
                if(parentWdg && parentWdg._checkIfSingleChild){
                    parentWdg._checkIfSingleChild();
                }
            } else if(domNode) {
                this.deleteDomNodeContent(domNode);
            }else if(deletingNode.externalWidget){
                deletingNode.externalWidget.destroy();
            }
        }
    },

    cleanupNodeSubscriptions:function(node){
        this._cleanupNodeSubscriptions(node);
        this.cleanupContentSubscriptions(node._value);
    },

    cleanupContentSubscriptions:function(content){
        if (content instanceof gnr.GnrBag) {
            var that = this;
            content.walk(function(n){
                that._cleanupNodeSubscriptions(n);
            },'static');
        }
    },

    _cleanupNodeSubscriptions:function(node){
        var subscriptions = objectPop(this._subscribedNodes, node.getStringId());
        if (subscriptions) {
            for (var reason in subscriptions) {
                dojo.forEach(subscriptions[reason], dojo.hitch(this, 'unsubscribeHandle'));
            }
        }
        var nodeId = node.attr.nodeId;
        if (nodeId && this._index[nodeId] === node) {
            delete this._index[nodeId];
        }
    },

    deleteChildrenExternalWidget:function(deletingNode){
        this.deleteContentExternalWidget(deletingNode._value);
    },
    deleteContentExternalWidget:function(content){
        if(content instanceof gnr.GnrBag && content.len()>0){
            content.walk(function(n){
                if(n.externalWidget && n.externalWidget.destroy){
                    n.externalWidget.destroy();
                }
            },'static');
        }
    },

    deleteDomNodeContent:function(domNode){
        var widgets = dojo.query('[widgetId]', domNode);
        widgets = widgets.map(dijit.byNode);     // Array
        var that = this;
        dojo.forEach(widgets, function(widget) {
            that.widgetDestroyAndUnlink(widget);
        });
        dojo._destroyElement(domNode);
    },

    deleteNodeContent:function(sourceNode){
        var children = sourceNode._value;
        children.forEach(function(n){
            children.popNode(n.label);
        })
    },
    
    
    buildNode: function(sourceNode, where, ind) {
        this.formsToUpdate={};
        this.afterBuildCalls = [];
        sourceNode.build(where, ind);
        var cb;
        while (this.afterBuildCalls.length > 0) {
            cb = this.afterBuildCalls.pop();
            cb.call();
        }
        if(genro._pageStarted){
            for (var formId in this.formsToUpdate){
                var form = this.formsToUpdate[formId];
                form.applyDisabledStatus();
            } 
        }

    },



    getSource:function(path) {
        if (path) {
            return this._main.getItem('main.' + path);
        }
        else {
            return  this._main.getItem('main');
        }


    },

    getNode:function(obj,autocreate) {
        autocreate = autocreate===false?false:true;
        if (!obj) {
            return this._main.getNode('main');
        }
        if (typeof (obj) == 'string') {
            if (obj.indexOf('main.') != 0) {
                obj = 'main.' + obj;
            }
            return this._main.getNode(obj, false, autocreate);
        }
        if (obj.declaredClass == 'gnr.GnrDomSourceNode') {
            return obj;
        }
        if (obj.sourceNode) {
            return obj.sourceNode;
        }
        if (obj.target) {
            return obj.target.sourceNode || dijit.getEnclosingWidget(obj.target).sourceNode;
        }
    },

    nodeBySourceNodeId:function(identifier) {
        return this._main.findNodeById(identifier);
    },
    newRoot:function() {
        return new gnr.GnrDomSource();
    },
    setSource:function(path, value, attributes, kw) {
        if (!attributes && (value instanceof gnr.GnrDomSource)) {
            value = value.getNodes()[0];
        }
        this._main.setItem('main.' + path, value, attributes, kw);
    },
    delSource:function(path) {
        this._main.delItem('main.' + path);
    },

    startUp:function(source) {//nome troppo generico?
        this._main.setItem('main', source);
        this.sourceRoot = source;
        this._started=true;

    },
    setInRootContainer:function(label, item) {
        alert('removed : setInRootContainer in genro_src');
    },
    enclosingSourceNode:function(item) {
        if (item.sourceNode) {
            return item.sourceNode;
        }
        if (item.widget) {
            var widget = item.widget;
        } else {
            var widget = dijit.getEnclosingWidget(item);
        }
        if (widget) {
            if (widget.sourceNode) {
                return widget.sourceNode;
            } else {
                return genro.src.enclosingSourceNode(widget.domNode.parentNode);
            }
        }
    },
    onEventCall:function(e, code, kw) {
        var sourceNode = genro.src.enclosingSourceNode(e.target);
        var func = funcCreate(code, 'kw,e', sourceNode);
        func(kw, e);
        dojo.stopEvent(e);

    },
    checkSubscribedNodes:function(){
        var subscribedNodes = this._subscribedNodes;
        for (var strid in subscribedNodes){
            var srcnode = genro.src._main.findNodeById(strid.slice(2));
            console.log(strid,srcnode,srcnode.getParentNode())
          //for (var attr in subscribedNodes[strid]) {
          //         dojo.forEach(subscribedNodes[strid][attr],function(n){
          //             console.log(n);
          //         });
          //     }
        }
        return;
    },
    stripData: function(node) {
        this.stripDataNode(node);
        var content = node.getValue('static');
        if (content instanceof gnr.GnrDomSource) {
            content.forEach(function(node){genro.src.stripDataNode(node);},'static');
        }
    },
    stripDataNode:function(node){
        if (node.attr.tag && !node._alreadyStripped) {
            if (node.attr.tag.toLowerCase() in genro.src.datatags) {
                this.moveData(node);
            }
            else {
                var nodeattr = node.attr;
                var attrvalue;
                var specialattr={}
                var dflt;
                for (var attr in nodeattr) {
                    attrvalue = nodeattr[attr];
                    if ((typeof (attrvalue) == 'string') && node.isPointerPath(attrvalue)) {
                        if (attr=='value'){
                            dflt = nodeattr['default'] || nodeattr['default_value'];
                        }else{
                            dflt = nodeattr['default_' + attr];
                        }
                        if((typeof(dflt)=='string' ) && node.attr.dtype){
                            dflt = convertFromText(dflt,node.attr.dtype);
                        }
                        var currval=node.getAttributeFromDatasource(attr, true, dflt);
                        if (!isNullOrBlank(dflt) && isNullOrBlank(currval)){
                            node.setAttributeInDatasource(attr, dflt);
                        }
                    }
                    if(attr.indexOf('attr_')==0){
                        specialattr[attr.slice(5)] = attrvalue;
                    }
                }
                if(objectNotEmpty(specialattr) ){
                    var valuepath = nodeattr['value'] || nodeattr['src'] || nodeattr['innerHTML'];
                    if(valuepath){
                        var valueNode = genro.getDataNode(node.absDatapath(valuepath));
                        if(valueNode){
                            valueNode.updAttributes(node.evaluateOnNode(specialattr));
                        }
                    }
                }                
            }
        }
        node._alreadyStripped=true;
    },
    moveData: function(node) {
        node._registerNodeId();
        var attributes = node.registerNodeDynAttr(false);
        var tag = objectPop(attributes, 'tag');
        var path = objectPop(attributes, 'path');
        var value;
        if (tag == 'data' && attributes.remote) {
            attributes['method'] = objectPop(attributes, 'remote');
            tag = 'dataRemote';
        }
        if (tag == 'data') {
            path = node.absDatapath(path);
            value = node.getValue('static');
            node._value = null;
            if (value instanceof gnr.GnrBag) {
                value.clearBackRef();
            }
            var serverpath = objectPop(attributes, 'serverpath');
            if (serverpath) {
                genro._serverstore_paths[node.absDatapath(path)] = serverpath;
            }
            var shared_id = objectPop(attributes,'shared_id');
            if(shared_id){
                var shared_kw=objectExtract(attributes,'shared_*');
                setTimeout(function(){
                    genro.som.registerSharedObject(node.absDatapath(path),shared_id,shared_kw);
                },1);
            }
            if(!genro.getDataNode(path)||(value!==null)){
                genro.setData(path, value, attributes);
            }
        } else if (tag == 'dataRemote') {
            node._dataprovider = tag;
            var isResolved = objectPop(node.attr,'_resolved');
            objectPop(attributes,'_resolved');
            if(isResolved){
                value = node.getValue('static');
                path = node.absDatapath(path);
                node._value = null;
                node._resolvedValue = value;
            }
            node.setDataNodeValue();
        } else {         
            var initialize = objectPop(attributes, '_init');
            node._dataprovider = tag;
            if (initialize) {
                node.setDataNodeValue();
            } else {
                path = node.absDatapath(path);
                genro.getDataNode(path, true);
            }
            var timing = objectPop(attributes, '_timing');

            if (timing) {
                node.setTiming(timing);
            }
            var onStart = objectPop(attributes, '_onStart');
            var onBuilt = objectPop(attributes, '_onBuilt');
            var subscriptions = objectExtract(attributes, 'subscribe_*');
            var selfsubscriptions = objectExtract(attributes, 'selfsubscribe_*');
            var formsubscriptions = objectExtract(attributes, 'formsubscribe_*');
            var nid = node.attr.nodeId || node.getStringId();
            for (var selfsubcription in selfsubscriptions){
                subscriptions[nid+'_'+selfsubcription] = selfsubscriptions[selfsubcription];
            }
            if(objectNotEmpty(formsubscriptions) || node.attr.parentForm){
                var cb = function(){
                    var form = node.getFormHandler();
                    if(form){
                        node.form = form;
                        var fid = form.formId;
                        var subscriptions = {};
                        for (var formsubcription in formsubscriptions){
                            subscriptions['form_'+fid+'_'+formsubcription] = formsubscriptions[formsubcription];
                        }
                        node._dataControllerSubscription(subscriptions);
                    }
                };
                genro.src.afterBuildCalls.push(cb);
            }
            
            node._dataControllerSubscription(subscriptions);
            
            if (onStart) {
                node.attr._fired_onStart = '^gnr.onStart';
                node.registerDynAttr('_fired_onStart');
                if (typeof(onStart) == "number" && !node.attr._delay) {
                    node.attr._delay = onStart;
                }
            }
            if(onBuilt){
                this.onBuiltCall(function(){
                    if(typeof(onBuilt)=='number'){
                        setTimeout(function(){node.setDataNodeValue();},onBuilt);
                    }else{
                        node.setDataNodeValue();
                    }
                })
            }
        }
        node._setDynAttributes();
    },
    
    dynamicParameters: function(source, sourceNode) {
        var obj = {};
        var path;
        if ((source != '') & (typeof source == 'string')) {
            source = genro.evaluate(source);
        }
        if (source) {
            sourceNode = sourceNode || objectPop(source,'_sourceNode');
            var formulaProp = [];
            for (var prop in source) {
                var val = source[prop];
                if (typeof(val) == 'string' && val.length>1) {
                    var dynval = stringStrip(val);
                    var sourceNodeKw = sourceNode?sourceNode.attr : {};
                    var toConvert = ( (dynval[0] == '=') || (dynval[0]== '^') ) && !((prop in sourceNodeKw) && (sourceNodeKw[prop]!=dynval));
                    if(toConvert){
                        if (dynval.indexOf('==') == 0) {
                            formulaProp.push(prop);
                            //val = funcApply("return "+dynval.slice(2),source,sourceNode);
                        } else {
                            path = dynval.slice(1);
                            if (sourceNode) {
                                path = sourceNode.absDatapath(path);
                            } else {
                                if (path.indexOf('.') == 0) {
                                    throw "Unresolved relative path in dynamicParameters: " + path;
                                }
                            }
                            val = genro._data.getItem(path);
                        }
                    }
                } else if (typeof(val) == 'function') {
                    val = val();
                }
                obj[prop] = val;
            }
            if(formulaProp.length>0){
                dojo.forEach(formulaProp,function(prop){
                    obj[prop] = funcApply("return "+stringStrip(source[prop]).slice(2),obj,sourceNode);
                });
            }
        }
        return obj;
    },
    create: function(widget,pars,path) {
       //var path = path || '_temp.'+this.getNode()._id;
       //var source = genro.src.getNode(path).getParentBag();
       //source.delItem('#0');
       
       //var root = genro.src.newRoot();
       return genro.src.getNode()._('div', path)._(widget,path,pars);
       //var node = genro.src.getNode(path).clearValue();
       //return node._(widget,path,pars);        
    }

});