

var genropatches = {};
genropatches.dojoXhr = function(transport){
    if(transport !== 'fetch' || genropatches.dojoXhr.installed ||
            !window.fetch || !window.AbortController || !window.DOMParser ||
            !window.URL || !window.Headers){
        return;
    }
    var original = {xhr: dojo.xhr, rawXhrPost: dojo.rawXhrPost,
                    rawXhrPut: dojo.rawXhrPut, cancelAll: dojo._ioCancelAll};
    var pending = new Set();
    var handlers = ['text', 'json', 'xml', 'javascript',
                    'json-comment-filtered', 'json-comment-optional'];

    function supported(args){
        if(args.sync || args.user || args.password || args.responseType ||
                args.onprogress || args.upload || args.iframeProxyUrl ||
                handlers.indexOf(args.handleAs || 'text') < 0){
            return false;
        }
        var form = args.form && dojo.byId(args.form);
        if(form && form.querySelector('input[type="file"]')){
            return false;
        }
        try{
            var url = new URL(args.url || (form && form.getAttribute('action')),
                              document.baseURI);
            return /^https?:$/.test(url.protocol) && !url.username && !url.password &&
                   url.origin === window.location.origin;
        }catch(error){
            return false;
        }
    }

    function request(method, args, hasBody, rawField){
        var controller = new AbortController();
        var finished = false;
        var timer;
        var responseHeaders;
        function cleanup(){
            finished = true;
            clearTimeout(timer);
            pending.delete(dfd);
        }
        var dfd = dojo._ioSetArgs(args, function(deferred){
            deferred.canceled = true;
            cleanup();
            controller.abort();
            xhr.readyState = 0;
            xhr.status = 0;
            xhr.statusText = '';
            responseHeaders = null;
            var error = new Error('xhr cancelled');
            error.dojoType = 'cancel';
            return error;
        }, function(deferred){
            return dojo._contentHandlers[deferred.ioArgs.handleAs](xhr);
        }, function(error){
            return error;
        });
        var ioArgs = dfd.ioArgs;
        // Preserve the response surface used by Dojo handlers and RPC bookkeeping.
        var xhr = ioArgs.xhr = {
            readyState: 1, status: 0, statusText: '', responseText: '', responseXML: null,
            getResponseHeader: function(name){
                return responseHeaders ? responseHeaders.get(name) : null;
            },
            getAllResponseHeaders: function(){
                var result = '';
                if(responseHeaders){
                    responseHeaders.forEach(function(value, name){
                        result += name + ': ' + value + '\r\n';
                    });
                }
                return result;
            },
            abort: function(){ dfd.cancel(); }
        };
        function fail(error){
            if(finished){ return; }
            if(!error.status){
                xhr.readyState = 4;
                xhr.status = 0;
                xhr.statusText = '';
                responseHeaders = null;
            }
            cleanup();
            dfd.errback(error);
        }
        if(rawField){
            if(rawField === 'postData' || args.putData){
                ioArgs.query = args[rawField];
            }
            if(rawField === 'putData' && args.putData){
                args.putData = null;
            }
        }else if(!hasBody){
            dojo._ioAddQueryToUrl(ioArgs);
        }
        pending.add(dfd);
        try{
            var headers = new Headers(args.headers || {});
            if(args.contentType || !headers.has('Content-Type')){
                headers.set('Content-Type', args.contentType || 'application/x-www-form-urlencoded');
            }
            if(!headers.has('X-Requested-With')){
                headers.set('X-Requested-With', 'XMLHttpRequest');
            }
            if(args.timeout){
                dfd.startTime = Date.now();
                timer = setTimeout(function(){
                    if(finished){ return; }
                    controller.abort();
                    var error = new Error('timeout exceeded');
                    error.dojoType = 'timeout';
                    fail(error);
                }, args.timeout);
            }
            window.fetch(ioArgs.url, {
                method: method, headers: headers, body: hasBody ? ioArgs.query : null,
                credentials: 'same-origin', signal: controller.signal
            }).then(function(response){
                if(finished){ return; }
                xhr.status = response.status;
                xhr.statusText = httpStatusText(response.status, response.statusText);
                xhr.readyState = 2;
                responseHeaders = response.headers;
                return response.text().then(function(text){
                    if(finished){ return; }
                    xhr.responseText = text;
                    xhr.readyState = 4;
                    if(/(?:\/|\+)xml(?:\s*;|$)/i.test(xhr.getResponseHeader('Content-Type') || 'text/xml')){
                        var xml = new DOMParser().parseFromString(text, 'application/xml');
                        var parseErrors = xml.getElementsByTagNameNS(
                            'http://www.mozilla.org/newlayout/xml/parsererror.xml', 'parsererror').length ||
                            xml.getElementsByTagNameNS('http://www.w3.org/1999/xhtml', 'parsererror').length;
                        xhr.responseXML = parseErrors ? null : xml;
                    }
                    if(!dojo._isDocumentOk(xhr)){
                        var error = new Error('Unable to load ' + ioArgs.url + ' status:' + xhr.status);
                        error.status = xhr.status;
                        error.responseText = text;
                        fail(error);
                        return;
                    }
                    cleanup();
                    dfd.callback(dfd);
                });
            }).catch(fail);
        }catch(error){
            // Keep setup failures asynchronous, like other fetch failures.
            Promise.resolve().then(function(){ fail(error); });
        }
        return dfd;
    }

    dojo.xhr = function(method, args, hasBody){
        if(!supported(args) || (hasBody && (method === 'GET' || method === 'HEAD')) ||
                ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'HEAD'].indexOf(method) < 0){
            return original.xhr.apply(dojo, arguments);
        }
        return request(method, args, hasBody);
    };
    dojo.rawXhrPost = function(args){
        return supported(args) ? request('POST', args, true, 'postData') :
                                original.rawXhrPost.apply(dojo, arguments);
    };
    dojo.rawXhrPut = function(args){
        return supported(args) ? request('PUT', args, true, 'putData') :
                                original.rawXhrPut.apply(dojo, arguments);
    };
    dojo._ioCancelAll = function(){
        Array.from(pending).forEach(function(dfd){ dfd.cancel(); });
        return original.cancelAll.apply(dojo, arguments);
    };
    genropatches.dojoXhr.installed = true;
};

genropatches.places = function(){
    var placeOnScreenAroundElement = dijit.placeOnScreenAroundElement;
    dijit.placeOnScreenAroundElement = function(
        /* DomNode */       node,
        /* DomNode */       aroundNode,
        /* Object */        aroundCorners,
        /* Function */      layoutNode){

        var result = placeOnScreenAroundElement(node,aroundNode,aroundCorners,layoutNode);
        var bodyWidth = dojo.body().clientWidth;
        var coords = dojo.coords(node);
        var delta = bodyWidth-(coords.l+coords.w+5);
        if(delta<0){
            node.style.left = parseInt(node.style.left)+delta+'px';
            result.w = result.w + result.overflow;
            result.overflow = null;
        }
        //console.log('result',result);
        return result;
    };

};
genropatches.forEachError = function(){
    var fe = dojo.forEach;
    dojo['forEach'] = function(arr,cb,scope){
        if(arr==null){
            if(genro.isDeveloper){
                debugger;
            }else{
                console.error('ERROR FOREACH',arguments,cb);
                return;
            } 
        }
        fe.call(dojo,arr,cb,scope);
    }
};

genropatches.indexOfError = function(){
    var fe = dojo.indexOf;
    dojo['indexOf'] = function(arr,object,scope){
        if(object instanceof Date){
            return arr.findIndex(elem=>object.getTime()===elem.getTime());
        }
        return fe.call(dojo,arr,object,scope);
    }
};

genropatches.setStateClass=function(){
    dojo.require('dijit.form._FormWidget');
    dijit.form._FormWidget.prototype._setStateClass_original = dijit.form._FormWidget.prototype._setStateClass;
    dijit.form._FormWidget.prototype._setStateClass = function(){
        if(this.stateNode || this.domNode){
            this._setStateClass_original();
        }
    };
}

genropatches.getDocumentWindow = function(){
    dijit.getDocumentWindow = function(doc){
    //  summary
    //  Get window object associated with document doc

    // With Safari, there is not way to retrieve the window from the document, so we must fix it.
    if(dojo.isSafari && !doc._parentWindow){
        /*
            This is a Safari specific function that fix the reference to the parent
            window from the document object.
            TODO: #5711: should the use of document below reference dojo.doc instead
            in case they're not the same?
        */
        var fix=function(win){
            win.document._parentWindow=win;
            for(var i=0; i<win.frames.length; i++){
                try{
                    fix(win.frames[i]);
                }catch(e){
                    
                }
                
            }
        }
        try{
            fix(window.top);
        }catch(e){
            
        }
    }

    //In some IE versions (at least 6.0), document.parentWindow does not return a
    //reference to the real window object (maybe a copy), so we must fix it as well
    //We use IE specific execScript to attach the real window reference to
    //document._parentWindow for later use
    //TODO: #5711: should the use of document below reference dojo.doc instead in case they're not the same?
    if(dojo.isIE && window !== document.parentWindow && !doc._parentWindow){
        /*
        In IE 6, only the variable "window" can be used to connect events (others
        may be only copies).
        */
        doc.parentWindow.execScript("document._parentWindow = window;", "Javascript");
        //to prevent memory leak, unset it after use
        //another possibility is to add an onUnload handler which seems overkill to me (liucougar)
        var win = doc._parentWindow;
        doc._parentWindow = null;
        return win; //  Window
    }

    return doc._parentWindow || doc.parentWindow || doc.defaultView;    //  Window
}
}
genropatches.sendAsBinary=function(){
    if(!XMLHttpRequest.prototype.sendAsBinary){
            XMLHttpRequest.prototype.sendAsBinary = function(datastr) {
                function byteValue(x) {
                    return x.charCodeAt(0) & 0xff;
                }
                var ords = Array.prototype.map.call(datastr, byteValue);
                var ui8a = new Uint8Array(ords);
                this.send(ui8a.buffer);
            }
        }
};
genropatches.dojoToJson = function() {
    dojo.toJson = function(/*Object*/ it, /*Boolean?*/ prettyPrint, /*String?*/ _indentStr){
        if(it === undefined){
            return "null";
        }
        if(it instanceof gnr.GnrBag){
            console.log('object_to_json',it);
        }
        
        var objtype = typeof it;
        if(objtype == "number" || objtype == "boolean"){
            return it + "";
        }
        if(it === null){
            return "null";
        }
        if(dojo.isString(it)){ 
            return dojo._escapeString(it); 
        }
        if(it.nodeType && it.cloneNode){ // isNode
            return ""; // FIXME: would something like outerHTML be better here?
        }
        // recurse
        var recurse = arguments.callee;
        // short-circuit for objects that support "json" serialization
        // if they return "self" then just pass-through...
        var newObj;
        _indentStr = _indentStr || "";
        var nextIndent = prettyPrint ? _indentStr + dojo.toJsonIndentStr : "";
        if(typeof it.__json__ == "function"){
            newObj = it.__json__();
            if(it !== newObj){
                return recurse(newObj, prettyPrint, nextIndent);
            }
        }
        if(typeof it.json == "function"){
            newObj = it.json();
            if(it !== newObj){
                return recurse(newObj, prettyPrint, nextIndent);
            }
        }

        var sep = prettyPrint ? " " : "";
        var newLine = prettyPrint ? "\n" : "";

        // array
        if(dojo.isArray(it)){
            var res = dojo.map(it, function(obj){
                var val = recurse(obj, prettyPrint, nextIndent);
                if(typeof val != "string"){
                    val = "null";
                }
                return newLine + nextIndent + val;
            });
            return "[" + res.join("," + sep) + newLine + _indentStr + "]";
        }
        /*
        // look in the registry
        try {
            window.o = it;
            newObj = dojo.json.jsonRegistry.match(it);
            return recurse(newObj, prettyPrint, nextIndent);
        }catch(e){
            // console.debug(e);
        }
        // it's a function with no adapter, skip it
        */
        if(objtype == "function"){
            return null; // null
        }
        // generic object code path
        var output = [];
        for(var key in it){
            var keyStr;
            if(typeof key == "number"){
                keyStr = '"' + key + '"';
            }else if(typeof key == "string"){
                keyStr = dojo._escapeString(key);
            }else{
                // skip non-string or number keys
                continue;
            }
            val = recurse(it[key], prettyPrint, nextIndent);
            if(typeof val != "string"){
                // skip non-serializable values
                continue;
            }
            // FIXME: use += on Moz!!
            //   MOW NOTE: using += is a pain because you have to account for the dangling comma...
            output.push(newLine + nextIndent + keyStr + ":" + sep + val);
        }
        return "{" + output.join("," + sep) + newLine + _indentStr + "}"; // String
    }
};
genropatches.dnd=function(){
    dojo.require("dojo.dnd.Moveable");
    var mvbl = dojo.dnd.Moveable;
    mvbl.prototype.onMouseDown_replaced=mvbl.prototype.onMouseDown;
    mvbl.prototype.onMouseDown= function(e){
        var contextclick = (e.button==2 ||  genro.dom.getEventModifiers(e)=='Ctrl');
        if (!contextclick){
            this.onMouseDown_replaced(e);
        }
    }
    
};

genropatches.tabContainer = function(){
    dojo.require("dijit.layout.StackContainer");
    dijit.layout.StackController.prototype.onCloseButtonClick = function(page){
        var container = dijit.byId(this.containerId);
        container.deletePage(page);
    };

};

genropatches.contentPane = function(){
    dojo.require("dijit.layout.ContentPane");
    var original_resize = dijit.layout.ContentPane.prototype.resize;
    // _singleChild is computed only at startup(): a single widget child built
    // after that (e.g. a lazily built dialog form) leaves it unset, so parent
    // resizes stop cascading at this pane and the child keeps its last
    // stamped pixel height. Re-check before resizing.
    dijit.layout.ContentPane.prototype.resize = function(size){
        if(!this._singleChild && this.doLayout != "false" && this.doLayout !== false){
            this._checkIfSingleChild();
        }
        return original_resize.apply(this, arguments);
    };
};
genropatches.menu = function(){
    dojo.require('dijit.Menu');
    dijit.Menu.prototype._openMyself = function(/*Event*/ e){
		// summary:
		//		Internal function for opening myself when the user
		//		does a right-click or something similar

		if(this.leftClickToOpen&&e.button>0){
			return;
		}
		dojo.stopEvent(e);

		// Get coordinates.
		// if we are opening the menu with the mouse or on safari open
		// the menu at the mouse cursor
		// (Safari does not have a keyboard command to open the context menu
		// and we don't currently have a reliable way to determine
		// _contextMenuWithMouse on Safari)
		var x,y;
		if(dojo.isSafari || this._contextMenuWithMouse){
			x=e.pageX;
			y=e.pageY;
		}else{
			// otherwise open near e.target
			var coords = dojo.coords(e.target, true);
			x = coords.x + 10;
			y = coords.y + 10;
		}

		var self=this;
		var savedFocus = dijit.getFocus(this);
		function closeAndRestoreFocus(){
			// user has clicked on a menu or popup
			dijit.focus(savedFocus);
			dijit.popup.close(self);
		}
		var popupKw = {
			popup: this,
			x: x,
			y: y,
			onExecute: closeAndRestoreFocus,
			onCancel: closeAndRestoreFocus,
			orient: this.isLeftToRight() ? 'L' : 'R'
		};
		this.onOpeningPopup(popupKw);
		dijit.popup.open(popupKw);
        var that = this;
        setTimeout(function(){
            that.focus();
        },1)
		

		this._onBlur = function(){
			this.inherited('_onBlur', arguments);
			// Usually the parent closes the child widget but if this is a context
			// menu then there is no parent
			dijit.popup.close(this);
			// don't try to restore focus; user has clicked another part of the screen
			// and set focus there
		}
	};
    
};
genropatches.comboBox = function() {
    dojo.require('dijit.form.ComboBox');
    dojo.declare("gnr.Gnr_ComboBoxMenu", dijit.form._ComboBoxMenu, {
        /*templateString:"<div class='dijitMenu' dojoAttachEvent='onmousedown,onmouseup,onmouseover,onmouseout' tabIndex='-1' style='overflow:\"auto\";'>"
         +"<div class='dijitMenuItem dijitMenuPreviousButton' dojoAttachPoint='previousButton'></div>"
         +"<div class='dijitMenuItem dijitMenuNextButton' dojoAttachPoint='nextButton'></div></div>",*/
        templateString: "<ul class='dijitMenu' dojoAttachEvent='onmousedown:_onMouseDown,onmouseup:_onMouseUp,onmouseout:_onMouseOut' tabIndex='-1' style='overflow:\"auto\";'>"
                + "<li class='dijitMenuItem dijitMenuPreviousButton' dojoAttachPoint='previousButton'></li>"
                + "<li class='dijitMenuItem dijitMenuNextButton' dojoAttachPoint='nextButton'></li>"
                + "</ul>",
        createOptions:function(results, dataObject, labelFunc) {
            this._results = results;
            this._lastFetchAttrs = dataObject.store.lastFetchAttrs;
            this.renderOptions();
        },
        renderOptions:function() {
            var results = this._results;
            var lfa = this._lastFetchAttrs;
            var columns = lfa.columns.split(',');
            var headers = lfa.headers.split(',');
            var tblclass = 'multiColumnSelect' + ' ' + lfa.resultClass;
            var tplRow = this.params.auxColumns_template;
            var max_height = null;
            var multiline = !tplRow && (this._multiline || this.params.auxColumns_multiline===true);
            if(tplRow || multiline){
                results.forEach(n=>{
                    n.attr._template_value = tplRow? dataTemplate(tplRow,n.attr) : this.multilineValue(n.attr,columns,headers);
                });
                if(multiline){
                    tblclass += ' multilineAuxColumns';
                }
                columns = ['_template_value']
                headers = ['*']
                tblclass += ' templateAuxColumns'
                max_height = '400px'
            }
            genro.dom.scrollableTable(this.domNode, results[0].getParentBag(), {'columns':columns,'headers':headers,'tblclass':tblclass,
                                                                                max_height:max_height});
            this.domNode.onmouseover = dojo.hitch(this, 'onmouseover');
            // this.nextButton.style.display='none';
            //  this.previousButton.style.display='none';
            //genro.debug("this.domNode.innerHTML=tbl.join('\n');");
        },
        multilineValue:function(row, columns, headers) {
            var caption = row[columns[0]];
            if(isNullOrBlank(caption)){
                caption = row.caption;
            }
            var lines = [`<div class="auxColumns_caption">${isNullOrBlank(caption)?'&nbsp;':_F(caption)}</div>`];
            for(var i = 1; i < columns.length; i++){
                var v = row[columns[i]];
                if(!isNullOrBlank(v)){
                    lines.push(`<div class="auxColumns_line">${headers[i]}: ${_F(v)}</div>`);
                }
            }
            return lines.join('');
        },
        adaptToField:function(fieldWidth) {
            this.domNode.style.setProperty('--auxColumns-field-width', fieldWidth+'px');
            var mode = this.params.auxColumns_multiline;
            if(this._multiline || mode===true || mode===false || this.params.auxColumns_template || !this._results){
                return false;
            }
            var wrapper = this.domNode.firstChild;
            var table = wrapper && dojo.query('table', wrapper)[0];
            if(!table){
                return false;
            }
            var allowedWidth;
            if(typeof(mode)=='number'){
                allowedWidth = fieldWidth*mode;
            }else{
                var em = parseFloat(window.getComputedStyle(this.domNode).fontSize);
                allowedWidth = Math.max(fieldWidth, Math.min(2*fieldWidth, 30*em));
            }
            if(wrapper.scrollWidth<=wrapper.clientWidth && table.offsetWidth<=allowedWidth){
                return false;
            }
            this._multiline = true;
            this.renderOptions();
            return true;
        },
        tblrows:function() {
            return dojo.query('tbody tr', this.domNode);
        },

        clearResultList:function() {
            this.domNode.innerHTML = '';
        },
        getItems:function() {
            return this.tblrows();
        },

        getListLength:function() {
            return this.tblrows().length;
        },

        onmouseup:function(/*Event*/ evt) {
            evt.preventDefault();
            dojo.stopEvent(evt);
            if (evt.target === this.domNode) {
                return;
            } else {
                var tgt = this.getHighlightedOption();
                if (tgt) {
                    this.setValue({target:tgt}, true);
                }
                ;
            }
        },

        onmouseover:function(/*Event*/ evt) {
            if (evt.target === this.domNode) {
                return;
            }
            var tgt = evt.target.closest && evt.target.closest('tbody tr[id]');
            if (tgt && this.domNode.contains(tgt)) {
                this._focusOptionNode(tgt);
            }

        },
        _page:function(/*Boolean*/ up) {
            return;
        },
        getHighlightedOption:function() {
            // summary:
            //  Returns the highlighted option.
            return this._highlighted_option;
        },
        _focusOptionNode:function(/*DomNode*/ node) {
            // summary:
            //  does the actual highlight
            if (this._highlighted_option != node) {
                this._blurOptionNode();
                this._highlighted_option = node;
                dojo.addClass(this._highlighted_option, "multiColumnSelectHover");
            }
        },
        _blurOptionNode:function() {
            // summary:
            //  removes highlight on highlighted option
            if (this._highlighted_option) {
                dojo.removeClass(this._highlighted_option, "multiColumnSelectHover");
                this._highlighted_option = null;
            }
        },
        _highlightNextOption:function() {
            var nextNode;
            var hop = this.getHighlightedOption();
            if (!hop) {
                nextNode = this.tblrows()[0];
            } else if (hop.nextSibling && hop.nextSibling.style.display != "none") {
                nextNode = hop.nextSibling;
            }
            if (nextNode) {
                this._focusOptionNode(nextNode);
                nextNode.scrollIntoView({block:'nearest'});
            }
        },

        highlightFirstOption:function() {

            // highlight the non-Previous choices option
            this._focusOptionNode(this.tblrows()[0]);
            //  dijit.scrollIntoView(this._highlighted_option);
        },

        highlightLastOption:function() {
            // highlight the noon-More choices option
            var rows = this.tblrows();
            this._focusOptionNode(rows[rows.length - 1]);
            //  dijit.scrollIntoView(this._highlighted_option);
        },

        _highlightPrevOption:function() {
            if (!this.getHighlightedOption()) {
                var rows = this.tblrows();
                this._focusOptionNode(rows[rows.length - 1]);
            } else if (this._highlighted_option.previousSibling && this._highlighted_option.previousSibling.style.display != "none") {
                this._focusOptionNode(this._highlighted_option.previousSibling);
            }
            if (this._highlighted_option) {
                this._highlighted_option.scrollIntoView({block:'nearest'});
            }
        },
        

        handleKey:function(evt) {
            switch (evt.keyCode) {
                case dojo.keys.DOWN_ARROW:
                    this._highlightNextOption();
                    break;
                case dojo.keys.PAGE_DOWN:
                    this.pageDown();
                    break;
                case dojo.keys.UP_ARROW:
                    this._highlightPrevOption();
                    break;
                case dojo.keys.PAGE_UP:
                    this.pageUp();
                    break;
            }
        }
    });
   

    var dijit_form_ComboBoxMixin_onKeyPress = function(/*Event*/ evt){
            // summary: handles keyboard events

            //except for pasting case - ctrl + v(118)
            if(evt.altKey || evt.ctrlKey || evt.metaKey){
                console.log('dijit_form_ComboBoxMixin_onKeyPress exit',evt)
                return;
            }
            if(evt.shiftKey){
                let code = evt.code.toLowerCase();
                if(code.includes('shift') || code=='space'){
                    return
                }
            }
            var doSearch = false;
            var pw = this._popupWidget;
            var dk = dojo.keys;
            if(this._isShowingNow){
                pw.handleKey(evt);
            }
            var evt_keycode = evt.keyCode;
            if((evt_keycode==dk.UP_ARROW && evt.keyChar=='&') || (evt_keycode==dk.DOWN_ARROW && evt.keyChar=='(')){
                evt_keycode = 0; //L.A. fix for evt.keyChar=='&'
            }
            switch(evt_keycode){
                case dk.PAGE_DOWN:
                case dk.DOWN_ARROW:
                    if(!this._isShowingNow||this._prev_key_esc){
                        this._arrowPressed();
                        doSearch=true;
                    }else{
                        this._announceOption(pw.getHighlightedOption());
                    }
                    dojo.stopEvent(evt);
                    this._prev_key_backspace = false;
                    this._prev_key_esc = false;
                    break;

                case dk.PAGE_UP:
                case dk.UP_ARROW:
                    if(this._isShowingNow){
                        this._announceOption(pw.getHighlightedOption());
                    }
                    dojo.stopEvent(evt);
                    this._prev_key_backspace = false;
                    this._prev_key_esc = false;
                    break;

                case dk.ENTER:
                    // prevent submitting form if user presses enter. Also
                    // prevent accepting the value if either Next or Previous
                    // are selected
                    var highlighted;
                    if(! this._isShowingNow){
                        evt.preventDefault();
                        dojo.stopEvent(evt);
                        break;
                    }
                    if( this._isShowingNow && 
                        (highlighted = pw.getHighlightedOption())
                    ){
                        
                        // only stop event on prev/next
                        if(highlighted == pw.nextButton){
                            this._nextSearch(1);
                            dojo.stopEvent(evt);
                            break;
                        }else if(highlighted == pw.previousButton){
                            this._nextSearch(-1);
                            dojo.stopEvent(evt);
                            break;
                        }
                    }else{
                        this.setDisplayedValue(this.getDisplayedValue());
                    }
                    // default case:
                    // prevent submit, but allow event to bubble
                    evt.preventDefault();
                    // fall through

                case dk.TAB:
                    var newvalue = this.getDisplayedValue();
                    // #4617: 
                    //      if the user had More Choices selected fall into the
                    //      _onBlur handler
                    if(pw && (
                        newvalue == pw._messages["previousMessage"] ||
                        newvalue == pw._messages["nextMessage"])
                    ){
                        break;
                    }
                    if(this._isShowingNow){
                        this._prev_key_backspace = false;
                        this._prev_key_esc = false;
                        if(pw.getHighlightedOption()){
                            pw.setValue({ target: pw.getHighlightedOption() }, true);
                        }
                        this._hideResultList();
                    }
                    break;

                //case dk.SPACE:
                //    this._prev_key_backspace = false;
                //    this._prev_key_esc = false;
                //    if(this._isShowingNow && pw.getHighlightedOption()){
                //        dojo.stopEvent(evt);
                //        this._selectOption();
                //        this._hideResultList();
                //    }else{
                //        doSearch = true;
                //    }
                //    break;

                case dk.ESCAPE:
                    this._prev_key_backspace = false;
                    this._prev_key_esc = true;
                    if(this._isShowingNow){
                        dojo.stopEvent(evt);
                        this._hideResultList();
                    }
                    this.inherited(arguments);
                    break;

                case dk.DELETE:
                case dk.BACKSPACE:
                    this._prev_key_esc = false;
                    this._prev_key_backspace = true;
                    doSearch = true;
                    break;

                case dk.RIGHT_ARROW: // fall through
                case dk.LEFT_ARROW: 
                    this._prev_key_backspace = false;
                    this._prev_key_esc = false;
                    break;

                default: // non char keys (F1-F12 etc..)  shouldn't open list
                    this._prev_key_backspace = false;
                    this._prev_key_esc = false;
                    doSearch = true;
            }
            if(this.searchTimer){
                clearTimeout(this.searchTimer);
            }
            if(doSearch){
                // need to wait a tad before start search so that the event
                // bubbles through DOM and we have value visible
                setTimeout(dojo.hitch(this, "_startSearchFromInput"),1);
            }
        }
        dijit_form_ComboBoxMixin_onKeyPress.nom='_onKeyPress';
        dijit.form.ComboBoxMixin.prototype.templateString = "<div class=\"dijit dijitReset dijitInlineTable dijitLeft\"\n\tid=\"widget_${id}\"\n\tdojoAttachEvent=\"onmouseenter:_onMouse,onmouseleave:_onMouse,onmousedown:_onMouse\" dojoAttachPoint=\"comboNode\" waiRole=\"combobox\" tabIndex=\"-1\"\n\t><div style=\"overflow:hidden;\"\n\t\t><div class='dijitReset dijitRight dijitButtonNode dijitArrowButton dijitDownArrowButton'\n\t\t\tdojoAttachPoint=\"downArrowNode\" waiRole=\"presentation\"\n\t\t\tdojoAttachEvent=\"onmousedown:_onArrowMouseDown,onmouseup:_onMouse,onmouseenter:_onMouse,onmouseleave:_onMouse\"\n\t\t\t><div class=\"dijitArrowButtonInner\">&thinsp;</div\n\t\t\t><div class=\"dijitArrowButtonChar\">&#9660;</div\n\t\t></div\n\t\t><div class=\"dijitReset dijitValidationIcon\"><br></div\n\t\t><div class=\"dijitReset dijitValidationIconText\">&Chi;</div\n\t\t><div class=\"dijitReset dijitInputField\"\n\t\t\t><input type=\"text\" autocomplete=\"off\" name=\"${name}\" class='dijitReset'\n\t\t\tdojoAttachEvent=\"onkeydown:_onKeyPress, onfocus:_update, compositionend,onkeyup\"\n\t\t\tdojoAttachPoint=\"textbox,focusNode\" waiRole=\"textbox\" waiState=\"haspopup-true,autocomplete-list\"\n\t\t/></div\n\t></div\n></div>\n"
        if(genro.isMobile){
            dijit.form.ComboBoxMixin.prototype.templateString = "<div class=\"dijit dijitReset dijitInlineTable dijitLeft\"\n\tid=\"widget_${id}\"\n\tdojoAttachEvent=\"onmouseenter:_onMouse,onmouseleave:_onMouse,onmousedown:_onMouse\" dojoAttachPoint=\"comboNode\" waiRole=\"combobox\" tabIndex=\"-1\"\n\t><div style=\"overflow:hidden;\"\n\t\t><div class='dijitReset dijitRight dijitButtonNode dijitArrowButton dijitDownArrowButton'\n\t\t\tdojoAttachPoint=\"downArrowNode\" waiRole=\"presentation\"\n\t\t\tdojoAttachEvent=\"onmousedown:_onArrowMouseDown,onmouseup:_onMouse,onmouseenter:_onMouse,onmouseleave:_onMouse\"\n\t\t\t><div class=\"dijitArrowButtonInner\">&thinsp;</div\n\t\t\t><div class=\"dijitArrowButtonChar\">&#9660;</div\n\t\t></div\n\t\t><div class=\"dijitReset dijitValidationIcon\"><br></div\n\t\t><div class=\"dijitReset dijitValidationIconText\">&Chi;</div\n\t\t><div class=\"dijitReset dijitInputField\"\n\t\t\t><input type=\"text\" autocomplete=\"off\" name=\"${name}\" class='dijitReset'\n\t\t\tdojoAttachEvent=\"input:_onKeyPress, onfocus:_update, compositionend,onkeyup\"\n\t\t\tdojoAttachPoint=\"textbox,focusNode\" waiRole=\"textbox\" waiState=\"haspopup-true,autocomplete-list\"\n\t\t/></div\n\t></div\n></div>\n"
        }
        dijit.form.ComboBoxMixin.prototype._onKeyPress = dijit_form_ComboBoxMixin_onKeyPress;
        dijit.form.ComboBox.prototype._onKeyPress = dijit_form_ComboBoxMixin_onKeyPress;
};
genropatches.borderContainer = function() {
    dojo.require("dijit.layout.BorderContainer");
    dojo.require("dijit.layout._LayoutWidget");
    dojo.declare(
            "dijit.layout.BorderContainer",
//  [dijit._Widget, dijit._Container, dijit._Contained],
            dijit.layout._LayoutWidget,
    {
        // summary:
        //  Provides layout in 5 regions, a center and borders along its 4 sides.
        //
        // description:
        //  A BorderContainer is a box with a specified size (like style="width: 500px; height: 500px;"),
        //  that contains a child widget marked region="center" and optionally children widgets marked
        //  region equal to "top", "bottom", "leading", "trailing", "left" or "right".
        //  Children along the edges will be laid out according to width or height dimensions.  The remaining
        //  space is designated for the center region.
        //  The outer size must be specified on the BorderContainer node.  Width must be specified for the sides
        //  and height for the top and bottom, respectively.  No dimensions should be specified on the center;
        //  it will fill the remaining space.  Regions named "leading" and "trailing" may be used just like
        //  "left" and "right" except that they will be reversed in right-to-left environments.
        //  Optional splitters may be specified on the edge widgets only to make them resizable by the user.
        //
        // example:
        // |    <style>
        // |        html, body { height: 100%; width: 100%; }
        // |    </style>
        // |    <div dojoType="BorderContainer" design="sidebar" style="width: 100%; height: 100%">
        // |        <div dojoType="ContentPane" region="top">header text</div>
        // |        <div dojoType="ContentPane" region="right" style="width: 200px;">table of contents</div>
        // |        <div dojoType="ContentPane" region="center">client area</div>
        // |    </div>
        //
        // design: String
        //  choose which design is used for the layout: "headline" (default) where the top and bottom extend
        //  the full width of the container, or "sidebar" where the left and right sides extend from top to bottom.
        design: "headline",

        // liveSplitters: Boolean
        //  specifies whether splitters resize as you drag (true) or only upon mouseup (false)
        liveSplitters: true,

        // persist: Boolean
        //      Save splitter positions in a cookie.
        persist: false, // Boolean

        // _splitterClass: String
        //      Optional hook to override the default Splitter widget used by BorderContainer
        _splitterClass: "dijit.layout._Splitter",

        postCreate: function() {
            this.inherited(arguments);

            this._splitters = {};
            this._splitterThickness = {};
            dojo.addClass(this.domNode, "dijitBorderContainer");
        },

        startup: function() {
            if (this._started) {
                return;
            }
            dojo.forEach(this.getChildren(), function(child) {
                this._setupChild(child);
                var region = child.region;
                if (this._splitters[region]) {
                    dojo.place(this._splitters[region], child.domNode, "after");
                    this._computeSplitterThickness(region); // redundant?
                }
            }, this);
            this.inherited(arguments);
        },

        _setupChild: function(/*Widget*/child) {
            var region = child.region;
            if (region) {
//          dojo.addClass(child.domNode, "dijitBorderContainerPane");
                child.domNode.style.position = "absolute"; // bill says not to set this in CSS, since we can't keep others
                // from destroying the class list

                var ltr = this.isLeftToRight();
                if (region == "leading") {
                    region = ltr ? "left" : "right";
                }
                if (region == "trailing") {
                    region = ltr ? "right" : "left";
                }

                //FIXME: redundant?
                this["_" + region + "Widget"] = child; //fix safari swapped lines 492/493
                this["_" + region] = child.domNode;
                if (child.splitter && !this._splitters[region]) {
                    var _Splitter = dojo.getObject(this._splitterClass);
                    var flip = {left:'right', right:'left', top:'bottom', bottom:'top', leading:'trailing', trailing:'leading'};
                    try{
                        var oppNodeList = dojo.query('[region=' + flip[child.region] + ']', this.domNode);
                    }catch(e){
                        //fix safari
                        var oppNodeList = Array();
                        oppNodeList.constructor = dojo.NodeList;
                        dojo._mixin(oppNodeList, dojo.NodeList.prototype);
                    }
                    
                    var splitter = new _Splitter({ container: this, child: child, region: region,
                        oppNode: oppNodeList[0], live: this.liveSplitters });
                    this._splitters[region] = splitter.domNode;
                }
                child.region = region;
            }
        },
        /* getRegionVisibility: function(region){
         return (this._splitterThickness[region]!=0);
         },

         showHideRegion: function(region, show){
         var regions=region.split(',');
         for (var i=0; i < regions.length; i++) {
         show = this.showHideRegion_one(regions[i],show);
         };
         return show;
         },
         showHideRegion_one: function(region, show){
         if(this._splitters[region]){
         this._computeSplitterThickness(region);
         }
         var regionNode = this['_'+region];
         if (regionNode){
         if(show=='toggle'){
         show = (this._splitterThickness[region]==0);
         }
         var disp=show? '':'none';
         var splitterNode = this._splitters[region];
         if (splitterNode){
         var tk=this._splitterThickness['_'+region] || this._splitterThickness[region];
         this._splitterThickness['_'+region]=tk;
         this._splitterThickness[region] =show? tk : 0;
         var st=dojo.style(splitterNode,'display',disp);
         }
         dojo.style(regionNode,'display',disp);
         this.layout();
         }
         return show;
         },*/

        _computeSplitterThickness: function(region) {
            var re = new RegExp("top|bottom");
            this._splitterThickness[region] =
                    dojo.marginBox(this._splitters[region])[(re.test(region) ? 'h' : 'w')];
        },

        layout: function() {
            this._layoutChildren();
        },

        addChild: function(/*Widget*/ child, /*Integer?*/ insertIndex) {
            this.inherited(arguments);
            this._setupChild(child);
            if (this._started) {
                var region = child.region;
                if (this._splitters[region]) {
                    dojo.place(this._splitters[region], child.domNode, "after");
                    this._computeSplitterThickness(region);
                }
                this._layoutChildren();
            }
        },

        removeChild: function(/*Widget*/ child) {
            var region = child.region;
            var splitter = this._splitters[region];
            if (splitter) {
                dijit.byNode(splitter).destroy();
                delete this._splitters[region];
                delete this._splitterThickness[region];
            }
            this.inherited(arguments);
            delete this["_" + region];
            delete this["_" + region + "Widget"];
            if (this._started) {
                this._layoutChildren(child.region);
            }
        },

        _layoutChildren: function(/*String?*/changedRegion) {
            var sidebarLayout = (this.design == "sidebar");
            var topHeight = 0, bottomHeight = 0, leftWidth = 0, rightWidth = 0;
            var topStyle = {}, leftStyle = {}, rightStyle = {}, bottomStyle = {},
                    centerStyle = (this._center && this._center.style) || {};

            var changedSide = /left|right/.test(changedRegion);

            var cs = dojo.getComputedStyle(this.domNode);
            var pe = dojo._getPadExtents(this.domNode, cs);
            pe.r = parseFloat(cs.paddingRight);
            pe.b = parseFloat(cs.paddingBottom);

            var layoutSides = !changedRegion || (!changedSide && !sidebarLayout);
            var layoutTopBottom = !changedRegion || (changedSide && sidebarLayout);
            if (this._top) {
                topStyle = layoutTopBottom && this._top.style;
                topHeight = dojo.marginBox(this._top).h;
            }
            if (this._left) {
                leftStyle = layoutSides && this._left.style;
                leftWidth = dojo.marginBox(this._left).w;
            }
            if (this._right) {
                rightStyle = layoutSides && this._right.style;
                rightWidth = dojo.marginBox(this._right).w;
            }
            if (this._bottom) {
                bottomStyle = layoutTopBottom && this._bottom.style;
                bottomHeight = dojo.marginBox(this._bottom).h;
            }
            var splitters = this._splitters;
            var splitterThickness = this._splitterThickness;

            var sideThickness = function(region){
                var s = splitters[region];
                return genro.dom.isVisible(s)?splitterThickness[region]:0;
            }
            var topSplitter = splitters.top;
            var bottomSplitter = splitters.bottom;
            var leftSplitter = splitters.left;
            var rightSplitter = splitters.right;
            
            var topSplitterThickness = sideThickness('top');
            var leftSplitterThickness = sideThickness('left');
            var rightSplitterThickness = sideThickness('right');
            var bottomSplitterThickness = sideThickness('bottom');

            // Check for race condition where CSS hasn't finished loading, so
            // the splitter width == the viewport width (#5824)
            if (leftSplitterThickness > 50 || rightSplitterThickness > 50) {
                setTimeout(dojo.hitch(this, function() {
                    for (var region in this._splitters) {
                        this._computeSplitterThickness(region);
                    }
                    this._layoutChildren();
                }), 50);
                return false;
            }

            var splitterBounds = {
                left: (sidebarLayout ? leftWidth + leftSplitterThickness : 0) + pe.l + "px",
                right: (sidebarLayout ? rightWidth + rightSplitterThickness : 0) + pe.r + "px"
            };

            if (topSplitter) {
                dojo.mixin(topSplitter.style, splitterBounds);
                topSplitter.style.top = topHeight + pe.t + "px";
            }

            if (bottomSplitter) {
                dojo.mixin(bottomSplitter.style, splitterBounds);
                bottomSplitter.style.bottom = bottomHeight + pe.b + "px";
            }

            splitterBounds = {
                top: (sidebarLayout ? 0 : topHeight + topSplitterThickness) + pe.t + "px",
                bottom: (sidebarLayout ? 0 : bottomHeight + bottomSplitterThickness) + pe.b + "px"
            };

            if (leftSplitter) {
                dojo.mixin(leftSplitter.style, splitterBounds);
                leftSplitter.style.left = leftWidth + pe.l + "px";
            }

            if (rightSplitter) {
                dojo.mixin(rightSplitter.style, splitterBounds);
                rightSplitter.style.right = rightWidth + pe.r + "px";
            }

            dojo.mixin(centerStyle, {
                top: pe.t + topHeight + topSplitterThickness + "px",
                left: pe.l + leftWidth + leftSplitterThickness + "px",
                right: pe.r + rightWidth + rightSplitterThickness + "px",
                bottom: pe.b + bottomHeight + bottomSplitterThickness + "px"
            });

            var bounds = {
                top: sidebarLayout ? pe.t + "px" : centerStyle.top,
                bottom: sidebarLayout ? pe.b + "px" : centerStyle.bottom
            };
            dojo.mixin(leftStyle, bounds);
            dojo.mixin(rightStyle, bounds);
            leftStyle.left = pe.l + "px";
            rightStyle.right = pe.r + "px";
            topStyle.top = pe.t + "px";
            bottomStyle.bottom = pe.b + "px";
            if (sidebarLayout) {
                topStyle.left = bottomStyle.left = leftWidth + (this.isLeftToRight() ? leftSplitterThickness : 0) + pe.l + "px";
                topStyle.right = bottomStyle.right = rightWidth + (this.isLeftToRight() ? 0 : rightSplitterThickness) + pe.r + "px";
            } else {
                topStyle.left = bottomStyle.left = pe.l + "px";
                topStyle.right = bottomStyle.right = pe.r + "px";
            }

            // Nodes in IE respond to t/l/b/r, and TEXTAREA doesn't respond in any browser
            var janky = dojo.isIE || dojo.some(this.getChildren(), function(child) {
                return child.domNode.tagName == "TEXTAREA";
            });
            if (janky) {
                // Set the size of the children the old fashioned way, by calling
                // childNode.resize({h: int, w: int}) for each child node)

                var borderBox = function(n, b, s) {
                    n = dojo.byId(n);
                    s = s || dojo.getComputedStyle(n);
                    if (!b) {
                        return dojo._getBorderBox(n, s);
                    }
                    var me = dojo._getMarginExtents(n, s);
                    dojo._setMarginBox(n, b.l, b.t, b.w + me.w, b.h + me.h, s);
                    return null;
                };

                var resizeWidget = function(widget, dim) {
                    if (widget) {
                        (widget.resize ? widget.resize(dim) : dojo.marginBox(widget.domNode, dim));
                    }
                };

                // TODO: use dim passed in to resize() (see _LayoutWidget.js resize())
                // Then can make borderBox setBorderBox(), since no longer need to ever get the borderBox() size
                var thisBorderBox = borderBox(this.domNode, null, cs);

                var containerHeight = thisBorderBox.h - pe.t - pe.b;
                var middleHeight = containerHeight;
                if (this._top) {
                    middleHeight -= topHeight;
                }
                if (this._bottom) {
                    middleHeight -= bottomHeight;
                }
                if (topSplitter) {
                    middleHeight -= topSplitterThickness;
                }
                if (bottomSplitter) {
                    middleHeight -= bottomSplitterThickness;
                }
                var centerDim = { h: middleHeight };

                var sidebarHeight = sidebarLayout ? containerHeight : middleHeight;
                if (leftSplitter) {
                    leftSplitter.style.height = sidebarHeight;
                }
                if (rightSplitter) {
                    rightSplitter.style.height = sidebarHeight;
                }
                resizeWidget(this._leftWidget, {h: sidebarHeight});
                resizeWidget(this._rightWidget, {h: sidebarHeight});

                var containerWidth = thisBorderBox.w - pe.l - pe.r;
                var middleWidth = containerWidth;
                if (this._left) {
                    middleWidth -= leftWidth;
                }
                if (this._right) {
                    middleWidth -= rightWidth;
                }
                if (leftSplitter) {
                    middleWidth -= leftSplitterThickness;
                }
                if (rightSplitter) {
                    middleWidth -= rightSplitterThickness;
                }
                centerDim.w = middleWidth;

                var sidebarWidth = sidebarLayout ? middleWidth : containerWidth;
                if (topSplitter) {
                    topSplitter.style.width = sidebarWidth;
                }
                if (bottomSplitter) {
                    bottomSplitter.style.width = sidebarWidth;
                }
                resizeWidget(this._topWidget, {w: sidebarWidth});
                resizeWidget(this._bottomWidget, {w: sidebarWidth});

                resizeWidget(this._centerWidget, centerDim);
            } else {

                // We've already sized the children by setting style.top/bottom/left/right...
                // Now just need to call resize() on those children so they can re-layout themselves

                // TODO: calling child.resize() without an argument is bad, because it forces
                // the child to query it's own size (even though this function already knows
                // the size), plus which querying the size of a node right after setting it
                // is known to cause problems (incorrect answer or an exception).
                // This is a setback from older layout widgets, which
                // don't do that.  See #3399, #2678, #3624 and #2955, #1988

                var resizeList = {};
                if (changedRegion) {
                    resizeList[changedRegion] = resizeList.center = true;
                    if (/top|bottom/.test(changedRegion) && this.design != "sidebar") {
                        resizeList.left = resizeList.right = true;
                    } else if (/left|right/.test(changedRegion) && this.design == "sidebar") {
                        resizeList.top = resizeList.bottom = true;
                    }
                }

                dojo.forEach(this.getChildren(), function(child) {
                    if (child.resize && (!changedRegion || child.region in resizeList)) {
                        try {
                            child.resize();
                        } catch (error) {
                            return;
                        }
                    }
                }, this);
            }
        }
    });

// This argument can be specified for the children of a BorderContainer.
// Since any widget can be specified as a LayoutContainer child, mix it
// into the base widget class.  (This is a hack, but it's effective.)
    dojo.extend(dijit._Widget, {
        // region: String
        //      "top", "bottom", "leading", "trailing", "left", "right", "center".
        //      See the BorderContainer description for details on this parameter.
        region: '',

        // splitter: Boolean
        splitter: false,

        // minSize: Number
        minSize: 0,

        // maxSize: Number
        maxSize: Infinity
    });

    dojo.require("dijit._Templated");

    dojo.declare("dijit.layout._Splitter", [ dijit._Widget, dijit._Templated ],
    {
        /*=====
         container: null,
         child: null,
         region: null,
         =====*/

        // live: Boolean
        //      If true, the child's size changes and the child widget is redrawn as you drag the splitter;
        //      otherwise, the size doesn't change until you drop the splitter (by mouse-up)
        live: true,

        // summary: A draggable spacer between two items in a BorderContainer
        templateString: '<div class="dijitSplitter" dojoAttachEvent="onkeypress:_onKeyPress,onmousedown:_startDrag" tabIndex="0" waiRole="separator"><div class="dijitSplitterThumb"></div></div>',

        postCreate: function() {
            this.inherited(arguments);
            this.horizontal = /top|bottom/.test(this.region);
            dojo.addClass(this.domNode, "dijitSplitter" + (this.horizontal ? "H" : "V"));
//      dojo.addClass(this.child.domNode, "dijitSplitterPane");
//      dojo.setSelectable(this.domNode, false); //TODO is this necessary?

            this._factor = /top|left/.test(this.region) ? 1 : -1;
            this._minSize = this.child.minSize;

            this._computeMaxSize();
            //TODO: might be more accurate to recompute constraints on resize?
            this.connect(this.container, "layout", dojo.hitch(this, this._computeMaxSize));

            this._cookieName = this.container.id + "_" + this.region;
            if (this.container.persist) {
                // restore old size
                var persistSize = dojo.cookie(this._cookieName);
                if (persistSize) {
                    this.child.domNode.style[this.horizontal ? "height" : "width"] = persistSize;
                }
            }
        },

        _computeMaxSize: function() {
            var dim = this.horizontal ? 'h' : 'w';
            var available = dojo.contentBox(this.container.domNode)[dim] - (this.oppNode ? dojo.marginBox(this.oppNode)[dim] : 0);
            this._maxSize = Math.min(this.child.maxSize, available);
        },

        _startDrag: function(e) {
            if (!this.cover) {
                this.cover = dojo.doc.createElement('div');
                dojo.addClass(this.cover, "dijitSplitterCover");
                dojo.place(this.cover, this.child.domNode, "after");
            } else {
                this.cover.style.zIndex = 1;
            }

            // Safeguard in case the stop event was missed.  Shouldn't be necessary if we always get the mouse up.
            if (this.fake) {
                dojo._destroyElement(this.fake);
            }
            if (!(this._resize = this.live)) { //TODO: disable live for IE6?
                // create fake splitter to display at old position while we drag
                (this.fake = this.domNode.cloneNode(true)).removeAttribute("id");
                dojo.addClass(this.domNode, "dijitSplitterShadow");
                dojo.place(this.fake, this.domNode, "after");
            }
            dojo.addClass(this.domNode, "dijitSplitterActive");

            //Performance: load data info local vars for onmousevent function closure
            var factor = this._factor,
                    max = this._maxSize,
                    min = this._minSize || 10;
            var axis = this.horizontal ? "pageY" : "pageX";
            var pageStart = e[axis];
            var splitterStyle = this.domNode.style;
            var dim = this.horizontal ? 'h' : 'w';
            var childStart = dojo.marginBox(this.child.domNode)[dim];
            var splitterStart = parseInt(this.domNode.style[this.region]);
            var resize = this._resize;
            var region = this.region;
            var mb = {};
            var childNode = this.child.domNode;
            var layoutFunc = dojo.hitch(this.container, this.container._layoutChildren);

            var de = dojo.doc.body;
            this._handlers = (this._handlers || []).concat([
                dojo.connect(de, "onmousemove", this._drag = function(e, forceResize) {
                    var delta = e[axis] - pageStart,
                            childSize = factor * delta + childStart,
                            boundChildSize = Math.max(Math.min(childSize, max), min);

                    if (resize || forceResize) {
                        mb[dim] = boundChildSize;
                        // TODO: inefficient; we set the marginBox here and then immediately layoutFunc() needs to query it
                        dojo.marginBox(childNode, mb);
                        layoutFunc(region);
                    }
                    splitterStyle[region] = factor * delta + splitterStart + (boundChildSize - childSize) + "px";
                }),
                dojo.connect(de, "onmouseup", this, "_stopDrag")
            ]);
            dojo.stopEvent(e);
        },

        _stopDrag: function(e) {
            try {
                if (this.cover) {
                    this.cover.style.zIndex = -1;
                }
                if (this.fake) {
                    dojo._destroyElement(this.fake);
                }
                dojo.removeClass(this.domNode, "dijitSplitterActive");
                dojo.removeClass(this.domNode, "dijitSplitterShadow");
                this._drag(e); //TODO: redundant with onmousemove?
                this._drag(e, true);
            } finally {
                this._cleanupHandlers();
                delete this._drag;
            }

            if (this.container.persist) {
                dojo.cookie(this._cookieName, this.child.domNode.style[this.horizontal ? "height" : "width"]);
            }
        },

        _cleanupHandlers: function() {
            if(this._handlers){
                dojo.forEach(this._handlers, dojo.disconnect);
            }
            delete this._handlers;
        },

        _onKeyPress: function(/*Event*/ e) {
            // should we apply typematic to this?
            this._resize = true;
            var horizontal = this.horizontal;
            var tick = 1;
            var dk = dojo.keys;
            switch (e.charOrCode) {
                case horizontal ? dk.UP_ARROW : dk.LEFT_ARROW:
                    tick *= -1;
                    break;
                case horizontal ? dk.DOWN_ARROW : dk.RIGHT_ARROW:
                    break;
                default:
//              this.inherited(arguments);
                    return;
            }
            var childSize = dojo.marginBox(this.child.domNode)[ horizontal ? 'h' : 'w' ] + this._factor * tick;
            var mb = {};
            mb[ this.horizontal ? "h" : "w"] = Math.max(Math.min(childSize, this._maxSize), this._minSize);
            dojo.marginBox(this.child.domNode, mb);
            this.container._layoutChildren(this.region);
            dojo.stopEvent(e);
        },

        destroy: function() {
            this._cleanupHandlers();
            delete this.child;
            delete this.container;
            delete this.fake;
            this.inherited(arguments);
        }
    });
};

genropatches.tree = function() {
    dojo.require('dijit.Tree');
    dijit.Tree.prototype._expandNode_replaced=dijit.Tree.prototype._expandNode;
    dijit.Tree.prototype._collapseNode_replaced=dijit.Tree.prototype._collapseNode;
    dijit.Tree.prototype._expandNode = function(node) {
        if(node.item && node.item._resolver && node.item._resolver.expired()){
            node.state = 'UNCHECKED';
        }
        if(node.__eventmodifier=='Shift' && node.isExpandable){
            var was_expanded = node.isExpanded;
            this._expandNode_replaced(node);
            if(!was_expanded){
                this.expandAll(node);
            }
        }else{
            return this._expandNode_replaced(node);
        }
    }
    dijit.Tree.prototype._collapseNode = function(node) {
        if(node.item && node.item._resolver && node.item._resolver.expired()){
            node.state = 'UNCHECKED';
        }
        if(node.__eventmodifier=='Shift' && node.isExpandable){
            var was_expanded = node.isExpanded;
            this._collapseNode_replaced(node);
            if(was_expanded){
                this.collapseAll(node);
            }
        }else{
            return this._collapseNode_replaced(node);
        }
    }
    dijit._TreeNode.prototype.setLabelNode = function(label) {
        this.labelNode.innerHTML = "";
        var itemattr = this.item.attr || {};
        if ((typeof(label) == 'string') && (label.indexOf('innerHTML:') >= 0)) {
            this.labelNode.innerHTML = label.replace('innerHTML:', '');
        }
        else {
            this.labelNode.appendChild(dojo.doc.createTextNode(label));
        }
        ;
        if ('node_class' in itemattr) {
            dojo.addClass(this.domNode, itemattr.node_class);
        }
        if (itemattr.tip){
            this.domNode.setAttribute('title',itemattr.tip);
        }
        var sourceNode = this.tree.sourceNode;
        var draggable = sourceNode.attr.draggable;
        //var nodeattrs=this.tree.gnrNodeAttributes;
        if (draggable && (this.item instanceof gnr.GnrBagNode)) {
            this.domNode.setAttribute('draggable', draggable);
        }
        /*var dropTarget=sourceNode.attr.dropTarget
         if (dropTarget && (this.item instanceof gnr.GnrBagNode)){
         this.contentNode.setAttribute('droppable',droppable);
         }*/
    };

};


genropatches.parseNumbers = function() {
    dojo.require('dojo.number');

    dojo.number._integerRegexp = function(/*dojo.number.__IntegerRegexpFlags?*/flags) {
        // summary:
        //		Builds a regular expression that matches an integer

        // assign default values to missing paramters
        flags = flags || {};
        if (!("signed" in flags)) {
            flags.signed = [true, false];
        }
        if (!("separator" in flags)) {
            flags.separator = "";
        } else if (!("groupSize" in flags)) {
            flags.groupSize = 3;
        }
        // build sign RE
        var signRE = dojo.regexp.buildGroupRE(flags.signed,
                                             function(q) {
                                                 return q ? "[-+]" : "";
                                             },
                true
                );

        // number RE
        var numberRE = dojo.regexp.buildGroupRE(flags.separator,
                                               function(sep) {
                                                   if (!sep) {
                                                       return "(?:\\d+)";
                                                   }

                                                   sep = dojo.regexp.escapeString(sep);
                                                   if (sep == " ") {
                                                       sep = "\\s";
                                                   }
                                                   else if (sep == "\xa0") {
                                                       sep = "\\s\\xa0";
                                                   }

                                                   var grp = flags.groupSize, grp2 = flags.groupSize2;
                                                   if (grp2) {
                                                       var grp2RE = "(?:0|[1-9]\\d{0," + (grp2 - 1) + "}(?:[" + sep + "]\\d{" + grp2 + "})*[" + sep + "]\\d{" + grp + "})";
                                                       return ((grp - grp2) > 0) ? "(?:" + grp2RE + "|(?:0|[1-9]\\d{0," + (grp - 1) + "}))" : grp2RE;
                                                   }
                                                   return "(?:0|[1-9]\\d{0," + (grp - 1) + "}(?:[" + sep + "]\\d{" + grp + "})*)";
                                               },
                true
                );

        // integer RE
        return signRE + numberRE; // String
    };
};

genropatches.decimalRound = function() {
  /**
   * Decimal adjustment of a number.
   *
   * @param {String}  type  The type of adjustment.
   * @param {Number}  value The number.
   * @param {Integer} exp   The exponent (the 10 logarithm of the adjustment base).
   * @returns {Number} The adjusted value.
   */
  function decimalAdjust(type, value, exp) {
    // If the exp is undefined or zero...
    if (typeof exp === 'undefined' || +exp === 0) {
      return Math[type](value);
    }
    value = +value;
    exp = +exp;
    // If the value is not a number or the exp is not an integer...
    if (isNaN(value) || !(typeof exp === 'number' && exp % 1 === 0)) {
      return NaN;
    }
    // Shift
    value = value.toString().split('e');
    value = Math[type](+(value[0] + 'e' + (value[1] ? (+value[1] - exp) : -exp)));
    // Shift back
    value = value.toString().split('e');
    return +(value[0] + 'e' + (value[1] ? (+value[1] + exp) : exp));
  }

  // Decimal round
  if (!Math.round10) {
    Math.round10 = function(value, expOrFormat) {
        let exp;
        if(expOrFormat===undefined){
            exp = -2;
        }else if(typeof(expOrFormat)=='string'){
            let decimalPart = expOrFormat.split('.')[1];
            if (decimalPart===undefined){
                exp=0;
            }else{
                exp = -decimalPart.length;
            }
        }else{
            exp = expOrFormat;
        }
        return decimalAdjust('round', value, exp);
    };
  }
  // Decimal floor
  if (!Math.floor10) {
    Math.floor10 = function(value, exp) {
      return decimalAdjust('floor', value, exp);
    };
  }
  // Decimal ceil
  if (!Math.ceil10) {
    Math.ceil10 = function(value, exp) {
      return decimalAdjust('ceil', value, exp);
    };
  }
};
