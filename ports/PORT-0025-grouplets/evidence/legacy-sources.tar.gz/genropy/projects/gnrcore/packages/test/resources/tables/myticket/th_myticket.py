from gnr.core.gnrdecorator import public_method
from gnr.web.gnrbaseclasses import BaseComponent


class View(BaseComponent):
    py_requires = 'gnrcomponents/grouplet/grouplet:GroupletHandler'

    def th_struct(self, struct):
        r = struct.view().rows()
        r.fieldcell('subject', width='20em')
        r.fieldcell('ticket_type', width='10em', name='Type')
        r.fieldcell('ticket_date', width='10em')
        r.fieldcell('status', width='8em')

    def th_order(self):
        return 'ticket_date:d'

    def th_query(self):
        return dict(column='subject', op='contains', val='')

    def th_options(self):
        return dict(
            addrow=self.gr_groupletAddrowMenu(table='test.myticket', field='ticket_type')
        )


class Form(BaseComponent):
    py_requires = 'gnrcomponents/grouplet/grouplet:GroupletHandler'

    def th_form(self, form):
        bc = form.center.borderContainer()
        top = bc.contentPane(region='top', datapath='.record')
        fb = top.formlet(cols=2, border_spacing='3px')
        fb.field('subject', colspan=2, width='100%')
        fb.field('ticket_type', readOnly=True, tag='div')
        fb.field('ticket_date')
        fb.field('status', tag='filteringSelect',
                 values='open:Open,in_progress:In Progress,closed:Closed')
        fb.field('description', colspan=2, width='100%', tag='simpleTextArea',
                 height='60px')
        bc.contentPane(region='center', datapath='.record.extra_data').grouplet(
            resource='=#FORM.record.ticket_type',
            table='test.myticket',showOnFormLoaded=True)

    def th_options(self):
        return dict(dialog_windowRatio=.9,
            form_add=self.gr_groupletAddrowMenu(table='test.myticket', field='ticket_type')
        )


class FormAutoSize(BaseComponent):
    """Intrinsic content whose height follows the record: opened with
    dialog_autoSize, the dialog fits it after every load."""

    def th_form(self, form):
        pane = form.center.contentPane(datapath='.record', padding='12px')
        pane.div('^.subject', font_weight='bold', margin_bottom='8px')
        pane.div('^.description', white_space='pre-line', max_width='60em')

    def th_options(self):
        return dict(showtoolbar=False)


class ViewWizard(View):
    """Plain view for the wizard demo: no typed addrow menu."""

    def th_options(self):
        return dict()


class FormWizard(BaseComponent):
    """No-summary wizard on the `wizard_grouplets` root: a saved ticket
    reopened (or reloaded by its own save) must keep the current step."""
    py_requires = 'gnrcomponents/grouplet/grouplet:GroupletHandler'

    def th_form(self, form):
        form.center.contentPane().groupletWizard(
            table='test.myticket',
            value='^.record',
            frameCode='ticket_wizard',
            grouplets_root='wizard_grouplets',
            completeLabel='Complete Ticket')

    def th_options(self):
        return dict(dialog_height='420px', dialog_width='700px')


class FormWizardResume(FormWizard):
    """groupletWizardForm: the wizard owns the form (no toolbar, no padlock,
    a save on every advance) and a saved ticket reopens on its step."""

    def th_form(self, form):
        form.groupletWizardForm(
            frameCode='ticket_wizard_resume',
            grouplets_root='wizard_grouplets',
            resumeStepField='wizard_step',
            remote_ticket_note='resume test',
            recap_remote_subject='=#FORM.record.subject',
            draftConfirm=True, backToDraft=True,
            completeLabel='Complete Ticket')

    @public_method
    def th_onLoading(self, record, newrecord, loadingParameters, recInfo):
        if newrecord:
            record['__is_draft'] = True


class FormWizardLeft(FormWizardResume):
    """FormWizardResume with the steps in a rail on the left."""

    def th_form(self, form):
        form.groupletWizardForm(
            frameCode='ticket_wizard_left',
            grouplets_root='wizard_grouplets',
            resumeStepField='wizard_step',
            recap_remote_subject='=#FORM.record.subject',
            draftConfirm=True, backToDraft=True,
            stepperPosition='left',
            completeLabel='Complete Ticket')

    def th_options(self):
        return dict(dialog_height='420px', dialog_width='820px')
