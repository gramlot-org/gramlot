# 350 · Legacy grouplets and proposed Gramlot implementation plan

Document ID: **GC-350**. Research date: **2026-10-28**.

**Research/planning complete. New contracts, implementation and acceptance pending.**
[Expanded plan](../../docs/future/350-grouplets-implementation-plan.md).
[Evidence/handoff](../../ports/PORT-0024-grouplets/README.md).

<a id="gc-350-005"></a>
## 005 · Assignment and authority

Owner, this chat, 2026-10-28: “recupera TUTTO il materiale relativo ai grouplet dekl
genropy legacy e prepara un piano di imlementazione in gramlot che metteremo in un
qworktree diverso”. Authorizes research and a transferable plan, not implementation,
API approval, releases, dependency edits or worktree creation now. GC-110 remains
the completed 0.1.0 plan. Constitution §§3–7,13–14, 11.43, 11.56, 11.58–11.60 and
11.92 apply; new names require GC-225 review. Legacy spellings are evidence.

<a id="gc-350-010"></a>
## 010 · Recovered material and provenance

Current reference: `genropy/genropy@a135c9d949d0b014a22f57c418e83b315f85e7bf`,
GitHub develop verified 28 October, committed 27 October. Local legacy HEAD
`fa35e5adfa6ad1b269f3a22a9b12c4c1ee6513ea` is from 14 September.

- 196 current-tree grouplet path/content matches, 226 archived files with runtime/
  test dependencies/license. Main Python, controller, grid, card and CSS sources;
  loader/mixin/form/store/Source integration; 14 grouplet and 17 grid demo pages,
  resource trees, custom roots, transforms, collisions, documentation assets.
- Separate 135-file local legacy snapshot, with working-file hashes independent
  of its September HEAD; `local-legacy-manifest.json` and source archive.
- Direct GitHub search: 74 complete returned results (35 issues, 39 PRs), 45
  conversation and 36 inline review comments. Supplement: 247 indexed Genropy
  commits, 33 indexed issues, 36 indexed PRs, retrieved with pagination.
- Historical architecture Markdown and 43 KB store design HTML from
  `feat-grouplet-grid`, tree `b6f22d446180a0c32114bcf0e16ddc0e57ae960c`, with blob IDs.
- Six archived PoC notes/cards; 39 secondary local/archive references with hashes.
  Thirty known meeting summaries checked; one 29 September AI summary on
  GroupPanel/layout fixes, zero indexed transcript hits. No decision authority.
- Exact Gramlot working-file hashes; inspected local changes are not reproduced
  by HEAD alone. See `SOURCE-INDEX.md`, JSON inventories and evidence archives.

Coverage is the accessible current source, referenced historical branch, indexed
history and searched local roots. Deleted branches, inaccessible applications,
unindexed/private documentation are not claimed exhaustive. Archived sources are
**Historical record**, not active code, approved design or dependency pins.

<a id="gc-350-015"></a>
## 015 · What the legacy family actually contains

Basic Grouplet uses a dedicated remote body and data path. Resource discovery
handles ordinary/table resources, topics, custom roots, metadata, ordering,
permissions and enablement. Topic leaves are recursively built in one server call,
not necessarily one RPC per leaf. Metadata representations differ in legacy;
choose one approved destination representation.

GroupletForm wraps BoxForm with memory/Item defaults, separate record/controller/
origin paths and load/save transforms. Dialogs support memory/document/record;
record chunk uses isolated workspace and refresh after edit. Panels handle tree/
topic selection, pending edits, unopened mandatory groups and draft policy.
Wizard covers steps, saves, resume, summaries, confirmation/read-only and remote
parameters. Choice is single-value, with rows/DB query and optional auto-advance.
Card supplies chrome, title/collapse/tools/docs/checkbox and optional copy-edit form.

Grid repeats resource/handler/per-row-resource/struct fragments; cards/tabs/vtabs,
limits/defaults, row editing, phantom/entry/template rows, selection/clipboard,
DnD, sorting, formulas/totals/counts and shared card presentation. Legacy separates
struct adapter, DnD, store facade, controller and tiles. The facade still has
filter no-ops and private Bag movement; no complete generic-store claim or
authorization to reproduce those mechanisms.

<a id="gc-350-020"></a>
## 020 · History that changes the implementation requirements

Regression inputs: #1665 RPC/mixin identity; #1436 remote reentry; #1464 change
tracking and #1619 protected metadata; #1466 unopened mandatory groups;
#1496/#1498 wizard dismiss/save bypass; #1506 selected-step persistence;
#1537 temporary rows; #1613 empty drops; #1763/PR1764 duplicate decoration.

September's immediate-advance warning is superseded for October Next (onReload)
and Confirm (blocked/deferred handling). Back and valid panel-switch still save
then continue in their memory-store context: test asynchronous destination behavior;
do not infer a universal legacy data-loss defect.

Open proposals: #1714 multiple choice; #1095 terminal resource/initial-step scope;
#897 remaining adapter/filter work despite #900 facade completion; #899 shared
editor resolution; #909 diagnostics/identity; #910 client handler; #794 package
overrides. #1439 remains open although formulas/totals exist in current source.
Issue state is not the implementation contract. Full source links in expanded plan.

<a id="gc-350-025"></a>
## 025 · Existing Gramlot mechanisms and ownership

Reuse Page/@source/typed Source, RemoteBinding/SourceHandler, RPC envelope,
node-owned abort/latest-wins, named Logic/hooks, Data bindings/controllers,
subscriptions/references and shared layout/components. Keep remote method literal;
resource identity is a parameter. Logic groups are not proven instance isolation.
Source received as Data must not activate code.

GC-230's planned `grouplets` capability is not an implemented catalogue. Resource
search/import/package policy/auth belongs to an appropriate resource host. Core
resource helpers validate names/order, not filesystem discovery. No Genropy/DB
dependency in core. Formlet is layout, not a form/save engine. Reuse/settle shared
form lifecycle and GC-330 collection contracts before dependent families.
GC-340 directs legacy grid formulas/totals for now; coordinate PORT-0023/GC-345,
without a new Bag JS engine. Selector Kajenn/Asqueel scope does not approve every
grouplet DB service. Python-first examples live in gramlot-examples, core tests use
own fixtures. Base grouplet need not be a new Web Component; visual card requires
its own reviewed contract. No Dojo/application DOM/private Bag workarounds.

<a id="gc-350-030"></a>
## 030 · Decisions to settle before the affected implementation

Ask one owner decision at a time and record exact confirmation; do not reopen
settled decisions. Proposed gates:

1. D1: first slice = basic resource fragment, explicit Data, two isolated instances,
   reactive parameters and teardown; forms/grids later.
2. D2: portable versus hosted catalogue; first provider and single metadata format.
3. D3: resource/instance/location identity, method dispatch, explicit ID conflicts.
4. D4: loading/failure/old-body retention, install versus nested readiness, inactive bodies.
5. D5: direct/copy form data, commit/discard/transforms/dirty/invalid/async parent-child lifecycle.
6. D6: navigation, unopened required fields, draft/confirmation and save ordering.
7. D7: common-store requirements, first row representation/layout, optional grid slices.
8. D8: concrete language names/metadata/hooks under GC-225 before each API increment.

No proxy, class, registration format or spelling is approved by this list.

<a id="gc-350-035"></a>
## 035 · Proposed implementation sequence

| Phase | Work | Exit evidence |
| --- | --- | --- |
| P0 | Transfer dossier to verified development baseline in separate worktree | Reproducible baseline and prerequisites, no unrelated local changes |
| P1 | Approve resource/instance/dispatch/metadata/authorization contract and host | Two-resource/two-instance examples and negative provider fixtures |
| P2 | Basic typed Source/remote composition and explicit Data/cleanup | Isolation, nested/deferred routing, races, removal, failure/retry, Python fixture |
| P3 | Catalogue/topics and basic card presentation | Ordering/authorization/custom roots as approved, nested/empty/error cases, card state |
| P4 | Shared form/store lifecycle then GroupletForm and memory editor | Metadata-safe commit/discard, invalid/dirty/copy/transforms, async/parent-child cleanup |
| P5 | Panel and chunk, record variant only with service prerequisites | Save old origin before switch, Cancel, mandatory/draft and isolated chunk refresh |
| P6 | Wizard and single choice | Forward/back/stepper/close, editor/save deferral, confirmation, first insert/reload |
| P7 | Basic repeated card/Source grid consuming common store | Stable identity, external changes/replacement, nested teardown, locks/limits |
| P8 | Separate advanced grid slices | Layout/lazy/heterogeneous/struct/temporary rows/selection/clipboard/DnD/formula/doc checks |
| P9 | Python examples, chosen-host integration and acceptance | E2E, accessibility/lifecycle, paired docs, explicit omissions, owner acceptance |

P0→P1→P2→P3; shared forms→P4→P5→P6; shared collection contract + P2/P3→P7→P8;
accepted slices join P9. Basic fragments need not await full record/grid/DB work.
Each phase requires code/tests/docs/review; proposed locations are existing Page,
remote/logic/SourceHandler and shared components/collection exports. Add only
proven gaps; integration-owned discovery stays outside core. No imaginary classes
or blanket API delivery claims. Releases remain separately authorized.

<a id="gc-350-040"></a>
## 040 · Required destination qualification matrix

Test resource not-found/denied/malformed and direct-load authorization; duplicate
instances/IDs and same-named methods; typed Source versus inert Data; fixed method
and variable resource parameters; A→B→A/races/cache/false guard/removal/reentry;
no leaked providers/subscriptions. Verify copy/direct data and unchanged attributes/
relations; pending invalid edits/transforms/async failure; unopened mandatory groups,
Cancel/Discard, child registration, first insert, same/new record and draft/read-only.
Card/chunk: bound state, docs policy, clear scope, refresh and duplicate wrappers.
Grid: identity versus order, explicit row shape, empty/store replacement/nested
teardown/locks/limits, temporary-row promotion, clipboard/DnD/selection and stable
layout/sort changes. Formula results must be visible to another shared-store
consumer; aggregate scope is explicit. Include keyboard/focus, loading/errors,
narrow layouts, approved browsers/host. Control asynchronous completion order;
no Dojo dependency in core tests and no screenshot-only save acceptance.

<a id="gc-350-045"></a>
## 045 · Verification completed for this investigation

Exact-source legacy Node suites: **188 passed, 0 failed, 0 skipped** across
grouplet*, wizard saves, Item/memory writeback, remote reentry and field teardown.
VM/stubbed DOM evidence only; no browser/DB/E2E or Gramlot implementation claim.
Two real Python card/panel suites attempted, both blocked at collection by missing
`unidecode`; full diagnostics retained. No dependency-source workaround.
Archive hashes/checksums, paired anchors/local links and existing public-doc build
boundary are checked at delivery; plan is outside public allowlist. Runtime unchanged.

<a id="gc-350-050"></a>
## 050 · Transfer to a different worktree

Transfer paired GC-350, PORT-0024/evidence/HANDOFF and current-status entry.
Choose verified develop-derived baseline and required accepted increments at start;
HEAD alone omits inspected working changes. Re-read current instructions/contracts,
check baseline hashes, avoid copying unrelated work or editing dependencies.
Use managed-worktree tools when applicable. Work remains on development until
verified/accepted; main is consolidated. No worktree/chat/background workflow,
release or deployment is started here. Next product decision: D1's bounded first slice.
