# 330 · Collection store logic and open decisions

Document ID: **GC-330**. Updated: **2026-10-27**.

[Expanded brief](../../docs/future/330-collection-store-agent-brief.md). [Discussion record](320-grid-and-stores.md). [PostgreSQL strategy](325-postgresql-unlogged-selections.md).

**Clarified** means explicitly described by the owner, not a shipped or complete API. **Open** means a decision remains. Historical implementations and benchmarks do not approve destination behavior.

<a id="gc-330-005"></a>

## 005 · The common abstraction

Clarified: collection-store types expose the same conceptual methods with different implementations. Grids and other widgets request next/positional rows, filter and sort. Preserve the useful abstraction without copying accumulated legacy layers. Open: method inventory, signatures, results, async/errors, unsupported operations and class/composition structure. Common interface does not imply every origin supports all writes or cheap random access. Owner evidence: [GC-320 §095](320-grid-and-stores.md#gc-320-095).

<a id="gc-330-010"></a>

## 010 · Terms that must remain distinct

Origin is where data loads/saves; working collection is current data for a context; resident rows may be only part of the logical collection. Identity is distinct from ordinal/path. Named query selection differs from UI-selected rows. Save includes writeback to another in-memory Bag; autosave is a write policy. Data Bag differs from Source. Legacy `gnr.formstores.Collection` consumes a parent collection; PoC `CollectionStores` is a registry. Neither names the whole collection-store abstraction.

<a id="gc-330-015"></a>

## 015 · Bag data and the two row layouts

Clarified: attribute rows keep fields in node attributes with null node values; value rows keep fields in nested value Bags. Common consumer operations shield this distinction. No implicit fallback between layouts. Open: explicit declaration, field/row API, keys and metadata. Bag data does not imply store inheritance from Bag or full browser residency for virtual collections.

<a id="gc-330-020"></a>

## 020 · Origins and loading strategies

Clarified origins: another in-memory store's Bag/path; database via RPC; filesystem documents plus metadata editable in a form; generic RPC, possibly external, returning data representable in a Bag. Origin, row layout, copy/reference, save policy and resident/virtual loading are separate aspects, not an approved all-combinations matrix. Static labels the owner's completed conceptual explanation; it does not mean read-only, immutable or synchronous. Backend protocols, document content/metadata persistence and service writability remain open.

<a id="gc-330-025"></a>

## 025 · Working copy versus direct shared reference

Clarified: copy mode loads a separate working Bag and saves edits back; direct shared reference immediately edits the original. The concrete region example resolves earlier ambiguous “referenced/shared” wording. Sharing is not RPC autosave, durable persistence or undo. Open: copy depth/metadata, merge versus replacement, concurrent parent changes, source lifetime and shared rollback.

<a id="gc-330-030"></a>

## 030 · The region and province example

The source contains LOMBARDIA→MI/BG and CAMPANIA→NA/SA. A variable datapath selects the current region's provinces. Copy mode loads Lombardia, edits locally and saves back to Lombardia before loading Campania when retaining edits. Shared mode immediately changes Lombardia; switching reference does not discard those already-applied edits. RPC-loaded provinces have the same context-replacement concern with different load/save implementations.

<a id="gc-330-035"></a>

## 035 · Pending edits when the context changes

Clarified: before replacing unsaved modified data, offer saving or discarding. Loaded context and requested next context must remain distinct: Lombardia edits save to Lombardia, never Campania. Open: dirty/prompt ownership, validation, failures, UI switch timing, cancel-navigation choice and rapidly changing requests. No silent data-loss or shared rollback policy selected. [Owner evidence](320-grid-and-stores.md#gc-320-100).

<a id="gc-330-040"></a>

## 040 · Explicit save and contextual autosave

Clarified: in appropriate DB contexts, leaving an edited row triggers RPC persistence; insert/delete must also be considered. Not per-keystroke or universal autosave. Exact insertion/deletion triggers remain open, along with validation, write granularity/transactions, failures/retries, pending-write navigation, assigned identities and conflicts. Do not assign responsibilities to form/editor/store/controller without a decision. [Owner evidence](320-grid-and-stores.md#gc-320-105).

<a id="gc-330-045"></a>

## 045 · Filtering sorting and row access

Clarified operations, unresolved semantics: source mutation versus projection, shared versus independent consumer views, hidden-row identity lookup, navigation after transformations and server execution. Position depends on ordering and is not identity. Historical legacy sorting mutated Bag; PoC projected it. Both had hidden-row lookup hazards. These are evidence, not accepted alternatives.

<a id="gc-330-050"></a>

## 050 · Virtual collections and saved selections

Clarified: large collections must not imply full residency. Legacy named selections retained a result server-side, historically pickled, and supplied missing non-contiguous pages. Data cache and DOM window are separate. Owner selected PostgreSQL saved selections for their backend; [GC-325](325-postgresql-unlogged-selections.md) covers recovered UNLOGGED behavior and caveats. Core remains backend-independent.

Open: selection lifetime/access/revision, page sizes/prefetch/eviction, counts, async random access, off-page identity, transformed ordinals, snapshot edits/invalidation and DOM virtualization. No bounded historical cache or new DOM strategy established.

<a id="gc-330-055"></a>

## 055 · Progressive loading and query replacement

Owner requested 500,000×30 business-data measurements and block-size comparison, accounting for first-30-row use and an immediate query change. Worker/IndexedDB SQLite via Asqueel-JS, JSONL and TYTX was measured, not adopted as the general runtime. Avoiding unnecessarily broad queries was discussed without choosing a row cap/UI. [GC-320 §§140–145](320-grid-and-stores.md#gc-320-140) records results and differing timing boundaries; block sizes are not defaults or grid/RPC qualification.

Open: partial-result publication/counts/filter/sort, cancel versus retain, stale-response exclusion and upstream cancellation/cleanup. First visible rows, complete result and persisted edits are distinct. PostgreSQL CTAS alone does not guarantee progressive publication.

<a id="gc-330-060"></a>

## 060 · Decision register for the receiving agent

| Area | Still to decide |
| --- | --- |
| Common operations | Exact API, returned rows, async/errors, unsupported operations |
| Bag layouts/identity | Explicit declaration, field methods, keys, index base, missing rows and insert identity |
| Copy/reference | Copy depth/metadata, writeback merge/replacement, source lifetime |
| Context/dirty | Detection/prompt owner, validation, failed/pending writes, cancellation/request ordering |
| Autosave | Precise triggers, transactions, acknowledgement, concurrency and navigation |
| Filter/sort | Mutation/projection, consumer independence, hidden-row lookup |
| Forms/documents | Record versus collection responsibilities, content/metadata protocols |
| Virtual collections | Paging/cache/counts, random access, ordinals after transformations, snapshot edits |
| Progressive loads | Publication, late replies, cancellation/retention and resource cleanup |
| Server selections | Access, lifetime, revision/invalidation and integration ownership |
| Architecture | Classes/composition, declarations and bounded implementation scope |

Use [GC-225](../internal/225-naming-and-proxy-conventions.md) for names and the [constitution](../00-constitution.md) for confirmation and ownership. No inferred compatibility/fallback paths or legacy hierarchy.

<a id="gc-330-065"></a>

## 065 · Behavioral examples for a future contract review

Proposed review scenarios: equivalent consumers on both row layouts; copy save/discard with the correct previous region; direct shared edits; failed/pending writes during navigation; chosen multi-consumer filter/sort semantics; distant virtual rows after ordering changes; query replacement after early results; document form load/save. These are not an approved test plan. Expected failure/lifecycle behavior depends on §060 decisions.

<a id="gc-330-070"></a>

## 070 · Evidence scope and handoff boundaries

[GC-320 §§095–110](320-grid-and-stores.md#gc-320-095) preserves substantive owner statements; [§§115–125](320-grid-and-stores.md#gc-320-115) covers virtual options and PostgreSQL direction. [§090](320-grid-and-stores.md#gc-320-090) and [GC-325](325-postgresql-unlogged-selections.md) are historical evidence; [benchmark record](../../ports/PORT-0023-grid-and-stores/benchmark/README.md) retains measurement limits. This brief's date is not the date of the earlier statements.

Documentation only: no runtime port, final API, dependency edits or formal Live Object Tree semantics. Inspect existing Source/Data, bindings, controllers, resolvers and messaging before proposing new mechanisms. Choose a bounded contract with the owner, one open decision at a time; do not re-ask clarified concepts.
