# 345 · Updated legacy grid: filters and adjacent improvements

Document ID: **GC-345**. Reviewed: **2026-10-28**.

> **Historical evidence, not a Gramlot contract.** GitHub develop verified at
> `a135c9d949d0b014a22f57c418e83b315f85e7bf` (commit 2026-10-27).

[Expanded review](../../docs/future/345-legacy-grid-filtering-review.md).
[Earlier baseline](320-grid-and-stores.md). [Deferred Bag JS ideas](340-bag-js-calculation-and-validation.md).
[Evidence](../../ports/PORT-0023-grid-and-stores/review-2026-10-28/README.md).

<a id="gc-345-005"></a>

## 005 · Assignment and scope

Owner requests renewed legacy-grid inspection for added filters/improvements;
exact words in expanded §005. September working files/cached refs were insufficient:
GitHub branch API and immutable raw files supplied current evidence. Manifest
fingerprints 22 upstream and seven local comparison files. No runtime port approval.

<a id="gc-345-010"></a>

## 010 · Column filter declarations

Legacy cell `filterField=True` uses its field; a field string uses another query
field. Grid `filterFieldDefault=True` enables eligible plain columns, including
configurator-built ones; False opts a column out. TableHandler forwards through
grid_filterFieldDefault. Default excludes composite/calculated/values/checkbox/
user-set/button cells; explicit composite filters have separate captions.
NewIncludedView supports the feature. VirtualSelection suppresses icons and
predicates: resident browser filtering is not complete remote filtering.

<a id="gc-345-015"></a>

## 015 · Popup values, counts and predicate composition

Distinct options/counts, search, checkboxes, natural ascending/descending order,
empty-last, clear and row counts. OR within column, AND across columns. Counts
apply other filters, ignoring the current column's own predicate. Zero-count and
selected-but-missing options persist. Different IDs with same caption stay distinct.
Null/undefined/empty string merge; other keys stringify (no typed-key guarantee).
Search appears above six options; normal rendering caps unchecked options after
200, but search/checked items bypass that cap. Counts still scan resident items.
Existing text/comparison and filter-set predicates compose with column filters.
filterValues/filterRange are stored in struct attributes; popup direction is runtime
state. This is not complete saved-view persistence qualification.

<a id="gc-345-020"></a>

## 020 · Date periods: code corrects an example's prose

Date/datetime From/To use inclusive local calendar-day comparisons/open bounds.
The example says period and checks exclude each other; code/tests instead allow
checks to refine a period. Empty checks inside a period match nothing; without a
period they clear the filter. Removing a period can retain checks. UI clearing
From also clears To. Do not copy the stale example prose into a future contract.

<a id="gc-345-025"></a>

## 025 · Filtered actions and interaction corrections

Static-selection print/batch use visible rows without explicit selection; raw
export respects even a zero-match projection. Batch assignment maps visible row
indexes correctly. Filter icons cannot initiate resize/column drag. Shared
tooltip anchoring follows ancestor scroll and cleans up on clipping, detachment,
close/destroy. Tests do not qualify DOM-scraping formatted export or real server
print/export execution.

<a id="gc-345-030"></a>

## 030 · Hierarchical grid from a path column

First-column hierarchical='/' (or another separator) builds a tree from flat
record paths; missing ancestors become synthetic rows. Visible depth-first
projection, sibling sorting, reload-preserved open state and collapse selection
handling are tested for value/attribute rows. Other columns warn; VirtualSelection
refuses the mode. Filtering covers the visible tree, not hidden remote descendants.
This does not define Gramlot hierarchicalStore or replace its tree.

<a id="gc-345-035"></a>

## 035 · Other reviewed improvements and retained formula behavior

Distinct values support value/attribute layouts and comma captions; legacy fallback
is not approved. Concurrent selection loads queue one latest-arguments follow-up,
not cancellation/latest-response publication. Headerless full-width templates,
flex minima, group/footer alignment and literal-template activation have source/
fixture evidence, no browser qualification here. Configurator remains separate
from the proposed whole-colgroup drag/independent scroll.

Legacy formula/calculated/formula_* and #/+=/%= remain; GridChangeManager writes
results via store.updateRowNode. totalize supports paths, filtered/selected totals
and separate server totals. Multiple selected rows take precedence over filter
scope. Owner chooses this model for now, with exact aggregate/API/activation
contracts still open. Regex dependency detection, error-to-null and dynamic eval
are not approved implementation requirements. Formula inspection is static,
separate from the 67 filtering/interaction tests.

<a id="gc-345-040"></a>

## 040 · Comparison with the PoC and design implications

PoC `10478b57ce3f22e6445eb6b72eba343520cbebac` has local filters/sort, bounded DOM,
formula writes and resident totals, but inspected grid/store sources lack the new
column popup/date UI/path-tree features. Discuss filter capability versus state,
remote store execution, explicit counts/totals/action scope including empty results,
and colgroup/filter/resize/popup interaction. Minimal grid scope stays owner-selected;
this is not an implementation plan or automatic legacy parity commitment.

<a id="gc-345-045"></a>

## 045 · Verification receipt

67 upstream Node VM tests pass: filters, periods/actions, tree mode, distinct
values, batch mapping, queued loads and tooltip lifecycle. Initial missing-source
failure resolved by retrieving same-revision gnrstores.js. Real methods with
stubbed browser/Dojo surfaces; no full browser/DB, performance, accessibility or
Python example execution claim. Manifest/log retain hashes and reproduction.
Paired docs, links, evidence and existing public checker verified. No runtime or
dependency source modifications.
