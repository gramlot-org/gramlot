# 335 · Bag formulas and data validation: legacy reminder

Document ID: **GC-335**. Updated: **2026-10-28**.

> **Historical record.** Legacy Python evidence for possible future store work;
> not an implemented Gramlot API or approved port.

[Expanded reference](../../docs/future/335-bag-formulas-and-validation.md).
[Collection model](330-collection-store-agent-brief.md).
[Port evidence](../../ports/PORT-0023-grid-and-stores/README.md).

<a id="gc-335-005"></a>

## 005 · Owner context and scope

Owner, 2026-10-28: a grid may declare formulas and write their results to a shared
store; another grid sees those values without declaring the formulas. The owner
then suggested future store-level formulas and requested a reminder about legacy
Python Bag formulas and validation. Exact words are retained in the expanded
§005. Research/documentation is authorized; no new formula/validation API,
replacement of grid formulas or implementation schedule is approved.

<a id="gc-335-010"></a>

## 010 · Sources and verification boundary

GenroPy `fa35e5adfa6ad1b269f3a22a9b12c4c1ee6513ea`, unchanged local evidence:
`gnrpy/gnr/core/gnrbag.py` (node reads/writes, symbols/formulas, BagValidationList,
BagFormula and invoice example) and `gnrpy/tests/core/gnrbag_test.py` (existing
validation case). Exact links in expanded §010;
[hashes](../../ports/PORT-0023-grid-and-stores/legacy-bag-formulas-evidence.json).
Verified import is historical `gnr.core.gnrbag` in `legacy` mode, not modern
`genro-bag`, JavaScript Bag or Gramlot.

<a id="gc-335-015"></a>

## 015 · Formula authoring and evaluation

`defineSymbol(q='quantity', p='price')` names paths; `defineFormula(amount='$q*$p')`
names expressions; `bag.formula('amount')` or `bag.formula('$q*$p', q='quantity',
p='price')` creates a BagFormula resolver installed as a node's value.
Symbols are captured at construction; paths resolve against the installed node's
containing Bag, including ancestors. `_`-prefixed symbols target resolvers
(inspected, not separately executed).

Default `cacheTime=0`, `readOnly=True` means recompute on read, without storing the
result or publishing derived-value updates. `readOnly` is not a write permission.
This differs from PoC grid formulas writing to the store. Python `eval` executes
the expression; no bounded language, dependency graph or cycle diagnostic is
established. Errors propagate on read.

<a id="gc-335-020"></a>

## 020 · Aggregates and chained calculations

Expressions can use ancestor parameters and aggregate child Bags, e.g.
`bag.formula("$rows.sum('#v.total')", rows='rows')`. The source invoice example
chains row totals, subtotal, tax and final total. Decimal multiplication works
with Decimal operands; Python semantics apply. Aggregates cover the addressed
Bag, not unloaded remote rows. Resident/window/projection/complete-result scope
remains a future decision.

<a id="gc-335-025"></a>

## 025 · Validation belongs to BagNode value assignment

Use `BagNode(validators=...)`, `setItem(..., _validators=...)`, or
`addValidator(path, validator, parameter)`. The ordered chain calls
`validator(value, oldvalue, parameter)`; each returns a possibly transformed value
or raises. Plain rejected scalar writes preserve the accepted value and emit no
update; there is no multi-field transaction. Adding a validator is not retroactive.
`oldvalue` is the current node value, not a child's loaded baseline or a conflict
check. Attribute writes bypass this value chain, so attribute-row and value-row
field validation are not automatically equivalent.

<a id="gc-335-030"></a>

## 030 · Built-ins and limitations to retain

`case` transforms strings; `inList` checks comma-separated strings; `length`
checks inclusive two-integer bounds; callables receive current old value.
Reproduced defects: `db` is a no-op; `hostaddr` has a dispatcher-arity mismatch;
unknown names print a message and return None, potentially erasing the value.
Do not carry those defects forward. `status`/`errMsg` are not a working status
protocol; `coerceFromText` is not wired into the chain. No async checks, UI error
contract, database constraints, uniqueness or concurrency guarantee follows.

<a id="gc-335-035"></a>

## 035 · Reminder for future Gramlot design

Retain data-owned calculations/validation as a possibility, alongside the owner's
current grid-formula direction. Before implementation decide lazy/materialized
results, dependencies/context/errors/cycles, writer ownership, aggregate scope,
value/attribute validation, save/conflict semantics and Source activation.
Data struct formula strings are not executable by default under constitution
11.53. Reuse current Bag/resolver/Source/binding/controller mechanisms; report
dependency gaps to their owners, with no workaround or old-runtime restoration.
No new names or runtime extensions are approved.

<a id="gc-335-040"></a>

## 040 · Verification receipt

All 11 [isolated probes](../../ports/PORT-0023-grid-and-stores/legacy-bag-formulas-probe.py)
passed on 2026-10-28, including the three legacy limitations; no network access.
All three expanded-document Python examples also executed successfully.
Existing pytest case inspected, not run: pytest absent in legacy environment.
No full suite, browser, modern Bag, DB transaction or cross-language claim.
No runtime/dependency edits. Paired anchors, local links, hashes and public-site
exclusion checked; `check_public_docs.py` passes on the existing 11-page public
build, which excludes this note. Expanded §040 contains the reproduction command.
