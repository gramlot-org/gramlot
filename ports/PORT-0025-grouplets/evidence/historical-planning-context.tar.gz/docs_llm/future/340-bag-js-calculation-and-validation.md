# 340 · Bag JS calculation and validation: deferred ideas

Document ID: **GC-340**. Updated: **2026-10-28**.

**Reminder only.** [Expanded reference](../../docs/future/340-bag-js-calculation-and-validation.md).
[Legacy Python evidence](335-bag-formulas-and-validation.md).
[Updated legacy grid review](345-legacy-grid-filtering-review.md).

<a id="gc-340-005"></a>

## 005 · Owner direction

Owner requests a future reminder and says that for now formulas and totals follow
legacy (exact words in expanded §005). Grid formulas are declared in the struct
and write shared-store results visible to other grids. Multiple grids do not
force a new store calculation engine. Exact APIs/aggregate scope remain open;
legacy defects, fallbacks and arbitrary Data formula execution are not approved.

<a id="gc-340-010"></a>

## 010 · What was found in the installed JavaScript Bag

**Inspection record:** installed `@genrojs/bag` metadata `0.11.0`, 2026-10-28;
not latest-upstream or Python parity. [Fingerprints](../../ports/PORT-0023-grid-and-stores/review-2026-10-28/manifest.json).
BagResolver/BagCbResolver already support callback resolution and cache policies;
reset invalidates for explicit reads. Both default readOnly=false, unlike legacy
BagFormula. Writable cache assignment suppresses node notifications. setValue
stores before hooks/subscribers, so these are not pre-write validation gates.
No legacy defineFormula/defineSymbol/BagValidationList equivalent was found in
the inspected public surface/value write path. reactive/interval resolver options
are explicitly rejected; do not restore them by inference.

<a id="gc-340-015"></a>

## 015 · Potentially useful primitives, still proposals

Evaluate existing resolvers for data-owned computed values. Consider explicit
validation before accepted assignment, covering values and attribute fields.
Placement in Bag, an extension or a store remains open. No new evaluator,
representation fallback or implementation is authorized.

<a id="gc-340-020"></a>

## 020 · Existing Gramlot responsibilities to preserve

Reuse dataFormula/bindings/controllers for reactive execution; FieldState and
validateInput already handle control candidates and presentation. Computation,
write validation, notification and persistence are separate. Current oldvalue
is not a child's baseline, client validation is not a DB constraint, and a lazy
formula does not automatically publish derived changes. Store-level declarations
remain deferred; dependency ownership boundaries still apply.

<a id="gc-340-025"></a>

## 025 · Questions for reopening this reminder

Require a concrete consumer; decide lazy/materialized publication, dependencies,
cycles, errors, rule ordering, rejection versus explicit transformation, async
candidate lifetime, value/attribute/row scope, server and save/conflict composition,
Source activation and Python/JS semantics. Names follow GC-225 only after decisions.

<a id="gc-340-030"></a>

## 030 · Completion and limits

Local static inspection, no new Bag JS tests or runtime/dependency changes.
Paired docs, links, hashes and public boundary checked. GC-335 and GC-345 retain
their separate execution evidence. This reminder is not a prerequisite for the
current grid work, which continues with legacy formulas and totalization.
