# 320 · Grid and store investigation

**Review supplement, 2026-10-28:** [GC-345](345-legacy-grid-filtering-review.md) examines newer legacy filters and adjacent improvements; the earlier snapshots below remain historical evidence. [GC-340](340-bag-js-calculation-and-validation.md) records deferred Bag JS ideas and the current legacy formula/totalization direction.

[English agent brief on PostgreSQL UNLOGGED selections](325-postgresql-unlogged-selections.md).

Document ID: **GC-320**. Investigated: **2026-10-25**.

**Investigation/proposals only; no implementation contract approved.** The owner
requested recovery of PoC grid/store evidence and the decisions needed for a clean
transfer. [Expanded evidence](../../docs/future/320-grid-and-stores.md).
[Port and probes](../../ports/PORT-0023-grid-and-stores/README.md).
[Status](../internal/070-work-status.md#gc-070-1725).

[Collection store concepts and open decisions for an agent (GC-330)](330-collection-store-agent-brief.md).

<a id="gc-320-005"></a>

## 005 · Conclusions and provenance

The PoC is substantial but not a transplantable subsystem. It has two collection
loading pipelines, grid/editor prototypes, form persistence and independent server
memory. Resolve ownership, projection/identity, formula activation, editing/save
and real paging before transfer. Existing tests pass but miss two reproduced
formula defects; filtered lookup also conflates data and view membership.

PoC: `10478b57ce3f22e6445eb6b72eba343520cbebac`, initially without reported local
changes. Core: working files over `d01bf3dc6389ad9bca91ef0f4bdbaafbfcc10242`, including
later local implementations. `ports/PORT-0023-grid-and-stores/evidence.tsv` fingerprints
files and distinguishes reviewed sources from search leads. Retained DB candidate:
`worktrees/gramlot-db-api-proposal`, not accepted architecture. Legacy knowledge
includes PoC audits/cards and direct store-source inspection for §§055–085; no fresh legacy UI execution or exhaustive archived
conversation review. External/dependency sources were not modified.

<a id="gc-320-010"></a>

## 010 · Recovered implementation map

PoC sources: `js/dom/src/stores/{bag-rows,collection-stores}.js`;
`collections/grid*.js`; `src/gramlot/{grid,store}.py`; Python `grammar/grid.py` and
`grammar/logic.py`; old runtime/renderer/server-call wiring; `database/common`,
`database/fake` and `database/service.js`; `forms/{stores,controller,value-snapshot}.js`.
Chart reuses BagRows; tree uses Bags/resolvers. `grid-store.js` only re-exports
BagRows. Selection/VirtualSelection/FileSystem are labels on a shared resident
implementation, not complete legacy classes.

Retained candidate has common read stores/fake adapter and twelve tests. Its old
GC-015/020/025 and PORT-0001 identifiers must not overwrite current core identities.

<a id="gc-320-015"></a>

## 015 · Four meanings of store, and two collection paths

1. Resident collection: Bag + index/projection, grid-owned or Source-registered.
2. Database read store: request/result/loading/error state; owns no UI persistence.
3. Form store: detached load/save; form owns dirty/validation/conflict policy.
4. ExclusiveBagStore: process-local server dictionary with leases, no rollback or
   multi-process guarantee; cancellation waits for worker lock release.

First collection route: bagStore/rpcStore → registry → BagRows → grid/form.
Second: dataSelection → DatabaseService/CollectionStore → BagDbReadAdapter/BagDB →
copy into application Data → another BagRows → grid. The second keeps private
request state plus a published consumer result. Decide authority explicitly.
Old RPC refuses busy calls; read stores cancel superseded work. Current dataRpc
already has latest-request behavior; do not port a second transport.

Data residency, editability, persistence and DOM virtualization are independent
dimensions. Missing versus unloaded identity, query revisions and edit overlays
outside an evictable cache are recovered design inputs, not remote guarantees.

BagDB is optional fake/local evidence: read adapter T/L/R/B, one scalar PK, equality,
literal text, ordering before limit, independent identity lookup. No cursor/exact
count/application writes. Each read copies the database snapshot. The 18-table,
17,538-row fixture is not performance or Decimal/date/cross-backend qualification.
Setup CRUD/save-on-close is not the read-store persistence contract.

<a id="gc-320-020"></a>

## 020 · Functional coverage recovered

Implemented PoC subsets: Bag/attribute rows; typed stable keys; projected filter/sort;
shared stores and one-page RPC replacement; mutable structure Bags; quickGrid/column;
bounded DOM viewport; frozen/resizable columns; measured/manual row heights;
none/single/multiple selection; local row/column reorder; real Source scalar editors;
suspended invalid drafts; async validation; external-write conflict checks; net-change
Bag; scalar popups; formulas/Decimal arithmetic; columnsets and automatic totals.

The Python playground includes a small live structure palette (heading/width/hidden/
order), despite older “no configurator” descriptions. Full configurator, saved views,
general grid context menus/export/print, checkbox/radio/userSets, explicit multirow
footers, virtual caching and collection persistence remain absent/incomplete.

One structure view/layout row only; Python columnset helper is absent from JS helper.
Array columns remain an old parallel path. Bag field reads fall back to attributes.
Filtering hides identity lookup; query state is shared by borrowers. Bounded DOM
still scans resident rows. No row-scoped #ROW, related-caption/multifield editor
contract, save acknowledgement, insert/delete changeset or undo history. `modal`
popup does not make the page inert. Changes log excludes external writes.
Form adapters are bounded memory/item/collection/subform/hierarchical/RPC record
load/save; model catalog does not provide field/fieldcell construction.

<a id="gc-320-025"></a>

## 025 · Conflicts and required adaptation to current Gramlot

Reuse current NodeBinding/DataRouter subtree registration, bagStore/setStoreBag,
typed Source, nodeId/symbolic references, component descriptors/generated Python
metadata, RPC/remote/dataRemote lifecycle, InlineCompiler activation, controls,
FieldState/ControlAdapter, formatter, popup/menu, publish/subscribe and drag/drop.
Tree storepath/selectedPath and bounded dbSelect/dbComboBox contracts already exist;
neither implies a general grid/store/read-record contract or permission to rewrite tree.

Do not copy BagRows' private `_parent` backref repair, pinned first-party dependencies,
old import aliases, tag-special renderer integration, direct Data formula evaluator,
or document-ID-based GridStatus mounting without reviewed current responsibility.
Report genuine dependency defects upstream; no installed-source fixes/workarounds.
Core stays host/ORM independent. DB/grid validation remains separately deferred.
Constitution §§13–14, 11.43/53/56/92 apply; no amendment or approval is created here.

<a id="gc-320-030"></a>

## 030 · Reproduced defects and semantic hazards

- **P1:** filter hides resident row `two`; identity lookup returns null and update
  of its original node throws. Observed contract hazard for shared forms/views.
- **P2:** field total with constant expression `'total'` throws a false dependency
  cycle because references are extracted with a regex. Reproduced defect.
- **P3:** batch a=10,b=20 leaves fa=a*2 at 2 instead of 20, while fb=b*3 becomes 60.
  Only the last event survives batching. Reproduced correctness defect.
- **H1–H4:** formula manager per grid can compete over shared Data; footer totals
  cover only the resident projection/page; full index/geometry work survives DOM
  virtualization; Data structure formulas bypass current Source activation if copied.
  These are source-grounded risks, not additional browser reproductions.

Retained probes deliberately assert the bad/current behavior for investigation.
No defect was fixed and no product acceptance follows from their success.

<a id="gc-320-035"></a>

## 035 · Decisions to settle in dependency order

All **open/proposed**, one owner decision at a time:

| ID | Decision to settle |
| --- | --- |
| D01 | Source-owned store independent of grid versus initial grid-owned adapter; recommend independent lifetime |
| D02 | Explicit Bag/attribute dialects versus one initial representation; no implicit fallback |
| D03 | Typed keys, label default, mutations/replacement and composite-key scope |
| D04 | Independent view projections versus shared query; recommend identity access outside filtering |
| D05 | Existing symbolic references versus necessary store registry, with GC-225 naming |
| D06 | Existing DataRouter, mutation events and complete batch invalidation |
| D07 | One structure Bag, bounded helpers/layout scope, disposition of array API |
| D08 | One local/remote read pipeline, result shape and Data-visible loading/error/stale state |
| D09 | Resident first slice versus real window/cache; offset/cursor/snapshot and refresh semantics |
| D10 | Calculation ownership, stored/view-derived fields, Decimal/null/errors and activated language |
| D11 | Dataset/filter/page/selection/server aggregate scope |
| D12 | Typed selection, missing/unloaded keys, focus/activation; separate check/radio/set semantics |
| D13 | Edit owner, Source controls, row context/relation outputs and draft/reload/removal policy |
| D14 | Save changesets, acknowledgement/canonical records/revisions, cancellation and undo |
| D15 | Common/fake/SQLAlchemy/Genropy/model capability boundaries; BagDB optional |
| D16 | Priorities for configuration, menus/clipboard, bands/checks/reorder/saved views |
| D17 | Optional packaging, Python/JS metadata and measurable performance/accessibility gates |

Do not reopen existing Python-first, typed Source, Bag Data, no-workaround,
dependency, tree, selector or ownership decisions. No implementation/release authorized.

<a id="gc-320-040"></a>

## 040 · Verification performed and its limits

Fresh: **75 PoC JS**, **14 PoC Python**, **12 retained DB candidate**, **67 current
core context tests** passed; three diagnostic observations reproduced. Exact commands
are in PORT-0023. Initial Python run had 13 passes and one obsolete loader-path
failure. Existing GRAMLOT_CLIENT_MODULES configuration resolved it; rerun 14/14,
one upstream Python deprecation warning. Node v23.11.0, PoC Python v3.14.

Gallery parity includes 5,000 attribute rows and bounded mounted rows in jsdom,
not a benchmark. Browser specs were inspected, not rerun; no fresh real DB/server
grid round-trip, Chromium/WebKit/touch/accessibility or remote-scale claim.
Paired anchors/local links checked separately from public documentation checks.

<a id="gc-320-045"></a>

## 045 · Proposed transfer sequence and acceptance gates

Proposal, not execution plan: A resident identity/projection/lifecycle; B read-only
grid/structure/selection; C editing/calculation; D common reads/paging; E persistence
and richer tools. Gates include two independent views, hidden identity lookup,
complete batches, actual Source removal, typed transport, live configuration/focus,
draft races/conflicts, multi-view formulas, fake/real provider agreement, off-page
lookup, cache/aggregate semantics and save acknowledgement. GC-110 stays completed.
Core fixtures stay independent; examples and backend examples belong downstream.
Original recommendation was D01; the subsequent owner request puts terminology alignment first (§055). No hierarchy or later decision is approved.

<a id="gc-320-050"></a>

## 050 · Evidence guide and historical corrections

Expanded §050 indexes grid architecture/legacy/structure/formula plans, collection
design and remote lifecycle checklist, check/radio usage audit, footer/configurator/
context-menu audits, 25-record/46-selection parameter audit, BagDB/model guides,
legacy inventory cards and Python playground/teaching/chart/database examples.

Early alpha omissions were superseded by later PoC code. Full configurator remains
absent but its small palette exists. VirtualSelection is only one-page loading.
September 17 added local dataRecord/dataSelection/fake work, without core acceptance.
BagDB moved out of Bag JS; old pinning language is superseded. Census declaration
absence does not prove internal behavior absent. Preserve history and do not promote
historical approvals into current product decisions.

<a id="gc-320-055"></a>

## 055 · Terminology analysis: levels, not a new hierarchy

Owner follow-up, 2026-10-25: “farei prima una analisi completa degli store che hai trovato per allineare la perminologiua”. Terminology alignment precedes D01; no name/design is approved. Definition census under PoC js/src, runtime and consumer inspection distinguishes declarations, instances, data, registries and loaders/savers. Additional direct legacy evidence is fingerprinted in [terminology-evidence.tsv](../../ports/PORT-0023-grid-and-stores/terminology-evidence.tsv).

| Name | Actual role |
| --- | --- |
| Bag / Data Bag | Data container |
| BagRows; ValuesBagRows / AttributesBagRows | Resident row access/projection; value/attribute representations |
| BagGridStore | BagRows export alias |
| bagStore / rpcStore | Source declarations |
| selectionStore / fsStore | Python helpers producing rpcStore declarations |
| CollectionStores | Plural registry/lifecycle manager |
| BaseStore / CollectionStore / SelectorStore / RecordStore | Separate database-read experiment |
| formStore; MemoryStore | Form configuration/factory; private snapshot implementation |
| ExclusiveBagStore / StoreLease | Python process-local shared-memory service / access lease |
| AuthoringNode.store | Property returning builder.data |
| storeTree / GnrStoreTree | Hierarchical UI consumer |

<a id="gc-320-060"></a>

## 060 · Resident rows and RPC collections

BagRows retains the original Bag; indexes/subscriptions provide keyed/indexed access. Edits change original nodes, while filter/sort project without reordering the Bag. Grids can own or borrow it; charts also use it. Borrowers of one instance share its filter/sort projection; independent views are not supplied by the registry. ValuesBagRows fixes nested-Bag fields (PoC includes attribute fallback); AttributesBagRows fixes attribute fields. These representations are evidence, not destination approval. Default key is node label; configured identifier reads a field; keys are unique nonempty strings or finite numbers, including zero. Projection position is not identity. PoC lookup indexes only projected rows, causing P1 hidden-row/form lookup failure.

CollectionStores owns Source node/code/path/adapter/subscription entries, rejects duplicate code/path ownership, and disposes on unregister. Borrowing grids do not own disposal. bagStore wraps existing Data; rpcStore converts endpoint rows/identifier/metadata into an attribute-row Bag. selectionStore supplies Selection/VirtualSelection labels (chunkSize selects the latter), not distinct classes. loadPage replaces one resident page. fsStore defaults directory_selection and path identity; flat rows, no filesystem edit protocol. totalRows can describe remote cardinality while len describes the resident projection. None establishes multi-page caching, random access or global totals.

<a id="gc-320-065"></a>

## 065 · Database-read request state

BaseStore in database/common/stores.mjs stores loading/stale/error/result at a Data path; detached snapshots, microtask notifications, latest-request cancellation per lane. Errors retain stale results; abort is not an application error; invalidate aborts and marks stale. CollectionStore load calls adapter.query; lookup calls readRecord without replacing query results; loadMore explicitly unsupported. SelectorStore reads metadata, searches prefix then contains only after zero hits, maps value/caption options and resolves identities separately. RecordStore reads a record, with no save/delete/edit session.

This family neither extends BagRows nor belongs to CollectionStores. Read adapters supply origin operations, ModelCatalog supplies metadata, BagDB is the local database laboratory; none is a synonymous store or accepted core backend. DatabaseService manages read stores in private Bags and publishes provider outputs to Data. dataRecord/dataSelection are declarations. RPC→resident Bag→BagRows and adapter→request/result state→Data are distinct paths; accepted current-core selectors remain separate contracts.

<a id="gc-320-070"></a>

## 070 · Form load/save adapters

FormController owns baseline/draft/dirty/validation/conflict policy; stores load detached copies and commit them. Python formStore configures the enclosing form, not the collection registry. JS mostly returns plain adapters.

| Type | Load / save | Limits |
| --- | --- | --- |
| memory | Private MemoryStore snapshot / replace snapshot | No durability |
| item | Data Bag at storepath / replace Bag | Local item |
| hierarchical | Same implementation as item | No extra hierarchy behavior |
| subform | Selected storeFields / merge into parent Data Bag | No full parent-form coordination |
| collection | Existing storeCode/storeKey row / update it | Fixed identity; no insert/delete/navigation/off-page fetch; P1 applies |
| record | loadmethod returning Bag / savemethod with key and draft | RPC persistence, distinct from read-only DB RecordStore; no version protocol |

Non-memory adapters guard the loaded identity/location against save to a different one; this is not remote optimistic locking. Save may mean only local Bag replacement. Detached copies are not transactions or undo history.

<a id="gc-320-075"></a>

## 075 · Other uses of store and resolver

ExclusiveBagStore belongs to host PageRegistry and page contexts; string-keyed Bags in one Python process, exclusive whole-operation lease, thread ownership, detached boundaries. Async cancellation retains ownership until worker completion. No rollback, durability, multi-process coordination or browser row view. StoreLease is its access mechanism. AuthoringNode.store returns builder.data.

Resolver computes a node value; PoC RpcResolver coalesces pending work and caches by time. It is not a query/save interface. fileSystemTree builds a lazy hierarchy through provider/resolvers, unlike flat fsStore. relationTree/storeTree are not collection-store subclasses.

<a id="gc-320-080"></a>

## 080 · Historical record: legacy correspondence

Direct read-only GenroPy inspection at fa35e5adfa6ad1b269f3a22a9b12c4c1ee6513ea; no legacy execution or revival approval. Three separate families:

- gnr.GnrStoreBag/Grid/Query in gnrstores.js: Dojo Read/Write/Identity/Notification adapters; Grid resolver fetch/paging; Query query/identity and value cache.
- gnr.stores in genro_components.js: _Collection→BagRows→Values/AttributesBagRows; AttributesBagRows→RpcBase→FileSystem; **AttributesBagRows→Selection→VirtualSelection**. _Collection includes Source, locks/protection, topics and linked widgets. Legacy sort physically reorders Bag and identity can fall back to label; PoC differs. RpcBase/FileSystem have deletion support. Selection includes DB live updates; VirtualSelection manages pages/pending pages/server sort/selectionName/counts. PoC labels do not reproduce them.
- gnr.formstores in genro_frm.js: Base→SubForm/Item/Collection/Hierarchical. Structural kind and action handler kind are independent axes. Handler variants include memory/record/rpc/document/recordCluster; PoC flattens some into one storeType enum. Legacy Collection navigates parent collection and supports memory CRUD; PoC only existing-row load/update. Legacy SubForm integrates parent form; PoC merges selected Data fields. Legacy Hierarchical is empty in inspected source; PoC aliases item behavior.

Legacy Python helpers create BagStore/SelectionStore declarations; virtualSelectionStore delegates to selectionStore. directoryStore writes resolver-produced Data, tableAnalyzeStore composes Data/RPC, externalStore supplies cross-database join metadata. Database store name is not browser collection storeCode.

<a id="gc-320-085"></a>

## 085 · Discussion vocabulary and limits

Origin/backend = where data comes from/is persisted; collection = records together; resident = currently loaded; projection = filtered/sorted access. Query selection differs from UI-selected rows, selector options and current form record. Identity differs from position/path. storeCode identifies registry entry; storepath locates Data; identifier specifies key field; storeKey is selected key. store/storeBag are context-dependent (grid code/Bag, builder Data, tree, server), not a universal type. Page/chunk is not full virtual cache. Dirty draft differs from stale reads or remote conflict. Save need not be durable, transactional or undoable.

Concrete path: declaration→code/Data path→resident Bag→BagRows→grid; collection form copies one keyed row and save updates that row. Remote persistence requires a separate contract; neither DB RecordStore nor ExclusiveBagStore implicitly provides it. Next align vocabulary with the owner before architectural choices. D01 deferred, not accepted/rejected. Runtime unchanged; §040 test evidence retains its original scope. Legacy comparison is static, not browser/DB parity qualification.

<a id="gc-320-090"></a>

## 090 · Historical record: legacy collection stores

Owner requested the actual legacy collection stores and their characteristics. Direct source: genro_components.js:6586–8183, declaration widgets, form Collection navigation, server get_selection.py/misc.py; static inspection only. A collection store governed a row set for linked grid/form consumers, locating data in a Bag and supplying row access, loading and change coordination. This is the gnr.stores family, not PoC CollectionStores registry.

Hierarchy: _Collection→BagRows→ValuesBagRows/AttributesBagRows; AttributesBagRows→RpcBase→FileSystem; AttributesBagRows→Selection→VirtualSelection. Selection does not extend RpcBase.

_Collection supplies Source-relative data path/rebinding/clear, row/index/key access, filtering, linked-grid discovery/broadcast, locks/protection inherited from parent form, explicit loading blockers, visible-client gating, operation prompts and extension hooks. Filter mapping belongs to the instance; getData(true) copies projected rows. Shared consumers share filtering. rowBagNodeByIdentifier uses filtered lookup, so hidden-row lookup already fails in this legacy path. Values keyGetter uses rowFromItem label fallback; Attributes rowFromItem has fallback but keyGetter directly reads the configured attribute.

BagRows deep-copies loaded data; selfUpdate preserves selection/reapplies filters. Local delete removes Bag nodes by supplied labels. Updates dispatch to nested-value or attribute specialization; sorting mutates Bag; sums use those representations. Dirty/error inspection reads _newrecord/_loadedValue/_validationError markers, not a standalone save/conflict protocol. RpcBase loads via the Source provider, gates by visibility, reports loading, resets filter and reloads after configured deletion. FileSystem defaults app.deleteFileRows; neither has Selection's DB reconciliation.

Selection adds query load/count-only for title counters, view-derived columns and server totals; DB event subscriptions (default LOCAL via isLocalPageId, PAGE current page, NO disabled), exclusions, pending events, visibility/form-operation/delay/activity gates. It rechecks changed keys against query membership, inserting/updating/removing locally or reloading above the default 0.3 change ratio or for totals/applymethod/fullReloadOnChange. It preserves selected identities, notifies selected-row/editor/external-change state and postpones sort while editing. Remote duplicate/delete/unlink/archive/counter operations use Genro services; not universal create/save.

VirtualSelection retains P_N page Bags, pending requests and selectionName; index maps to page/offset. It fetches missing pages, prefetches adjacent pages, suppresses some scrolling requests, emits updateRows and clears cache on reload; no bounded LRU observed. Server getSelection freezes/unfreezes and sorts a named selection, then emits row_start/row_count slices. Browser paging does not imply database-cursor streaming. Entire-selection keys and sums use server services. DB changes check frozen-selection relevance then reload with selected identities. Frozen result is not a transaction. Local filtering scans loaded pages; filteredRowsIndex explicitly unimplemented; identity lookup searches cached data; some row retrieval can be synchronous. Do not infer full off-page lookup/global local filters/bounded memory/race-free requests.

Separate gnr.formstores.Collection consumes parent collection ordering/filtering for first/last/next/previous navigation. Python declarations configure widgets that instantiate stores: bagStore normally ValuesBagRows; selectionStore Selection/VirtualSelection according to chunkSize; rpcStore/fsStore RpcBase/FileSystem. Actual family combines row representation, origin and loading strategy with grid/form/server coordination. This descriptive recovery approves no destination architecture.


<a id="gc-320-095"></a>

## 095 · Owner clarification: one collection contract, different implementations

Owner clarification, 2026-10-25:

> il concetto era buono ma si era stratificato nel tempo
> di fatto ogni collectyon strire espione gli stessi metodi ma a seconda del tipo li implementa in modi diverso

The conceptual model to recover is a common collection-store method contract, implemented differently by each store type. Historical layering does not invalidate that abstraction. The preceding class inventory describes how the legacy realized and accumulated responsibilities; it must not be interpreted as a proposal for unrelated consumer-facing interfaces.

This confirms the conceptual reading, not a complete destination API: method inventory, signatures, semantics, asynchronous behavior, capabilities and implementation structure still need examination and explicit decisions. A shared public contract does not by itself require copying the legacy inheritance tree. No new API, class hierarchy or runtime implementation is approved here. Next analysis should map the common methods to their type-specific implementations and identify semantic differences or incomplete legacy implementations.


<a id="gc-320-100"></a>

## 100 · Owner clarification: origin, copy/reference and dirty context changes

Owner examples, 2026-10-25, clarify the conceptual collection contract beyond §095:

- “inoltre i collection store aveva anche la possibilita di essere filtarto” and “e poi aveva modo di essere sortato”: filtering and sorting belong to the collection abstraction.
- “tipicamente la 'view' chiede allo store la prossima riga o la riga numero x”: grids and other views consume a common row-access contract, independent of value-Bag versus attribute-Bag row representation. The owner describes the store's data as always a Bag; this does not settle class inheritance or require each returned row to have a newly specified representation.
- The region/provinces example clarifies two valid alternatives: copying the selected region's province Bag into a working store, versus directly referencing that original Bag. Owner: “sono due modi alternativi validi entrambi a seconda del contestop”. In copy mode load creates the working copy and save writes back to its origin, even entirely in memory. In direct-reference mode edits reach the original immediately. This later concrete example resolves the earlier ambiguous use of “referenziato” versus “condiviso”; direct reference here means immediate shared edits.
- The same context change can load provinces through an RPC. Owner: “se cambio regione sebza salvare mi aspettp che mi chieda se salvare le modifiche oppure annullarle”. A change that would replace edited data must therefore offer saving or discarding the pending edits before replacing them. This requirement applies to a copied in-memory collection and to the RPC example; save is not synonymous with remote persistence.

In the example, pending Lombardy edits belong to the Lombardy origin, while the proposed next load targets Campania. Saving commits the previous working data to its previous origin, then the next context can load; discarding abandons the pending working edits before that load. The origin/context of the working data must not be confused with the requested next context. Direct-reference editing has already modified the original; the owner has not specified a rollback mechanism for that mode.

These are owner-confirmed conceptual requirements and examples, not an implemented API. Exact method signatures, dirty-state ownership, responsibility for displaying the question, save-error handling, request ordering, a possible cancel-navigation choice and rollback semantics remain unspecified. No hierarchy, new handler, persistence format or runtime implementation is selected by this record. Continue terminology/contract discussion before implementation.


<a id="gc-320-105"></a>

## 105 · Owner clarification: contextual database autosave

Owner, 2026-10-25: “anche per lo store su db in realra esiste una modalita 'autosave' per cui se sono in edit e cambio riga viene fatta una rpc per modificare immediatamente o aggiungere o eliminare. ovviamente vale in certi contesti ma di fatto bisogna tenerne conto”.

The model must account for contextual database autosave as well as explicit save. The owner describes leaving an edited row as a trigger for an RPC write, and includes update, insert and delete operations. This is not a requirement to save on each keystroke or to enable autosave universally. The precise insertion/deletion triggers are not separately specified. This record captures the owner's stated behavior and requirement; it does not claim a newly verified current-core implementation.

Data origin and save policy are distinct aspects of the discussion: an RPC/database-backed collection can use explicit save or contextual autosave. Autosave still performs a write operation across a service boundary; it is not the same mechanism as directly sharing an in-memory Bag. The dirty-context guard from §100 must account for the selected policy and any outstanding write rather than assuming every edit always prompts for manual save.

Validation, write acknowledgement, failed/pending writes, row/context switching during those writes, assigned identities after insertion, deletion timing and responsibility for coordinating the interaction remain to be specified. No defaults, API, state machine or implementation ownership are approved by this note. Continue conceptual contract alignment before implementation.


<a id="gc-320-110"></a>

## 110 · Owner-completed conceptual scope: static collection stores

Owner conclusion, 2026-10-25: “qundi sono modalita analoghe
ora hai tutto relativamente ai collection store statici.” This closes the owner's conceptual explanation of static collection stores. It does not authorize runtime implementation or declare the preceding PoC/legacy implementations accepted.

Additional owner evidence since §105:

- Filesystem: “potrei ricevere ad esempio un certo numero di documenti cone metadati ed editare i documenti in una form”. A collection can present documents with metadata and support document editing through a form; this scope is broader than a read-only file listing. Exact content-loading and metadata/content persistence protocols are not specified.
- Generic service: “una rpc ad un servizio generico anche esterno che mi rende una cosa che posso mettere in una bag”. An RPC service, including an external service, can provide data that becomes the collection's Bag. No arbitrary conversion API or universal write capability is inferred.
- In-memory row representation: “una bag di attributin (con value nullo) o una bag di valori”. These are analogous collection representations: attribute rows have null node values with fields in attributes; value rows have fields in nested value Bags. The common store contract shields consumers from that storage distinction. This is a concrete supported conceptual alternative, not permission for arbitrary representations or compatibility fallbacks.

Consolidated model from §§095–110:

| Aspect | Owner-described scope |
| --- | --- |
| Consumer contract | A grid or other view requests rows, including positional/sequential access; collection filtering and sorting are part of the abstraction |
| Data representation | Bag data, with the two analogous in-memory row layouts described above |
| Origin | In-memory Bag/path, database, filesystem documents/metadata, generic RPC service (possibly external) |
| In-memory relationship | Working copy with save back to the original path, or direct reference with edits immediately affecting the original |
| Load/save | Origin-specific implementation behind common collection behavior; save also has meaning entirely in memory |
| Save policy | Explicit save, or contextual database autosave; do not generalize all combinations to all origins |
| Context changes | Pending edits require save/discard handling before replacement; autosave must be taken into account; previous working origin remains distinct from the requested next origin |
| Editing | Row operations, and document editing through a form in the filesystem example; exact integration responsibilities remain to be designed |

Treat these as dimensions of the described model rather than a list of unrelated consumer interfaces. They do not establish that every origin supports every write operation, both reference modes or every save policy. The owner has completed the conceptual scope of static stores; exact methods/signatures, asynchronous and error semantics, ownership and implementation design remain separate work. The label static is retained as the owner's scope label, not inferred to mean read-only, synchronous or unable to load through RPC. No virtual-store requirements are added by this conclusion.


<a id="gc-320-115"></a>

## 115 · Virtual-store options and query scope before optimization

Owner discussion, 2026-10-25: legacy named selections associated an identifier (typically described as a 22-character UUID) with a query result pickled on the server. The browser retained non-contiguous pages and fetched missing blocks on demand. The owner raised server-side materialization in an untracked database table and full IndexedDB population through a Worker as alternatives, leaving DOM handling for a separate decision. These are options raised for evaluation, not chosen destination implementations or a mandated identifier format.

Subsequent owner steering: “ogni soluzione ha pregi e difetti, in realta basterebe dire ai clienti che è inutile che prendano 300000 ckienti assien++”. This puts the usefulness and scope of the query before engineering for indiscriminate full-result browsing. It does not establish a numeric row cap, reject every legitimate large collection, or approve a specific search UI. A proposed practical direction is to help users narrow a query, reserving virtualization for justified result sizes and treating full client replication as an option needing a concrete use case and measurements.

Read-only technical evidence gathered during the discussion:

- Legacy selection.py separates pickle metadata and full row data; _freeze_data('r') calls pickle.load on the full data file. _gnrbasewebpage.py delegates freeze/unfreeze through page-local paths. The existing getSelection handler slices the resulting selection for a requested block. This supports a potential full-unpickle cost, not measured latency or a claim that every layer rereads on every request.
- Existing PoC grid.js:457–480 clears/rebuilds its bounded visible row window with overscan, while retaining resident data separately. This is not evidence about Dojo DOM retention or a destination implementation decision. Its resident-data geometry costs remain subject to the earlier investigation.
- IndexedDB is available in Workers and supports indexed structured data; browser storage has quotas and eviction policies. Moving work to a Worker does not eliminate total transfer/storage cost, and ordinary object messages use structured cloning rather than sharing Bag instance identity. A serialization contract preserving Bag semantics would need review, not ad hoc dependency workarounds.
- A server-side indexed materialization, browser page cache, persistent client replica and bounded DOM window are different concerns. The owner's “untracked” table is not automatically PostgreSQL UNLOGGED; that interpretation is unconfirmed. If UNLOGGED were selected, PostgreSQL documents crash truncation and lack of standby replication.

Primary references consulted: [MDN IndexedDB](https://developer.mozilla.org/en-US/docs/Web/API/IndexedDB_API), [indexed access](https://developer.mozilla.org/en-US/docs/Web/API/IndexedDB_API/Using_IndexedDB), [Worker messaging](https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API/Using_web_workers), [structured clone](https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API/Structured_clone_algorithm), [storage quotas/eviction](https://developer.mozilla.org/en-US/docs/Web/API/Storage_API/Storage_quotas_and_eviction_criteria), [PostgreSQL CREATE TABLE](https://www.postgresql.org/docs/18/sql-createtable.html). These verify platform properties, not performance on Gramlot's workload.

No choice of pickle replacement, IndexedDB replica, Worker ownership, DOM lifecycle, paging API or automatic query limit is approved. No large-dataset benchmark or runtime implementation was performed. Core remains independent of server/database technology; implementation placement would need destination review. Next discussion should start from actual user query needs before selecting a virtual-store strategy.


<a id="gc-320-120"></a>

## 120 · Standard protocols and established virtualization patterns

Owner question, 2026-10-25: “esistono soluzioni'standard' ?”. Primary-source research distinguishes formal protocols, established data-access patterns and rendering libraries. None is a universal Bag collection-store contract or automatically determines persistence/editing behavior.

| Area | Established reference | Relevance and limits |
| --- | --- | --- |
| Positional paging | SQL LIMIT/OFFSET; OData skip/top | Requests a portion by position/count. Requires deterministic ordering; large SQL offsets can still compute skipped rows. The interface does not guarantee efficient random access or stable snapshots across concurrent changes. |
| Cursor paging | GraphQL Cursor Connections specification | first/after and last/before with opaque cursors/pageInfo. Suitable for successive pages; no inherent arbitrary row-number jump or prescribed efficient database implementation. Cursor is not synonymous with a live database cursor. |
| Stable search context | Elasticsearch point-in-time plus search_after | Established example of retaining a consistent view over multiple requests; related purpose to named selections, but not the same storage/materialization or positional-access implementation. |
| Client block cache | AG Grid Server-Side Row Model | Requests start/end row ranges, retains blocks, supports bounded cache, request concurrency and scroll-load debounce. This specific AG Grid model is Enterprise; cited as a design reference, not chosen dependency. |
| DOM virtualization | TanStack Virtual | Headless visible-range/measurement utility with framework-independent core; renders a bounded visible/overscan window through the consumer renderer. Does not fetch data, save records or make server paging unnecessary. |

Formal protocol reference: [OData 4.01 OASIS Standard](https://docs.oasis-open.org/odata/odata/v4.01/os/part1-protocol/odata-v4.01-os-part1-protocol.html) defines filter/orderby/skip/top/count and server-driven paging. [GraphQL Cursor Connections](https://relay.dev/graphql/connections.htm) specifies cursor/page metadata conventions rather than a universal storage strategy. Further primary references: [PostgreSQL LIMIT/OFFSET](https://www.postgresql.org/docs/current/queries-limit.html), [Elasticsearch paging/PIT](https://www.elastic.co/docs/reference/elasticsearch/rest-apis/paginate-search-results), [AG Grid cache configuration](https://www.ag-grid.com/javascript-data-grid/server-side-model-configuration/), [AG Grid cache/request controls](https://www.ag-grid.com/javascript-data-grid/server-side-model-api-reference/), [TanStack Virtual](https://tanstack.com/virtual/latest/docs/introduction), [framework-independent core](https://tanstack.com/virtual/latest/docs/installation), [rendering versus data virtualization](https://tanstack.com/table/latest/docs/framework/react/guide/virtualization).

Proposed reference direction only: a paged collection with bounded resident blocks and a separately bounded DOM window is close to the legacy model and established grid practice; IndexedDB full replication is not a prerequisite. The critical distinction is arbitrary positional access versus cursor traversal. A service that only exposes successive pages cannot promise cheap access to row 300,000 without additional indexing/materialization or traversal. Origin-specific optimization remains outside the portable core. No adoption of OData, GraphQL, AG Grid, TanStack, Elasticsearch or a new backend is approved, and no benchmark or implementation was performed.

<a id="gc-320-125"></a>

## 125 · Owner-specific PostgreSQL selection direction

Owner, 2026-10-25: “la version e che usero io si basera su slezioni salvate su postgres”. Selects saved PostgreSQL selections for the owner's implementation, not a core PostgreSQL dependency or runtime assignment. Owner reports 400,000 rows saved in under one second, fluid scrolling and search/sort/group/filter; historical owner evidence, not rerun here. Subsequent request seeks January–March branches including client work. §130 recovers February 2026 sources; generic backend alternatives are background for this owner-specific choice.

<a id="gc-320-130"></a>

## 130 · Historical record: PostgreSQL branch recovered

Main ref: **sql_review/freezed_to_sqlite_pg**, **9353aa448ba868307b1a4b24bce8933abd735c18**, **2026-02-16**; local and cached origin tips agree. Not an ancestor of inspected cached origin/develop; no fetch, so no claim about current remote merges or independent reimplementations. Distinct source from the October checkout reviewed earlier. No checkout/edit of external sources. [Ten historical source/test digests](../../ports/PORT-0023-grid-and-stores/postgres-branch-evidence.tsv); [five branch tips](../../ports/PORT-0023-grid-and-stores/postgres-branch-refs.tsv).

Supporting branches: feature/freezed-selection-tests (107b005800, Feb 12); feature/refactor-freezed-selection (25acf811fe, Feb 12); feature/freezed_to_sqlite (265500812d, Feb 15); sql_review/lazy_selection (94894a082f, Feb 14). Related commit issue references #477/#481/#486/#488 were not independently read as issue discussions. PostgreSQL introduced 480c6c98fd Feb 14; direct-query path 9353aa448b Feb 16; later-page search seed fix 265500812d Feb 15.

Server: GnrFreezedSelections proxy delegates to Pickle/Sqlite/Unlogged, with shared Sql base. Preference sys.freeze_backend or page use_freeze_backend chooses backend. PostgreSQL stores UNLOGGED tables in _qc plus filesystem unlogged_meta.json, with _rowidx and unique index. This resolves the concrete recovered implementation behind “untracked”; no generic naming inference remains needed here.

Fast path: apphandler obtains outputTableName, passes _outputTable before execution; SqlQuery wraps CREATE UNLOGGED TABLE AS SELECT with row_number()-1; _dofetch avoids fetching all rows into Python and retains count/output metadata; freeze adds index/metadata; first page comes through getFromFreezedSelection. Explains mechanism, not a measured timing. Historical query-recreation/row-insert fallbacks, exception catching and type conversion are not approved port paths.

Page reads use ORDER BY/LIMIT/OFFSET against saved SQL rows and rebuild only that page as SqlSelection/grid Bag. Index presence is not an ordinal range-seek claim. Search creates a tokenized LIKE/ILIKE VIEW over text columns, optional visible-column restriction, filtered COUNT/SUM metadata and JSON search state; clearing seed restores original. State reuse compares seed only; concurrency, changed columns, and unused searchOn_field need review, not claimed executed defects.

Client: th_view.py binds searchOn_seed to searchbox Data; genro_grid.js switches virtual non-pickle search from local filter to store.loadData and restores echoed freezed_search_seed without recursive search. SearchBox input events and token highlighting added. VirtualSelection page requests carry searchOn_seed plus selectionName/start/count/sort/table, preserving search while scrolling. Application-preference check on client versus server page override needs review.

CleanupSelection/Page/Orphans/All methods exist; automatic lifecycle wiring not verified. Full unfreeze/key retrieval still load full results. The paged saved-selection API has search/sort/sums but no group_by parameter; group_by/having exist in initial getSelection query. Dedicated regrouping over an already saved selection not established by this snapshot.

Tests inspected: web suite uses PostgreSQL source site but freezes through pickle/SQLite only; does not parameterize PostgreSQL UNLOGGED backend. Lazy suite has PostgreSQL variants but is not a 400,000-row/browser benchmark. No tests/DB mutations/browser run executed; source/ref hashes and paired links/anchors checked. Owner timing remains owner-reported. Expanded view links exact source lines. Recovery complete; next bounded contract comparison needs its own owner scope, no copy/implementation authorized.


<a id="gc-320-135"></a>

## 135 · JSONL Worker and composed SQL measurements — 2026-10-25

Historical checkpoint before the subsequent full-run instruction and completed measurements in §140.

Owner requested 500,000 × 30 business fields in a Worker using Asqueel-JS migration and the existing TYTX/JSONL adapter. TYTX 0.16.4 supplies toTytxIter/fromTytxIter. Core RPC still reads a complete response, so the experiment is an isolated loopback fixture, not a Gramlot streaming RPC implementation. No dependency source was edited or storage contract adopted.

The 1,000-row smoke passed migration/import/integrity/query/reopen checks in about 957 ms for the streaming pipeline. Owner interrupted the full run at the last reported 280,000 rows / 216.884 s: no full-run final verification, commit confirmation or memory result. The agent chose 1,000-row batches; one transaction covered the full stream. No full run restarted.

Owner then requested composed SQL. Same 30-column dataset, migration-created SQLite/IndexedDB database; individual sequential samples including composition and commit, excluding network/migration/data generation:

| Path | Rows | Time / outcome |
| --- | ---: | --- |
| Current sql_insert | 1,000 | 915.1 ms |
| Concatenated INSERTs, one adapter call | 1,000 | 23.2 ms |
| Multi-row INSERT, bound values | 1,000 | 19.3 ms |
| Multi-row INSERT, literals | 1,000 | 17.7 ms |
| Multi-row INSERT, bound values | 10,000 | Too many SQL variables; rollback verified |
| Multi-row INSERT, literals | 10,000 | 172.6 ms; 4.37 MB SQL |

Apple M4 / 24 GiB, Chromium 156, wa-sqlite 1.0.0 / SQLite 3.44.0. Actual variable limit: 32,766, allowing 1,092 rows × 30 independent parameters in one statement. Successful cases verify count/key sum and 30-field samples. No 500,000-row composed statement tested. Fifteen TYTX iterator tests passed.

Earlier attribution solely to individual INSERT preparation was incomplete: concatenated individual statements also perform much better. Per-record Asqueel compilation/invocation/binding needs profiling; no precise attribution established. The literal encoder is a fixed-schema probe, not a general serializer or approved Gramlot workaround. Any production optimization belongs in Asqueel and must preserve types/defaults/generated values/partitions/transactions. Source hashes identify Asqueel's locally modified working source. [Method and results](../../ports/PORT-0023-grid-and-stores/benchmark/README.md); [expanded limitations](../../docs/future/320-grid-and-stores.md#gc-320-135).


<a id="gc-320-140"></a>

## 140 · Completed 500,000-row loads and query replacement — 2026-10-25

Owner explicitly resumed full-scale measurement across block sizes and required considering early display and changing query after 30 rows. Isolated fixture only: TYTX JSONL → Worker → Asqueel SQLite/IndexedDB; first commit 30 rows, then one raw SQL multi-row INSERT/commit per block. The first page is read from SQLite and delivered to a blank main-thread fixture, not rendered in a grid. No dependency/runtime edits or store API acceptance.

Fresh Chromium 156 per case, Apple M4 / 24 GiB; one sample per size. Same **404,890,606-byte** loopback response; **205,320,192-byte** logical database. Memory is summed browser-process RSS sampled every second over load and validation, not exact Worker memory.

| Block | Load to last commit | First 30 at main | RSS sum | New first page after switching during INSERT |
| --- | ---: | ---: | ---: | ---: |
| 1,000 | 10.449 s | 99.6 ms | 749.9 MiB | 42.4 ms |
| 10,000 | 10.064 s | 98.5 ms | 925.8 MiB | 145.3 ms |
| 50,000 | 11.486 s | 97.7 ms | 1,392.4 MiB | 700.0 ms |

Switching immediately after the first 30 delivered a new first page in 22.6–24.2 ms. Old HTTP production stopped at 1,024 rows / about 0.81 MB; 128 decoded, 30 committed. During-INSERT cancellation acknowledgement/cleanup was 25.2 / 130.7 / 685.4 ms. The 1,000-row block finished before cancellation was processed; 10,000/50,000 blocks rolled back. All old temporary databases were deleted, new 120-row queries verified, and deliberately replayed stale pages rejected. This tests synthetic HTTP-producer cancellation, not actual PostgreSQL query cancellation. No SQLite interrupt is exposed; incoming messages and cleanup are cooperative. Replacement is serial in the same Worker.

Nine final smoke cases plus three full loads/six replacements passed count/key-sum/full-width sample/reopen/cleanup checks. No main-thread long tasks; blank-page frame intervals around 16.7 ms. However, deep LIMIT/OFFSET reads took 1.28–1.45 s midway and 2.57–2.70 s near the end, versus 0.8 ms on the first page. Loading performance does not establish smooth scrolling; indexed ordinal/range access needs design/testing. Including validation/read/reopen/cleanup, complete cases took 19.6–20.9 s rather than the 10–11.5 s loading interval.

The 10,000-row sample's ~4% advantage is not statistically established. No fixed/adaptive size adopted. Open: early commit/publication; incomplete collection semantics for sort/filter/count; cancellation/cache retention; streaming RPC/upstream cancellation; ordinal access; general typed SQL optimization in Asqueel. [Results](../../ports/PORT-0023-grid-and-stores/benchmark/results/bulk-500000.json), [reproduction](../../ports/PORT-0023-grid-and-stores/benchmark/README.md), [expanded detail](../../docs/future/320-grid-and-stores.md#gc-320-140).


<a id="gc-320-145"></a>

## 145 · PostgreSQL saved selection versus full Worker materialization — 2026-10-25

Owner asks which approach is preferable. Interpretation: retain the selection in PostgreSQL and send requested pages, versus ship all rows into the Worker. This evaluates the owner's existing PostgreSQL direction; no new runtime contract approved.

Isolated PostgreSQL 17.7 cluster, private Unix socket, defaults/durability on, warm source/OS cache. Same 500,000 × 30 records; initial COPY setup excluded. Three UNLOGGED materializations with deterministic row_number() OVER (ORDER BY id)-1 and unique _rowidx index:

- Materialization + index: **499–532 ms**; including ANALYZE: **745–757 ms**.
- Indexed range pages of 30 at start/middle/end: **0.027–0.054 ms SQL execution**.
- OFFSET halfway/end: **39.6–41.4 / 77.3–81.2 ms**.
- Filter/sort without supporting index: **22.2–23.1 ms**; GROUP BY: **37.0–50.6 ms**.
- Selection plus indexes: **217,849,856 bytes**. Integrity/ordinal/page/sample checks passed; isolated cluster stopped and removed.

These SQL-stage timings exclude HTTP/TYTX/RPC/rendering and final commit acknowledgement, unlike the Worker's measured 404.9 MB full transfer/import in 10–11.5 s. Do not compare PG range to SQLite OFFSET as equivalent algorithms; SQLite indexed range remains unmeasured. The result supports PostgreSQL-retained pages for large online collections because full-result transfer is avoided. Client materialization may suit complete-local-data workloads. Per-selection server resources/lifetime/concurrency remain unmeasured.

Outstanding: actual paged RPC/first paint/scroll under realistic latency, prefetch/cancellation, ordinal mapping after filter/sort, and multi-user selection lifecycle. The filter/group timings do not establish reindexed derived selections. [Raw results](../../ports/PORT-0023-grid-and-stores/benchmark/results/postgres-500000.json), [expanded method](../../docs/future/320-grid-and-stores.md#gc-320-145), [reproduction](../../ports/PORT-0023-grid-and-stores/benchmark/README.md).
