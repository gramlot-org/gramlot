# 320 · Grid and store investigation

**Review supplement, 2026-10-28:** [GC-345](345-legacy-grid-filtering-review.md) examines newer legacy filters and adjacent improvements; the earlier snapshots below remain historical evidence. [GC-340](340-bag-js-calculation-and-validation.md) records deferred Bag JS ideas and the current legacy formula/totalization direction.

[English agent brief on PostgreSQL UNLOGGED selections](325-postgresql-unlogged-selections.md).

Document ID: **GC-320**. Investigated: **2026-10-25**.

**Status: investigation and proposals; no grid/store implementation contract is approved by this document.**
The owner requested an accurate recovery of grid/store evidence from gramlot-poc,
exposing decisions for a clean, coherent transfer. This authorizes the investigation,
not bulk copying or implementing the proposals below.

[Concise counterpart](../../docs_llm/future/320-grid-and-stores.md).
[Port evidence and executable probes](../../ports/PORT-0023-grid-and-stores/README.md).
[Current status](../internal/070-work-status.md#gc-070-1725).

**Owner follow-up, 2026-10-25:** “farei prima una analisi completa degli store che hai trovato per allineare la perminologiua”. Sections 055–085 provide that terminology analysis. Discussing D01 is deferred until terminology is aligned; no name, hierarchy or contract is approved by this analysis.

[Collection store concepts and open decisions for an agent (GC-330)](330-collection-store-agent-brief.md).

<a id="gc-320-005"></a>

## 005 · Conclusions and provenance

There is substantial reusable behavior, but no single finished grid/store subsystem
ready to transplant. The PoC contains **two different collection-loading designs**,
a resident row adapter, a substantial grid/editor prototype, separate form
persistence adapters and an unrelated process-local shared store. Their names and
successful tests do not establish a common product contract.

The most consequential findings are:

1. Store identity lookup currently depends on the filtered view. A resident record
   can disappear from a form's lookup simply because a grid filter hides it.
2. The PoC grid owns formula writers even when several grids share one store.
   Calculation ownership must be settled independently of presentation.
3. Bounded DOM rendering is implemented; complete remote virtualization is not.
   A paged RPC store replaces one page, and local totals cover only its resident view.
4. Grid editing reuses real Source controls and validation, but confirmation only
   changes resident data. It is not a save protocol, transaction or undo history.
5. Two formula defects were reproduced beyond the existing passing suite: batch
   updates can leave derived values stale, and string literals can create false cycles.
6. Current Gramlot already provides routing, RPC cancellation, Source activation,
   controls, validation, menus, popup infrastructure and drag/drop responsibilities.
   PoC-specific copies or integration hooks must not displace these mechanisms.

Evidence baselines:

| Source | Inspected baseline | Authority and limits |
| --- | --- | --- |
| [gramlot-poc](https://github.com/gramlot-org/gramlot-poc/tree/10478b57ce3f22e6445eb6b72eba343520cbebac) | `10478b57ce3f22e6445eb6b72eba343520cbebac`; no local changes reported at initial inspection | Code/tests are evidence; September decisions are historical and do not approve this transfer |
| Current core | Working checkout over `d01bf3dc6389ad9bca91ef0f4bdbaafbfcc10242`, including later local implementation | Actual inspected files are fingerprinted in the port inventory; the base commit alone does not reproduce them |
| Retained DB candidate | Sibling `worktrees/gramlot-db-api-proposal` | Earlier proposal and executable comparison; not accepted core architecture |
| Legacy GenroPy | September PoC audits, followed by direct store-source inspection at `fa35e5adfa6ad1b269f3a22a9b12c4c1ee6513ea` for §§055–085 | Directly reviewed sections are fingerprinted in `terminology-evidence.tsv`; the legacy UI was not executed |

The port's `evidence.tsv` records repository, path, review level and SHA-256.
The inventory contains 213 entries: 180 PoC, 27 core and six retained-candidate files.
86 entries have directly reviewed sections; 21 identify executed test files (seven
also have reviewed sections). Search-indexed files are discovery leads, not claims that every line or archived
conversation has been audited. Primary files and the consequential comparisons
below were read directly. No external checkout or dependency source was modified.

<a id="gc-320-010"></a>

## 010 · Recovered implementation map

All PoC paths in this section are relative to its recorded revision.

| Area | Primary sources | What is actually there |
| --- | --- | --- |
| Resident row access | `js/dom/src/stores/bag-rows.js` | BagRows, ValuesBagRows, AttributesBagRows; identity, reads/writes, filter/sort, subscriptions, batching |
| Shared collection lifetime | `js/dom/src/stores/collection-stores.js` | Source-owned registry, code/path uniqueness, resident and RPC loading, page replacement, teardown |
| Store declarations | `src/gramlot/grammar/logic.py`, `js/dom/src/logic/runtime.js` | bagStore/rpcStore; selectionStore/fsStore lower to rpcStore; install/remove hooks |
| Old transport bridge | `js/dom/src/services/server-call.js` | Provider delay, busy refusal, result/error handling and obsolete-owner suppression |
| Grid viewport | `js/dom/src/collections/grid.js` | Bounded DOM rows, geometry, frozen columns, selection, resizing, reconnect lifecycle |
| Structure | `collections/grid-structure.js`, `collections/grid-authoring.js` under `js/dom/src`; `src/gramlot/grid.py`, `src/gramlot/grammar/grid.py` | Structure Bag and authoring helpers, plus retained array columns |
| Editor | `js/dom/src/collections/grid-editor.js`, `grid-cell-popup.js`, `grid-status.js` | Source-mounted scalar editors, drafts, validation, net changes, popup and status presentation |
| Calculations and bands | `js/dom/src/collections/grid-formulas.js`, `grid-bands.js` | Dependency ordering, Decimal arithmetic, resident calculations, grouped headers and automatic totals |
| Interaction | `js/dom/src/collections/grid-interactions.js` | Selection ranges/toggles and local row/column reorder |
| Renderer/authoring seams | `js/dom/src/contrib/html/html-builder.js`, `source-bag.js`, `builder-base.js`, `js/pages/src/builder.js` | Tag-specific wiring, event publication, resize writeback, quickGrid structure generation |
| Database read experiment | `js/dom/src/database/common/{stores.mjs,read-adapter.mjs,model.mjs,bagdb.js}`, `database/fake/bagdb-read-adapter.mjs`, `database/service.js` | Distinct Base/Collection/Selector/RecordStore hierarchy, model catalog and local database |
| Form persistence | `js/dom/src/forms/{stores.js,controller.js,value-snapshot.js}` | memory/item/collection/subform/hierarchical/record adapters and form policy |
| Shared server memory | `src/gramlot/store.py`, `tests/test_shared_store.py` | ExclusiveBagStore/StoreLease; process-local dictionary of Bags under a whole-operation lock |
| Other consumers | `js/dom/src/collections/chart.js`, `storetree.js`; filesystem and selector sources | Chart reuses BagRows; tree consumes a Bag/resolvers; selectors have their own provider contracts |

`grid-store.js` is only a re-export of BagRows as BagGridStore. It is not another
engine to preserve. `Selection`, `VirtualSelection` and `FileSystem` names in the
collection registry are type labels on the same resident adapter, not three complete
implementations of the corresponding legacy classes.

The retained DB worktree contains `adapters/db/common/src/stores.mjs`, the fake
adapter, design documents 015/020/025 and a twelve-test suite. Its follow-up record
explicitly moves active experimentation to the PoC. Its historical document IDs
and PORT-0001 must not be imported over current core IDs/PORT-0001.

<a id="gc-320-015"></a>

## 015 · Four meanings of store, and two collection paths

| Meaning | State and owner | Consumer | Port consequence |
| --- | --- | --- | --- |
| Resident collection | Original Bag plus derived row index/projection; grid-owned or Source-registered | Grid, chart, collection form adapter | Separate record storage, view projection and lifetime |
| Database read store | Loading/stale/error/result in a designated Bag; Source service owns an instance | dataRecord/dataSelection/dbSelect experiment | Settle a single loading contract using existing core providers |
| Form store | Load/save of detached edits; FormController owns dirty/validation policy | Form | No implication of grid save support |
| Shared process store | Server dictionary of Bags under exclusive lease | Server operations | Separate from browser data views and database selections |

Actual collection routes:

```mermaid
flowchart TD
    A[PoC bagStore / rpcStore] --> B[CollectionStores registry]
    B --> C[BagRows over application Data]
    C --> G[Grid]
    C --> F[Collection form adapter]
    D[PoC dataSelection] --> E[DatabaseService and CollectionStore]
    E --> R[BagDbReadAdapter and BagDB]
    E --> P[Copy result into application Data]
    P --> Q[Another BagRows adapter]
    Q --> G
```

This diagram describes the PoC, not the proposed destination class hierarchy.
In the second route the service retains private request/result state and publishes
another consumer Bag. Deciding which state is authoritative is necessary before
combining it with the first route.

RPC collections refuse overlapping work as busy. Database read stores cancel the
previous request in a lane and suppress obsolete results, including when a provider
ignores cancellation. Current core dataRpc already follows latest-request behavior.
Do not transplant the old ServerCallService merely to retain its busy policy.

Keep four independent dimensions explicit: resident versus partially loaded data;
read-only versus editable data; in-memory versus persistent storage; and full versus
virtual DOM rendering. A remote read-only collection and a local editable grid are
both possible. Neither a store class name nor a viewport implementation chooses
the other dimensions. The recovered architecture proposal also distinguishes a
missing record from an unloaded one, query revisions from row identities, and edit
overlays from evictable page caches; these remain design inputs, not implemented
remote guarantees.

BagDB is an offline fake/local experiment, not a grid prerequisite. Its adapter
advertises reads, metadata, equality/literal text, ordering and T/L/R/B, but no
cursor, exact total count or application writes. It requires one scalar primary
key, sorts before applying a limit and resolves identities independently of the
loaded result. Each operation copies the database snapshot through `db.bag`.
The full fixture contains 18 tables and 17,538 rows; that does not establish
large-grid performance, Decimal/date parity or cross-backend compatibility.
BagDB's setup CRUD and save-on-close are distinct from its read-only adapter.

ExclusiveBagStore detaches returned values, checks lease/thread ownership and keeps
the lock until async worker completion even on cancellation. Exceptions release
ownership but do not roll back changes. It is neither a multi-process store nor
a database transaction or browser synchronization protocol.

<a id="gc-320-020"></a>

## 020 · Functional coverage recovered

“Implemented” below means present in the inspected PoC, not accepted into core.
Fresh verification is bounded by §040.

| Capability | Observed implementation | Limit or decision exposed |
| --- | --- | --- |
| Row representations | Nested Bag fields (`bag`) and node attributes (`attr`) | Bag mode additionally falls back to attributes; no automatic approval of both paths/fallback |
| Row identity | Label by default or explicit field; rejects missing/duplicate keys; accepts string/finite number, including zero | Identity mutation, composite keys and selection across unloaded rows unresolved |
| Shared consumers | Multiple grids borrow one registered BagRows; each has its own selection | Filter/sort belong to the shared store and affect every borrower |
| Local filter/sort | Project without reordering the source Bag | Lookup/update membership is restricted to the visible projection |
| Remote loading | Typed rows/identifier/metadata validated before replacement; prior data retained after errors | Registry status partly lives on JS objects rather than bound Data |
| Paging | chunkSize/loadPage, offset/limit, totalrows validation | One resident page; no multi-page cache, cursor protocol or unloaded selection |
| Filesystem | fsStore flat RPC selection and resolver-based fileSystemTree | Distinct from a complete filesystem store; current core filesystem work must be reused |
| Structure | Mutable Data Bag: view → rows → cell attributes; stable column labels; `info.columnsets` | One view and one layout row; not record rows; no complete Dojo layout parity |
| Authoring | quickGrid/column produce structure Data; Python GridStruct helpers | Old explicit `columns` arrays remain as a second path; Python has columnset helper absent from JS helper |
| Typed display | Shared formatDisplay, dtype/format/mask/locale/places | Must use current Gramlot formatter and typed-value contract |
| Viewport | Overscan and bounded mounted rows; fixed/measured/manual heights | All resident rows still inspected for geometry; all visible columns mounted |
| Geometry | Elastic zero width, pixel widths, resize/cancel, frozen columns and horizontal synchronization | No general width-unit parity; no measured performance budget or complete mobile/accessibility qualification |
| Selection | none/single/multiple, shift ranges, Ctrl/Cmd toggles; selectedKey/selectedKeys | External selection need not scroll; filtering/page change can clear selection |
| Activation | Enter/double-click row event, unless editable cell opens editor | Event payload and keyboard edit entry need current contract |
| Reorder | Bag-node-preserving row moves and structure-column moves | Disabled for sorted/filtered rows; no persisted reorder, keyboard reorder or drag auto-scroll |
| Cell editing | Ordinary Source control in stable slotted host; typed draft; Enter/Tab confirmation, Escape cancellation | No generic `#ROW` context or multi-field selected_* projection into row |
| Invalid drafts | Suspended controls retain validation and bindings across viewport redraw | Memory cost grows with retained drafts; removal/refresh policy must be explicit |
| Concurrent edit | Same-cell external value and replaced/deleted row checked at confirmation | Not revision-based conflict resolution or remote save concurrency |
| Change log | First old value and latest confirmed value; returning to baseline removes entry | Excludes external changes; no insert/delete changeset, save acknowledgement or undo/redo |
| Popup editor | Same scalar editor/validation in browser top layer | `modal` does not make the page inert; no arbitrary nested Bag form/contentCb |
| Formula fields | Dependencies, initial calculated flag, hidden formulas, reactive/passive parameters | Grid-owned writer; regex dependency extraction; separate dynamic JS and bounded Decimal evaluators |
| Special calculations | Index `#`, running `+=field`, percentage `%=field` | Operate over current store projection; not unloaded server selection |
| Footer/group bands | Contiguous columnsets split at frozen boundary; numeric/Boolean totals and bindings | Automatic single footer only; no arbitrary explicit footer rows/spans/server totals |
| Configuration palette | Python playground edits heading, pixel width, hidden state and row order directly in the real structure Bag | Functional small configurator exists; full legacy configurator, formula/group/style editing and saved views do not |
| Context menus/export | Legacy audits and proposed composition | No complete grid menu/plugin/export/print pipeline in this recovered grid |
| Checkbox/radio columns | Ordinary Boolean editor exists; detailed legacy audit recovered | checkboxcell/checkboxcolumn, row radio, per-row choice groups, userSets and remoteUpdate are separate missing contracts |
| Form persistence | Local replacement/subset merge, existing collection row update, explicit RPC load/save | No collection insert/delete/navigation, generated keys or server canonical record reconciliation |
| Model-driven columns | Metadata/model catalog and bounded eager relation tree | field/fieldcell construction, richer models and lazy model tree remain open |

The PoC chart already demonstrates a second BagRows consumer with separate data
and structure and shared selection through Data. That is useful evidence for a
non-grid-specific store, not authorization to port D3/chart functionality here.

<a id="gc-320-025"></a>

## 025 · Conflicts and required adaptation to current Gramlot

Current core has no general grid, CollectionStores or dataRecord/dataSelection
implementation in the inspected maintained sources. It does have relevant foundations:

| Existing core mechanism | Evidence | Consequence for the port |
| --- | --- | --- |
| Bag subtree observation | `binding/runtime.js` registerPointers, `binding/router.js`, `view/html.js`; tree descriptor `bagStore`/setStoreBag | Reuse the existing Data route; do not add widget-owned duplicate Bag listeners |
| Current tree contract | PORT-0017; GC-225 §070; `components/tree.js` | storepath is a plain Bag path; selection is store-relative selectedPath. Do not rewrite the tree or add a store alias by inference |
| Component descriptors | `components/registry.js`, generated Python collections | Define through current metadata, lifecycle and packaging; do not copy gnr-grid and tag-special cases |
| Source and references | Typed SourceBag/SourceBagNode, nodeId and current references | Review whether existing symbolic references can identify a Source-owned store before proposing another global registry |
| RPC and remote lifecycle | `binding/providers.js`, `remote.js`, RpcHandler, dataRemote | One transport/cancellation path; test actual Source removal and rebind |
| Code activation | `binding/inline.js` InlineCompiler; constitution 11.53 | Formula strings stored in a Data structure cannot automatically be executed with the PoC's independent `new Function` path |
| Inputs and validation | PORT-0010/0013, FieldState and ControlAdapter | Reuse controls/async validation and preserve a single accepted-value writer; old FormField internals are not the current API |
| Database selectors | PORT-0016, `components/database-choices.js`, `src/gramlot/db/__init__.py` | Typed identities and current selector RPC exist; do not reintroduce the PoC's string-ID bridge or assume a generic DB contract was approved |
| Formatting, popup, menu and messaging | Current formatter, popup infrastructure, menu/menuline and Source publish/subscribe | Compose existing services; no grid-specific replacement bus/menu engine |
| Drag/drop | Current renderer drag/drop and tree payload preparation | Grid row/column semantics need adaptation to this layer; do not copy an independent drag coordinator |

Specific prohibited carryovers under constitution §§13–14 and 11.92:

- BagRows manually inspects `_parent` and repairs nested Bag backrefs. This is a
  PoC dependency workaround, not a portable store responsibility. Inspect current
  upstream behavior with a contract reproducer; report any real remaining defect
  to its owning library. Do not copy the repair or alter installed dependencies.
- The old guide explicitly keeps array columns for compatibility. §13 does not
  authorize retaining this alongside structure Bags without a concrete owner choice.
- PoC packages pin old first-party Git revisions and use old import names. Preserve
  those versions only as evidence; new setup follows current dependency policy.
- GridStatus mounts into an element found by a document-wide ID and watches the
  document with MutationObserver. Review a Source composition/reference solution
  using existing mechanisms before reproducing this coupling.
- Model/provider code cannot import ORM, host or GenroPy services into core.
  SQLAlchemy/SQLite integration remains in the Python integration repository.
- DB/grid validators were explicitly deferred from input validation; neither
  ordinary editing nor client-only duplicate checks establish remote uniqueness.

No constitutional amendment is proposed or recorded as approved. A new contract
must name concrete responsibilities and reuse existing mechanisms; classes in the
PoC do not justify an identical class hierarchy in the destination.

<a id="gc-320-030"></a>

## 030 · Reproduced defects and semantic hazards

The retained `probes.mjs` runs against an explicitly supplied PoC checkout and
asserts the **observed problematic behavior**, not desired product behavior.

| ID | Reproduction / source | Result and consequence |
| --- | --- | --- |
| P1 | BagRows: hide row `two` with a filter; lookup and update by original BagNode | Row remains in underlying Bag, lookup returns null, update throws “Row does not belong to this store”. Identity access and view membership are conflated; collection-form loading shares this lookup |
| P2 | GridChangeManager: output field `total`, expression `'total'` | Throws dependency-cycle error although the expression is a constant string. Regex token extraction is not a JavaScript dependency parser |
| P3 | Two calculated fields `fa=a*2`, `fb=b*3`; batch writes a=10 then b=20 | fa stays 2 instead of 20, fb becomes 60. BagRows retains only the last event, so the change manager misses one dependency. Batch notification must retain all affected paths or invalidate the relevant scope |
| H1 | GridChangeManager constructed for each mounted grid | Several views can each write derived fields into the same shared store. Conflicting formula ownership is a design hazard; a multi-view conflict runtime was not executed |
| H2 | GridBands.render sums `store.keys()`; current paged store holds one page | A footer can display a loaded-page/filtered subtotal as though it were a whole-query total unless scope is explicit |
| H3 | `_renderRows` calls `_measureRows`; geometry loops over store.size; BagRows rebuilds indexes on changes | Bounded DOM is not bounded processing. No throughput/latency guarantee follows from the 5,000-row fixture |
| H4 | Formula compiler and edits to structure stored in Data | Trust/activation and dynamic-configuration behavior need a current Source-based contract; a working PoC formula is not authorization for arbitrary Data code execution |

P2/P3 are reproducible PoC correctness defects. P1 is observed behavior whose
acceptability depends on the chosen collection-versus-view contract; it must not
be silently inherited. H1–H4 are source-grounded risks, not claims of newly
executed browser failures. None was fixed as part of this investigation.

<a id="gc-320-035"></a>

## 035 · Decisions to settle in dependency order

Every row below remains **proposed/open**. Discuss one decision at a time and
record the owner's actual confirmation and scope. Recommendations are not approval.

| ID | Decision | Alternatives and recommendation | Why it precedes implementation |
| --- | --- | --- | --- |
| D01 | Store lifetime relative to the grid | Recommend a Source-owned collection service that can outlive/serve multiple views; alternative is a grid-owned adapter for the first slice | Establishes ownership, teardown and sharing without requiring a tree rewrite |
| D02 | Row representation | Explicit Bag-valued and attribute-valued dialects, or one initial dialect; reject implicit field fallback unless separately approved | Determines field addressing, transport, metadata and editor writes |
| D03 | Record identity | Define typed keys, label default, immutable/mutable identity, replacement and composite-key scope | Separate Bag labels, database keys, BagNode identity and view index |
| D04 | Dataset versus view | Recommend independent filter/sort projections over shared data, with identity lookup outside the projection; explicitly shared queries remain possible | Resolves P1 and interference between grids/forms/selectors |
| D05 | Store reference and naming | Assess existing Source nodeId/symbolic references versus a necessary named registry; settle declarative spelling under GC-225 | Avoid storeCode/path registries with duplicate lifetime or collisions in repeated fragments |
| D06 | Change notification and batching | Reuse DataRouter; define affected fields/order/reset/error events and whole-batch invalidation | Prevent P3; settle reactive responsibilities before formulas and editing |
| D07 | Structure authoring | Recommend one authoritative structure Bag with bounded helpers; decide one-view/one-row scope and whether any array API is needed | Preserves mutable configuration without speculative compatibility |
| D08 | Loading and read results | Align local/remote reads with current providers; define typed rows, missing records, metadata and Data-visible loading/error/stale state | Reconciles the two PoC pipelines without a second request framework |
| D09 | Paging and large collections | First resident slice versus real remote window; choose offset/cursor/snapshot semantics, cache bounds and refresh behavior before implementing remote virtualization | DOM virtualization alone cannot meet this contract |
| D10 | Calculation ownership and language | Prefer one owner per derived dataset; decide stored versus view-derived values, dependency declaration, Decimal/null/error behavior and activation of editable formulas | Resolves P2/H1/H4; existing dataFormula is a mechanism to assess, not an automatic row engine |
| D11 | Aggregate scope | Distinguish complete dataset, filtered view, loaded page, selected rows and server aggregate | Prevent misleading footers and percentages |
| D12 | Selection semantics | Row identity output, multiple selection, external/missing/unloaded keys, activation and focus; treat checks/radios/userSets separately | Preserves typed identities through sort/filter/reload and avoids accidental writes |
| D13 | Edit-session boundary | Recommend current Source controls/validation; settle row context, relation caption/selected_* writes, invalid drafts, removal and reload | Cell confirmation is not save; decide whether sessions belong to a view or shared editing service |
| D14 | Persistence and history | Separate local mutation from insert/update/delete changesets, save acknowledgement, canonical server records, revisions, cancellation and undo | Neither changes Bag nor form record adapter supplies the complete contract |
| D15 | Model/backend scope | Agree common minimum/fake/SQLAlchemy/Genropy boundaries and capabilities; BagDB remains optional evidence | No automatic ORM/model dependency for resident grids; dataRecord/dataSelection still need their own approved contract |
| D16 | Extended grid behavior | Prioritize configurator, menus/clipboard, grouped bands, explicit footers, check columns, reorder and saved views | Each has an independent service and acceptance boundary; legacy parity is not a bulk-port instruction |
| D17 | Packaging and qualification | Optional grid collection and portable Python/JS metadata using current conventions; choose measurable row/column/draft budgets and browser/accessibility gates | Avoid unconditional heavy dependencies and unsupported performance claims |

Already settled constraints are not reopened: Python-first applications; ordinary
Data Bags and typed Source; no application DOM/state bypass; first-party dependencies
unpinned; current tree storepath; current selector scope; core/host/database ownership;
explicit owner decisions; separate authorization for release/deployment.

<a id="gc-320-040"></a>

## 040 · Verification performed and its limits

Fresh runs on 2026-10-25:

| Suite | Result | What it establishes |
| --- | --- | --- |
| PoC JS, 11 focused files | **75 passed** | Grid, integration, editor, formulas, collections, form adapters, DB read/runtime/model, BagDB and full dataset |
| PoC Python, 5 files | **14 passed** with configured client modules | Grid authoring/transport, shared server store, BagDB declarations, Python/JS gallery parity and filesystem |
| Retained DB candidate | **12 passed** | Earlier read-store contracts remain reproducible against current PoC utility; not product acceptance |
| Current core, 4 focused files | **67 passed** | Tree, database selectors, router and hooks are an executable reuse baseline |
| Additional investigation probes | **3 observations reproduced** | P1/P2/P3 above; successful probes document limitations rather than certify correct behavior |

Initial Python run: 13 passed and gallery parity failed because the default loader
still points to the old sibling `gramlot-dom/tests/dom.js`. Re-running all five
files with the existing `GRAMLOT_CLIENT_MODULES="$PWD/build/test-client"`
configuration passed all 14. No source or dependency repair was made. One upstream
Python deprecation warning remains. Node was v23.11.0; PoC Python v3.14.

The gallery parity test includes a 5,000-row attribute fixture and checks a bounded
mounted row count. It is jsdom qualification, not a latency/heap benchmark.
The JS tests include mocked transport; a fresh real database/server/browser grid
round-trip was not run. Playwright `grid-editor.spec.js` and `states-grid.spec.js`
were inspected, including environment-dependent skips; their historical success is
not counted as a fresh run. No new Chromium/WebKit, touch, assistive-technology,
remote-cache or production-load qualification is claimed.

The port records exact commands and selected suites. Investigation artifacts have
paired anchors and local-link checks; public documentation checks are separate.

<a id="gc-320-045"></a>

## 045 · Proposed transfer sequence and acceptance gates

This is a review sequence, **not an approved execution plan** and not an addition
to the completed GC-110 release plan. PORT-0023 retains this investigation;
implementation slices must be bounded after the owner settles their contracts.

| Proposed slice | Useful outcome | Required evidence before acceptance |
| --- | --- | --- |
| A. Resident collection contract | Typed identity, original Bags, explicit projection and ownership | Two consumers with independent filters; hidden-row identity lookup; nested/attribute changes; replacement; complete batch invalidation; removal/rebind |
| B. Read-only grid and structure | Python-first grid, typed display, stable selection and bounded viewport | Python/JS metadata/transport parity; live structure edits; sort/filter/delete selection; focus/keyboard; measured large resident fixture; theme/mobile checks |
| C. Editing and calculations | Existing controls/validation with explicit derived-data ownership | Drafts across recycling, async validation and late results; row/store replacement; relation outputs; multi-view formulas; Decimal and P2/P3 regressions |
| D. Common read services and paging | One local/remote contract and honest partial-data behavior | Fake plus a chosen real provider; stable ordering before limit; off-page lookup; request races; cache invalidation; authorization in host; no late writes after Source removal |
| E. Persistence and richer tools | Reviewed changesets/save, bands, configuration, menus/check columns | Save failure/canonical response/conflicts; dirty navigation; undo policy; named total scope; clipboard/menu context after changes; cleanup and accessibility |

Each slice tests itself on core-owned fixtures. Demonstrations belong in
gramlot-examples; backend-specific examples belong to the relevant integration.
Portable core tests must not depend on either. The old examples are recovery
material, not application files to copy wholesale.

Original recommendation: **D01, collection lifetime independent of grid**.
The owner's subsequent request places terminology alignment first (§055).
Neither step decides D02–D17 or authorizes implementation.

<a id="gc-320-050"></a>

## 050 · Evidence guide and historical corrections

Read these PoC sources together, at the revision in §005:

- `docs/development/grid-legacy-audit-2026-09-11.md`,
  `grid-architecture-proposal-2026-09-11.md`, `grid-structure-legacy-2026-09-11.md`,
  `static-grid-plan-2026-09-11.md`, `static-grid-implementation-2026-09-11.md`,
  `handoff-static-grid-2026-09-11.md`, `grid-formulas-plan-2026-09-11.md`:
  origin, structure distinctions, initial scope and planned acceptance.
- `docs/development/collection-stores-2026-09-11.md`,
  `collection-store-design-2026-09-12.md`, `store-port-2026-09-13.md`,
  `remote-store-integration-checklist-2026-09-13.md`: store families, ownership,
  partial paging and remote/repeated-fragment lifecycle cases.
- `docs/development/grid-checkbox-radio-legacy-audit-2026-09-13.md` and
  `grid-checkbox-radio-sourcerer-usage-2026-09-13.md`: four distinct check/selection
  models, legacy usage and server-update boundaries.
- `docs/development/grid-footers-columnsets-legacy-audit-2026-09-14.md`,
  `grid-configurator-legacy-audit-2026-09-14.md`,
  `grid-context-menu-legacy-audit-2026-09-14.md`: full legacy horizon versus bounded prototype.
- `docs/development/datarecord-dataselection-legacy-audit-2026-09-15.md`:
  25 named record and 46 named selection server parameters plus open keyword
  families; common/optional/Genropy membership is proposed, not accepted wholesale.
- `docs/development/020-bagdb-laboratory.md`, `021-bagdb-library.md`,
  `025-abstract-database-model.md`, `ports/PORT-0001-bagdb-read-stores/README.md`:
  later read-store and model work; supersedes early statements that all such work is absent.
- `docs/guides/static-grid.md`, `docs/examples/grid-editor/{README.md,pages/index.py,pages/playground.py}`,
  `docs/examples/teaching/{21-grid-records,22-grid-attributes}`,
  `docs/examples/chartbox`, `docs/examples/bagdb`: executable scenarios and their limits.
- `gramlot_inventory/legacy-census/cards`: grid/quickgrid, GridEditor, GridStruct,
  bag/rpc/selection/virtual/filesystem/form stores, TreeGrid and specialized wrappers.
  Census entries marked “to implement” can refer to missing public legacy declarations
  even where a differently integrated internal prototype exists.

Historical corrections established by the current sources:

| Older statement | More precise reading now |
| --- | --- |
| First alpha lacks editing/formulas/filtering | Later PoC modules implement bounded versions; earliest checklist is not the final inventory |
| Static guide says columnsets/editor declarations unimplemented | Later GridBands/GridEditor and playground implement a subset |
| Configurator audit says no implementation | A small live structure palette exists; full configurator remains absent |
| Store port says VirtualSelection exists | A labelled paged resident store exists; full virtualization does not |
| Earlier DB notes say dataRecord/dataSelection/fake absent | September 17 local BagDB path implements bounded versions; core acceptance is still pending |
| Old port describes BagDB in Bag JS and requires a pin | Later owner correction places it in PoC Gramlot common code; current constitution forbids first-party pins |

Recovering these distinctions is part of the port preparation. Do not rewrite the
PoC's historical records or convert their old approvals into current product decisions.

<a id="gc-320-055"></a>

## 055 · Terminology analysis: objects, declarations and responsibilities

This is a descriptive vocabulary for the recovered implementations, **not a new
Gramlot API or a proposed class hierarchy**. The census of class/function definitions
under PoC `js/` and `src/` was checked against the runtime implementations and their
consumers. Unrelated occurrences of the English verb “store” are not components.

The word **store** crosses several levels that must be identified before comparing
names: a declaration in Source, the object it creates, the data that object reads,
a registry owning instances, and a service that loads or saves data. A shared word
does not imply shared inheritance, state or lifecycle.

| Found name | Kind of thing in the PoC | Responsibility |
| --- | --- | --- |
| `Bag`, Data Bag | Data container | Holds nodes/values/attributes; not a query or save policy |
| `BagRows` | Resident row adapter | Gives indexed/keyed access to rows in an existing Bag, with a filtered/sorted projection |
| `ValuesBagRows`, `AttributesBagRows` | BagRows subclasses | Fix where row fields are read: nested Bag values or row attributes |
| `BagGridStore` | Export alias | Another name for BagRows, not another implementation |
| `bagStore`, `rpcStore` | Source declarations | Register local rows or RPC-loaded rows in the collection registry |
| `selectionStore`, `fsStore` | Python declaration helpers | Produce rpcStore declarations with type labels and parameters |
| `CollectionStores` (plural) | Registry and lifecycle manager | Owns named collection entries, paths, bindings and disposal |
| `BaseStore`, `CollectionStore`, `SelectorStore`, `RecordStore` | Separate DB-read experiment | Track asynchronous read state and invoke a read adapter |
| `formStore` | Python configuration helper / JS factory | Configures a form / supplies its load-save adapter |
| `MemoryStore` | Form snapshot store | Retains an isolated in-memory saved snapshot |
| `ExclusiveBagStore`, `StoreLease` | Python shared-memory service and access lease | Protect access to a host-owned process-local dictionary of Bags |
| `AuthoringNode.store` | Property | Returns the builder's Data Bag |
| `storeTree` / `GnrStoreTree` | UI component | Displays Bag hierarchy; the name does not denote a store service |

PoC runtime sources: `stores/bag-rows.js`, `stores/collection-stores.js`,
`database/common/stores.mjs`, `forms/stores.js`, `forms/value-snapshot.js`,
`collections/storetree.js` under `js/dom/src`; Python `src/gramlot/grammar/logic.py`,
`builder.py`, `store.py`. Exact file fingerprints and additional legacy sources are
in [terminology-evidence.tsv](../../ports/PORT-0023-grid-and-stores/terminology-evidence.tsv).

<a id="gc-320-060"></a>

## 060 · Resident rows and RPC-loaded collections

**BagRows wraps resident data.** Its original Bag contains the records; its row
array, key index and subscriptions provide access to them. Local edits change the
original nodes. Filter/sort derive a projection without physically reordering that
Bag. “Resident” means already loaded in this runtime, not necessarily the entire
remote collection. A grid can create its own adapter or borrow a registered one;
a chart independently uses BagRows too. This is evidence of multiple consumers,
not an accepted destination lifetime decision. Filter/sort state belongs to each
BagRows instance: consumers borrowing the same instance also share its projection;
independent per-consumer views are not supplied by this registry.

`datamode='bag'` reads fields from each row's nested Bag, with an attribute fallback
in this prototype; `datamode='attr'` reads row-node attributes. ValuesBagRows and
AttributesBagRows fix these modes. These are two row representations, not two data
origins. They must not be silently treated as approved destination alternatives.

Default row identity is the node label. An explicit identifier reads a field;
keys must be unique nonempty strings or finite numbers (including zero). Row
**position** after sorting/filtering is not row **identity**. In the PoC, the lookup
index is unfortunately built from the projection: a hidden resident row is not
found by identity, including from a collection form. P1 documents this limitation.

**CollectionStores is the owner/registry.** Each entry relates a Source node,
`storeCode`, resolved Data path, BagRows instance and subscriptions. Duplicate codes
and path ownership conflict are rejected. Removing the declaration unregisters and
disposes the owned adapter. A borrowing grid does not own that adapter's disposal.

| Declaration | Data source and loading | Actual instance / limits |
| --- | --- | --- |
| `bagStore` | Existing Data Bag at storepath; replacement is observed | BagRows; loadData does not fetch an external source |
| `rpcStore` | Endpoint result with rows, identifier and metadata, converted into an attribute-row Bag | Same BagRows plus registry loading/page metadata; endpoint/identifier required |
| `selectionStore` | rpcStore with Selection label, or VirtualSelection when chunkSize is supplied | No separate Selection or VirtualSelection class; loadPage replaces the resident page |
| `fsStore` | rpcStore with FileSystem label, default directory_selection endpoint and path identifier | Flat filesystem rows; no filesystem editing protocol or lazy hierarchy |

`totalRows` describes the remote result when supplied; `len` describes the resident
projection. Page index/chunk size are request coordinates. They do not constitute a
multi-page cache, random-access virtual dataset or global totals. Selection labels
and row-count metadata cannot establish those capabilities.

<a id="gc-320-065"></a>

## 065 · Database-read stores: request state, not the row adapter

This family is under `database/common/stores.mjs`. It does not extend BagRows and
is not registered by CollectionStores. Its BaseStore stores a state object
`{loading, stale, error, result}` at a designated Data Bag path, returns detached
snapshots and batches listener notifications in a microtask. Each operation lane
cancels an earlier operation in that lane; read and lookup lanes are distinct.
Errors preserve the previous result and mark it stale; cancellation is not stored
as an application error. Invalidation aborts pending work and marks retained data
stale. These semantics belong to this experiment, not every object called store.

| Class | Reads and output | What it does not supply |
| --- | --- | --- |
| `CollectionStore` | load invokes adapter.query; lookup invokes adapter.readRecord without replacing the published query result | Local row projection/editing, save, continuation: loadMore explicitly rejects as unsupported |
| `SelectorStore` | Uses model metadata to search by prefix, then contains only if prefix found zero rows; supplies value/caption options and exact resolveValue lookup | A grid selection model or form persistence |
| `RecordStore` | Loads a record by identity and optional field projection | Save, delete or a form edit session |

The **read adapter** implements describe/query/read operations for an origin. The
**ModelCatalog** describes tables/fields/relations; its re-export from stores.mjs
does not make it a store. **BagDB** is the local model/data laboratory behind the
fake read adapter, with setup/mutation facilities; it is neither BagRows nor an
accepted core database/backend. DatabaseService creates/manages these read stores
from Source providers, using private state Bags and publishing results into page
Data. `dataRecord`/`dataSelection` are provider declarations, not these JS classes.

Thus there are two concrete PoC paths: RPC result → resident Bag → BagRows, and
read adapter → DB store request/result state → provider output in Data. There is no
implemented universal superclass joining them. Current Gramlot's accepted typed
selector contracts must be evaluated separately from this historical experiment.

<a id="gc-320-070"></a>

## 070 · Form stores: where a form loads and commits its draft

A form store supplies `load` and `save`. FormController owns the baseline, editable
draft, dirty state, validation and conflict/pending policy. Loading makes detached
copies: typing in a form is not automatically a write to the origin. “Save” here
means committing through the selected adapter; only some adapters call a server.
Python formStore configures attributes on the enclosing form, rather than declaring
a named collection entry. The JS factory mostly returns plain adapter objects.

| PoC type | Load origin | Save destination | Limits / terminology traps |
| --- | --- | --- | --- |
| `memory` | Private MemoryStore snapshot | Replace that private snapshot | No persistent storage or database |
| `item` | Bag at storepath in application Data | Replace that Bag | One local item, not remote CRUD |
| `hierarchical` | Same branch as item | Same branch as item | No additional hierarchy-specific behavior |
| `subform` | storeFields subset of a Bag at storepath | Merge those fields into a copy of that parent Bag | Field subset behavior; no full parent-form coordination |
| `collection` | Existing row selected by storeCode + storeKey | Update that row in the registered collection | Cannot change identity; no insertion, deletion, navigation or off-page fetch; affected by filtered lookup |
| `record` | loadmethod RPC returning a Data Bag | savemethod RPC with key and copied draft | Distinct from read-only DB RecordStore; no version/conflict protocol defined by this adapter |

The non-memory adapters guard against saving to an identity/location different
from the one loaded. This protects one boundary; it is not optimistic locking
against concurrent remote edits. Snapshot isolation is not a database transaction,
and replacing a local Bag is not durable persistence.

<a id="gc-320-075"></a>

## 075 · Shared server memory, authoring Data and lazy hierarchy

`ExclusiveBagStore` is created by the PoC's host-owned PageRegistry and passed to
page contexts. It stores Bags by string key in one Python process. Its exclusive
lease locks a whole operation, guards thread ownership and exposes detached input/
output copies. Its async bridge keeps ownership until the worker finishes even
when the caller is cancelled. It supplies no rollback on exception, disk storage,
database transaction, multi-process coordination or browser row view. StoreLease
is the access mechanism, not a second repository of records.

`AuthoringNode.store` simply returns `builder.data`. Here “store” means the
application's authoring Data Bag. It does not create any of the services above.

A **resolver** computes/loads a Bag node's value; the PoC RpcResolver additionally
coalesces pending loads and applies cache time. It is not a collection registry or
form store. A hierarchical Bag can contain lazy resolvers without acquiring row
query/edit/save semantics. `fileSystemTree` loads a hierarchical Bag through its
provider/resolvers; `fsStore` loads flat rows. `relationTree` and `storeTree` likewise
must not be classified as collection-store subclasses merely from their names.

<a id="gc-320-080"></a>

## 080 · Historical record: which legacy names really correspond

Direct read-only inspection of GenroPy complements the PoC audits. This section
records legacy behavior, not a transfer requirement or an approval to revive Dojo.
Three separate legacy families must remain distinguishable:

1. **`gnr.GnrStoreBag/Grid/Query`**, in `gnrstores.js`, adapt Bag data to the old
   Dojo store interfaces (Read/Write/Identity/Notification). Grid adds resolver-backed
   fetch/paging; Query adds query/identity lookup and value caching. These are widget
   adapters, not the same inheritance tree as the following collection classes.
2. **`gnr.stores.*`**, in `genro_components.js`, provide collections. BagRows extends
   _Collection; ValuesBagRows and AttributesBagRows extend BagRows. RpcBase extends
   AttributesBagRows; FileSystem extends RpcBase. **Selection extends
   AttributesBagRows directly**; VirtualSelection extends Selection. _Collection
   includes Source, form locks/protection, topics and linked-widget responsibilities.
3. **`gnr.formstores.*`**, in `genro_frm.js`, provide form persistence/navigation.
   Base has SubForm, Item, Collection and Hierarchical subclasses. Actions have
   separately selected handler types, including memory, record, rpc, document and
   recordCluster, with distinct load/save/delete implementations where supplied.

| Name or behavior | Legacy | PoC comparison |
| --- | --- | --- |
| Values/AttributesBagRows | Value/attribute row layout; sort mutates source Bag; identity can fall back to node label | Same layout distinction, but non-mutating projection and stricter configured identity |
| RpcBase / FileSystem | Loading/query integration and delete endpoints; FileSystem defaults a file-delete endpoint | rpcStore/fsStore declarations; no corresponding complete classes or delete protocol |
| Selection | Database selection, loading, live-update subscriptions and pending changes | A type label on the shared resident adapter |
| VirtualSelection | Pages, pending-page tracking, server-side sorting, selectionName and total-count metadata | One replaceable page; not equivalent virtual behavior |
| Form Collection | Parent collection navigation and memory load/save/delete | Existing-row load/update only |
| Form SubForm | Parent-form record integration | Subset load/merge against a Data path |
| Form Hierarchical | Empty subclass of Base in the inspected source | Same branch as item; the name alone proves no hierarchy behavior |
| Form memory / record | Action handler kinds, separate from form-store subclass | Flattened into the same six-value storeType list |

This last distinction is especially important: **the legacy form's structural
relationship and its persistence handler are two axes**. A collection form and a
remote saving mechanism are not inherently alternatives. The PoC's enum must not
be mistaken for a complete conceptual model of the legacy design.

Python legacy helpers add another layer: bagStore creates BagStore; selectionStore,
fsStore and rpcStore configure SelectionStore declarations; virtualSelectionStore
is itself a helper delegating to selectionStore. directoryStore writes a
DirectoryResolver-produced Bag to Data, and tableAnalyzeStore composes Data/dataRpc.
The externalStore helper in `_helpers.py` adds cross-database join metadata; it is
not another browser-store class. Legacy database “store name” describes database
routing, not a collection registry's storeCode.

<a id="gc-320-085"></a>

## 085 · Vocabulary for the next discussion

Use these distinctions to describe existing evidence before choosing destination
names. They do not add public methods or settle any D01–D17 decision.

| Term | Meaning in this discussion | Must not be conflated with |
| --- | --- | --- |
| Origin / backend | Where data is obtained or persisted: local Data, RPC service, database adapter, filesystem | The row adapter or its visual consumer |
| Collection | Set of records handled together | The registry of named collection instances |
| Resident data | Records currently present in memory | All rows matching a remote query |
| View / projection | Filtered and ordered access to resident records | A separate persisted dataset |
| Query selection | Result of a query | UI selection of rows, selector options, or current form record |
| Identity | Stable key of a row/record in the relevant contract | Row position, Bag path or widget ID |
| `storeCode` | Registry identifier of a collection instance | Data location or row key |
| `storepath` | Data location used by the declaration/adapter | Collection identity; tree storepath has its own component contract |
| `_identifier` / `identifier` | Field specifying row keys, where configured | One selected key value |
| `storeKey` | Key of the row/record selected for a form | Identifier field name |
| `store` / `storeBag` | Context-dependent: grid reference/code versus actual Bag property | One universal type across builder, grid, tree and server |
| Page / chunk | Loaded segment and its request coordinates | A complete virtual dataset/cache |
| Dirty / draft | Unsaved form or editor changes | Stale read result, server conflict or persisted changeset |
| Save / commit | Transfer draft to the adapter's destination | Necessarily durable storage, transaction or undo |

For example, a customer-list declaration can associate a collection code with a
Data path. The Bag at that path holds resident customers; BagRows exposes rows;
a grid applies presentation/selection; a collection form loads a copy of one row
by key. Saving that form updates the resident row. Persisting it to a remote
customer database is another operation requiring its own contract. A DB
RecordStore read is not that form's save operation, and the server's
ExclusiveBagStore is not that grid's row adapter.

Remaining discussion is to align these meanings with the owner's intended use of
“store”, then select architectural responsibilities and names individually. D01
is deferred, not approved or rejected. No runtime source changed for this
terminology follow-up. Previous focused tests in §040 remain evidence for their
original scope; the new legacy comparison is static inspection, not executed
legacy parity or a real-database qualification.

<a id="gc-320-090"></a>

## 090 · Historical record: the legacy collection-store family in detail

Owner follow-up, 2026-10-25: “se fai riferimenti al legacy avevamo i collection stores. prova a prenderli e a dirmi cosa erano e che caratteristiche avevano”. This section focuses on the actual `gnr.stores` family, not the PoC plural registry or the other uses of store. Source: `gnrjs/gnr_d11/js/genro_components.js:6586–8183`, supported by the declaration widgets immediately above it, `genro_frm.js:3278–3339`, and the server handlers in `gnrpy/gnr/web/gnrwebpage_proxy/apphandler/{get_selection,misc}.py`. All inspected legacy files are fingerprinted under PORT-0023. Static code evidence, not a newly executed parity claim.

A collection store was the **behavioral object governing a set of rows for linked UI consumers**. It located its data in a Bag at a Source-relative storepath, exposed row/index/identity access, coordinated loading and changes, and specialized that behavior for local Bags, RPC results, filesystem rows or database selections. A store could serve multiple linked grids, and a collection form could use it as its parent collection for navigation. It also contained presentation and server integration responsibilities; it was not an isolated generic container.

| Class | Actual parent | Added responsibility |
| --- | --- | --- |
| `_Collection` | none | Source/Data location, common row/view access, filtering, linked clients, locks/protection, loading hooks and operation prompts |
| `BagRows` | `_Collection` | Resident Bag loading/copying, local row deletion/update dispatch, change/error markers |
| `ValuesBagRows` | `BagRows` | Fields in nested row Bag; value updates, local sort and sums |
| `AttributesBagRows` | `BagRows` | Fields in node attributes; attribute updates, local sort and sums |
| `RpcBase` | `AttributesBagRows` | RPC loading with visibility gating, progress notifications and configured remote deletion |
| `FileSystem` | `RpcBase` | Filesystem deletion default (`app.deleteFileRows`) |
| `Selection` | `AttributesBagRows` | Database selection loading, live DB events, incremental reconciliation/reload, DB row actions and requested columns/totals |
| `VirtualSelection` | `Selection` | Named server selection, page cache and on-demand/pre-emptive fetch, server ordering/counts/aggregates |

**Common collection contract.** `_Collection` implements getData/getItems/len, key/index translation, rowByIndex and rowBagNodeByIdentifier, with specialization hooks for item access, keys and row representation. It derives a storepath from the Source node, can move that path and rebind linked grids/editors, clears data, publishes lock changes and tracks explicit loading blockers. Parent-form lock/protect state influences disabled controls. Loading can wait until a client becomes visible; linkedWidgetNode provides an alternative visibility client. linkedGrids discovers consumers by the store-node naming convention and caches them; gridBroadcast fans out operations.

Filtering lives on the store as `_filtered`, a mapping of visible positions to underlying indexes. It combines text/typed comparisons, the grid filter manager and include/exclude lists. getData(true) materializes copied filtered rows. Consumers sharing an instance share that filter state. Index and key methods have filtered/unfiltered variants, but rowBagNodeByIdentifier uses the filtered index by default: the hidden-row lookup problem is also present in this legacy path, not evidence of a new PoC-only regression. Row key extraction is not uniformly identical: ValuesBagRows uses rowFromItem's label fallback; AttributesBagRows rowFromItem has a fallback, but its keyGetter directly reads the configured attribute.

**Resident Bag rows.** BagRows.loadData deep-copies incoming data. With selfUpdate it preserves/restores grid selections and reapplies filters. Local deletion removes nodes and announces deleted rows. Values/Attributes specialize updateRowNode; sorting physically reorders the Bag, and sums read value/attribute fields respectively. hasChanges/hasErrors inspect `_newrecord`, `_loadedValue` and `_validationError` markers. They do not constitute a standalone draft/save/conflict protocol. Local deleteRows uses supplied keys as Bag node labels; it is not a universal identity-based delete implementation for every representation.

**RPC and filesystem rows.** RpcBase invokes the Source's RPC provider, broadcasts loading state, resets the filter and replaces loaded data. Deletion calls a configured endpoint and reloads. FileSystem supplies the standard file-delete endpoint. Python fsStore uses SelectionStore with FileSystem type and app.getFileSystemSelection. The source of the records differs while the attribute-row access contract is inherited. These classes do not implement Selection's database-event reconciliation.

**Database Selection.** It is a sibling of RpcBase, not its subclass. It adds:

- Query loading through the provider; visible-client gating, pendingLoading, optional count-only requests for title counters, and loading/count broadcasts.
- Requested columns derived from linked views; view changes can reload when additional columns are needed. Requested server total columns can be collected from non-editing grids.
- Table DB-event subscription. Default LOCAL filters events through isLocalPageId; PAGE accepts only the current page; NO disables subscription. Reasons can be excluded. Pending changes, visibility, form operations, configurable delays and user activity affect when updates apply.
- Reconciliation of inserts/updates/deletes against the original query condition, including rows entering or leaving the result. It reloads instead of patching when the change ratio exceeds the configured threshold (default 0.3), or totals/applymethod/fullReloadOnChange require it.
- Preservation of grid selections, selected-row notifications, highlighting of external changes, editor notification, and postponed reordering during editing. This is integration behavior, not a general concurrency-resolution guarantee.
- Remote duplicate/delete/unlink/archive actions using Genro app services, and counter-field updates. Common prompts/protected-key handling are coordinated with those actions; the class is not a universal record create/save API.

**VirtualSelection.** It represents a potentially large named selection while only some pages are resident in the browser. onLoaded stores the first page as P_0 and retains selectionName/count metadata. itemByIdx maps the logical row index to page/offset; getDataChunk avoids duplicate pending-page requests, schedules loading and suppresses some fetches during scrolling. Direction/position heuristics request an adjacent page in advance. Loaded chunks are retained as P_N Bags and notify updateRows; cache is cleared on reload. No bounded LRU eviction policy appears in this inspected class.

Its sort override intentionally does nothing locally: app.getSelection sorts/reuses the server selection. The server freezes a named selection and subsequent calls unfreeze it, emitting only the requested row_start/row_count slice. Thus this is browser paging over a server-retained selection, not proof of a database cursor that reads only one chunk from the database. currentPkeys can request the entire selection's keys, and sum requests server aggregates rather than summing only cached rows. DB changes first check whether the frozen selection is affected, then reload while retaining selected identities. A frozen selection is a saved query result, not a database transaction or a guarantee that it cannot change.

Limits matter for terminology: local virtual filtering iterates loaded pages, filteredRowsIndex is explicitly unimplemented, and key-to-index lookup searches cached data rather than universally resolving off-page identities. Some key-to-row paths can fetch synchronously. The implementation has page/pending caches and prefetch, but its name alone does not establish exhaustive lookup, global local filtering, bounded memory or race-free request lifecycle.

**Form relationship and authoring.** `gnr.formstores.Collection` is a separate consumer of the parent collection's len/getIdxFromPkey/getKeyFromIdx methods; first/last/next/previous navigation follows that collection's ordering/filtering. It is not another subclass of gnr.stores._Collection. Python bagStore configures the BagStore widget, which normally builds ValuesBagRows around a dataController. selectionStore configures SelectionStore, choosing Selection or VirtualSelection by chunkSize; rpcStore/fsStore choose RpcBase/FileSystem. These declarations build the behavioral instances and are distinct from the instances themselves.

The architectural description justified by this source is therefore: **a shared collection abstraction, specialized by row representation, origin and loading strategy, with substantial grid/form/server coordination attached**. Which parts belong together in Gramlot remains an owner decision; this account does not select a port design.


<a id="gc-320-095"></a>

## 095 · Owner clarification: one collection contract, different implementations

Owner clarification, 2026-10-25:

> il concetto era buono ma si era stratificato nel tempo
> di fatto ogni collectyon strire espione gli stessi metodi ma a seconda del tipo li implementa in modi diverso

The conceptual model to recover is a common collection-store method contract, implemented differently by each store type. Historical layering does not invalidate that abstraction. The preceding class inventory describes how the legacy realized and accumulated responsibilities; it must not be interpreted as a proposal for unrelated consumer-facing interfaces.

This confirms the conceptual reading, not a complete destination API: method inventory, signatures, semantics, asynchronous behavior, capabilities and implementation structure still need examination and explicit decisions. A shared public contract does not by itself require copying the legacy inheritance tree. No new API, class hierarchy or runtime implementation is approved here. Next analysis should map the common methods to their type-specific implementations and identify semantic differences or incomplete legacy implementations.


<a id="gc-320-100"></a>

## 100 · Owner clarification: origin, copy/reference and dirty context changes

Owner examples, 2026-10-25, clarify the conceptual collection contract beyond §095:

- “inoltre i collection store aveva anche la possibilita di essere filtarto” and “e poi aveva modo di essere sortato”: filtering and sorting belong to the collection abstraction.
- “tipicamente la 'view' chiede allo store la prossima riga o la riga numero x”: grids and other views consume a common row-access contract, independent of value-Bag versus attribute-Bag row representation. The owner describes the store's data as always a Bag; this does not settle class inheritance or require each returned row to have a newly specified representation.
- The region/provinces example clarifies two valid alternatives: copying the selected region's province Bag into a working store, versus directly referencing that original Bag. Owner: “sono due modi alternativi validi entrambi a seconda del contestop”. In copy mode load creates the working copy and save writes back to its origin, even entirely in memory. In direct-reference mode edits reach the original immediately. This later concrete example resolves the earlier ambiguous use of “referenziato” versus “condiviso”; direct reference here means immediate shared edits.
- The same context change can load provinces through an RPC. Owner: “se cambio regione sebza salvare mi aspettp che mi chieda se salvare le modifiche oppure annullarle”. A change that would replace edited data must therefore offer saving or discarding the pending edits before replacing them. This requirement applies to a copied in-memory collection and to the RPC example; save is not synonymous with remote persistence.

In the example, pending Lombardy edits belong to the Lombardy origin, while the proposed next load targets Campania. Saving commits the previous working data to its previous origin, then the next context can load; discarding abandons the pending working edits before that load. The origin/context of the working data must not be confused with the requested next context. Direct-reference editing has already modified the original; the owner has not specified a rollback mechanism for that mode.

These are owner-confirmed conceptual requirements and examples, not an implemented API. Exact method signatures, dirty-state ownership, responsibility for displaying the question, save-error handling, request ordering, a possible cancel-navigation choice and rollback semantics remain unspecified. No hierarchy, new handler, persistence format or runtime implementation is selected by this record. Continue terminology/contract discussion before implementation.


<a id="gc-320-105"></a>

## 105 · Owner clarification: contextual database autosave

Owner, 2026-10-25: “anche per lo store su db in realra esiste una modalita 'autosave' per cui se sono in edit e cambio riga viene fatta una rpc per modificare immediatamente o aggiungere o eliminare. ovviamente vale in certi contesti ma di fatto bisogna tenerne conto”.

The model must account for contextual database autosave as well as explicit save. The owner describes leaving an edited row as a trigger for an RPC write, and includes update, insert and delete operations. This is not a requirement to save on each keystroke or to enable autosave universally. The precise insertion/deletion triggers are not separately specified. This record captures the owner's stated behavior and requirement; it does not claim a newly verified current-core implementation.

Data origin and save policy are distinct aspects of the discussion: an RPC/database-backed collection can use explicit save or contextual autosave. Autosave still performs a write operation across a service boundary; it is not the same mechanism as directly sharing an in-memory Bag. The dirty-context guard from §100 must account for the selected policy and any outstanding write rather than assuming every edit always prompts for manual save.

Validation, write acknowledgement, failed/pending writes, row/context switching during those writes, assigned identities after insertion, deletion timing and responsibility for coordinating the interaction remain to be specified. No defaults, API, state machine or implementation ownership are approved by this note. Continue conceptual contract alignment before implementation.


<a id="gc-320-110"></a>

## 110 · Owner-completed conceptual scope: static collection stores

Owner conclusion, 2026-10-25: “qundi sono modalita analoghe
ora hai tutto relativamente ai collection store statici.” This closes the owner's conceptual explanation of static collection stores. It does not authorize runtime implementation or declare the preceding PoC/legacy implementations accepted.

Additional owner evidence since §105:

- Filesystem: “potrei ricevere ad esempio un certo numero di documenti cone metadati ed editare i documenti in una form”. A collection can present documents with metadata and support document editing through a form; this scope is broader than a read-only file listing. Exact content-loading and metadata/content persistence protocols are not specified.
- Generic service: “una rpc ad un servizio generico anche esterno che mi rende una cosa che posso mettere in una bag”. An RPC service, including an external service, can provide data that becomes the collection's Bag. No arbitrary conversion API or universal write capability is inferred.
- In-memory row representation: “una bag di attributin (con value nullo) o una bag di valori”. These are analogous collection representations: attribute rows have null node values with fields in attributes; value rows have fields in nested value Bags. The common store contract shields consumers from that storage distinction. This is a concrete supported conceptual alternative, not permission for arbitrary representations or compatibility fallbacks.

Consolidated model from §§095–110:

| Aspect | Owner-described scope |
| --- | --- |
| Consumer contract | A grid or other view requests rows, including positional/sequential access; collection filtering and sorting are part of the abstraction |
| Data representation | Bag data, with the two analogous in-memory row layouts described above |
| Origin | In-memory Bag/path, database, filesystem documents/metadata, generic RPC service (possibly external) |
| In-memory relationship | Working copy with save back to the original path, or direct reference with edits immediately affecting the original |
| Load/save | Origin-specific implementation behind common collection behavior; save also has meaning entirely in memory |
| Save policy | Explicit save, or contextual database autosave; do not generalize all combinations to all origins |
| Context changes | Pending edits require save/discard handling before replacement; autosave must be taken into account; previous working origin remains distinct from the requested next origin |
| Editing | Row operations, and document editing through a form in the filesystem example; exact integration responsibilities remain to be designed |

Treat these as dimensions of the described model rather than a list of unrelated consumer interfaces. They do not establish that every origin supports every write operation, both reference modes or every save policy. The owner has completed the conceptual scope of static stores; exact methods/signatures, asynchronous and error semantics, ownership and implementation design remain separate work. The label static is retained as the owner's scope label, not inferred to mean read-only, synchronous or unable to load through RPC. No virtual-store requirements are added by this conclusion.


<a id="gc-320-115"></a>

## 115 · Virtual-store options and query scope before optimization

Owner discussion, 2026-10-25: legacy named selections associated an identifier (typically described as a 22-character UUID) with a query result pickled on the server. The browser retained non-contiguous pages and fetched missing blocks on demand. The owner raised server-side materialization in an untracked database table and full IndexedDB population through a Worker as alternatives, leaving DOM handling for a separate decision. These are options raised for evaluation, not chosen destination implementations or a mandated identifier format.

Subsequent owner steering: “ogni soluzione ha pregi e difetti, in realta basterebe dire ai clienti che è inutile che prendano 300000 ckienti assien++”. This puts the usefulness and scope of the query before engineering for indiscriminate full-result browsing. It does not establish a numeric row cap, reject every legitimate large collection, or approve a specific search UI. A proposed practical direction is to help users narrow a query, reserving virtualization for justified result sizes and treating full client replication as an option needing a concrete use case and measurements.

Read-only technical evidence gathered during the discussion:

- Legacy selection.py separates pickle metadata and full row data; _freeze_data('r') calls pickle.load on the full data file. _gnrbasewebpage.py delegates freeze/unfreeze through page-local paths. The existing getSelection handler slices the resulting selection for a requested block. This supports a potential full-unpickle cost, not measured latency or a claim that every layer rereads on every request.
- Existing PoC grid.js:457–480 clears/rebuilds its bounded visible row window with overscan, while retaining resident data separately. This is not evidence about Dojo DOM retention or a destination implementation decision. Its resident-data geometry costs remain subject to the earlier investigation.
- IndexedDB is available in Workers and supports indexed structured data; browser storage has quotas and eviction policies. Moving work to a Worker does not eliminate total transfer/storage cost, and ordinary object messages use structured cloning rather than sharing Bag instance identity. A serialization contract preserving Bag semantics would need review, not ad hoc dependency workarounds.
- A server-side indexed materialization, browser page cache, persistent client replica and bounded DOM window are different concerns. The owner's “untracked” table is not automatically PostgreSQL UNLOGGED; that interpretation is unconfirmed. If UNLOGGED were selected, PostgreSQL documents crash truncation and lack of standby replication.

Primary references consulted: [MDN IndexedDB](https://developer.mozilla.org/en-US/docs/Web/API/IndexedDB_API), [indexed access](https://developer.mozilla.org/en-US/docs/Web/API/IndexedDB_API/Using_IndexedDB), [Worker messaging](https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API/Using_web_workers), [structured clone](https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API/Structured_clone_algorithm), [storage quotas/eviction](https://developer.mozilla.org/en-US/docs/Web/API/Storage_API/Storage_quotas_and_eviction_criteria), [PostgreSQL CREATE TABLE](https://www.postgresql.org/docs/18/sql-createtable.html). These verify platform properties, not performance on Gramlot's workload.

No choice of pickle replacement, IndexedDB replica, Worker ownership, DOM lifecycle, paging API or automatic query limit is approved. No large-dataset benchmark or runtime implementation was performed. Core remains independent of server/database technology; implementation placement would need destination review. Next discussion should start from actual user query needs before selecting a virtual-store strategy.


<a id="gc-320-120"></a>

## 120 · Standard protocols and established virtualization patterns

Owner question, 2026-10-25: “esistono soluzioni'standard' ?”. Primary-source research distinguishes formal protocols, established data-access patterns and rendering libraries. None is a universal Bag collection-store contract or automatically determines persistence/editing behavior.

| Area | Established reference | Relevance and limits |
| --- | --- | --- |
| Positional paging | SQL LIMIT/OFFSET; OData skip/top | Requests a portion by position/count. Requires deterministic ordering; large SQL offsets can still compute skipped rows. The interface does not guarantee efficient random access or stable snapshots across concurrent changes. |
| Cursor paging | GraphQL Cursor Connections specification | first/after and last/before with opaque cursors/pageInfo. Suitable for successive pages; no inherent arbitrary row-number jump or prescribed efficient database implementation. Cursor is not synonymous with a live database cursor. |
| Stable search context | Elasticsearch point-in-time plus search_after | Established example of retaining a consistent view over multiple requests; related purpose to named selections, but not the same storage/materialization or positional-access implementation. |
| Client block cache | AG Grid Server-Side Row Model | Requests start/end row ranges, retains blocks, supports bounded cache, request concurrency and scroll-load debounce. This specific AG Grid model is Enterprise; cited as a design reference, not chosen dependency. |
| DOM virtualization | TanStack Virtual | Headless visible-range/measurement utility with framework-independent core; renders a bounded visible/overscan window through the consumer renderer. Does not fetch data, save records or make server paging unnecessary. |

Formal protocol reference: [OData 4.01 OASIS Standard](https://docs.oasis-open.org/odata/odata/v4.01/os/part1-protocol/odata-v4.01-os-part1-protocol.html) defines filter/orderby/skip/top/count and server-driven paging. [GraphQL Cursor Connections](https://relay.dev/graphql/connections.htm) specifies cursor/page metadata conventions rather than a universal storage strategy. Further primary references: [PostgreSQL LIMIT/OFFSET](https://www.postgresql.org/docs/current/queries-limit.html), [Elasticsearch paging/PIT](https://www.elastic.co/docs/reference/elasticsearch/rest-apis/paginate-search-results), [AG Grid cache configuration](https://www.ag-grid.com/javascript-data-grid/server-side-model-configuration/), [AG Grid cache/request controls](https://www.ag-grid.com/javascript-data-grid/server-side-model-api-reference/), [TanStack Virtual](https://tanstack.com/virtual/latest/docs/introduction), [framework-independent core](https://tanstack.com/virtual/latest/docs/installation), [rendering versus data virtualization](https://tanstack.com/table/latest/docs/framework/react/guide/virtualization).

Proposed reference direction only: a paged collection with bounded resident blocks and a separately bounded DOM window is close to the legacy model and established grid practice; IndexedDB full replication is not a prerequisite. The critical distinction is arbitrary positional access versus cursor traversal. A service that only exposes successive pages cannot promise cheap access to row 300,000 without additional indexing/materialization or traversal. Origin-specific optimization remains outside the portable core. No adoption of OData, GraphQL, AG Grid, TanStack, Elasticsearch or a new backend is approved, and no benchmark or implementation was performed.

<a id="gc-320-125"></a>

## 125 · Owner-specific PostgreSQL selection direction

Owner, 2026-10-25: “la version e che usero io si basera su slezioni salvate su postgres”. The owner reports previous measurements of saving 400,000 rows in less than a second, fluid scrolling, and search/sort/group/filter capabilities. This selects PostgreSQL-saved selections for the owner's implementation; it does not make PostgreSQL a core dependency or authorize runtime changes in this investigation. The performance figure is owner-reported historical evidence, not a benchmark rerun here. Precise protocol, lifecycle, editing behavior and client rendering remain to be reviewed.

The owner then requested recovery of the relevant GenroPy branches, expected between January and March and including client interaction changes. §130 records the recovered February 2026 implementation. The earlier generic-option discussion is retained as background, not an unresolved choice of backend for this owner-specific version.

<a id="gc-320-130"></a>

## 130 · Historical record: PostgreSQL frozen-selection branch recovered

Read-only recovery on 2026-10-25 found the work in the locally available GenroPy refs. The most complete relevant branch is **sql_review/freezed_to_sqlite_pg**, at **9353aa448ba868307b1a4b24bce8933abd735c18**, dated **2026-02-16**. The local branch and cached origin ref resolve to that same commit. This commit is not an ancestor of the cached origin/develop ref inspected; no remote fetch was performed, so this is not a claim about current remote merge state or absence of independently reimplemented work.

This source is different from the October checkout underlying §090. The February experiment must be consulted explicitly; reading only the current checkout missed it. No branch was checked out or modified. The [source digest inventory](../../ports/PORT-0023-grid-and-stores/postgres-branch-evidence.tsv) identifies ten reviewed historical source/test files; the [ref inventory](../../ports/PORT-0023-grid-and-stores/postgres-branch-refs.tsv) retains five exact branch tips. Additional snapshots used for inspection are temporary, not a bulk transfer into core.

| Branch | Date / short tip | Contribution |
| --- | --- | --- |
| feature/freezed-selection-tests | 2026-02-12 / 107b005800 | Page-level frozen-selection tests |
| feature/refactor-freezed-selection | 2026-02-12 / 25acf811fe | Extracts frozen-selection responsibilities into a dedicated page proxy |
| feature/freezed_to_sqlite | 2026-02-15 / 265500812d | SQL-backed paging/search/sort evolution and client search propagation |
| sql_review/lazy_selection | 2026-02-14 / 94894a082f | Lazy selection work and _outputTable support for direct CREATE TABLE AS SELECT |
| sql_review/freezed_to_sqlite_pg | 2026-02-16 / 9353aa448b | PostgreSQL backend, combined client work, shared SQL backend and direct server-side materialization |

Related history includes #477 (tests), #481 (proxy/SQLite), #486 (SQL frozen selections and client work), and #488 (lazy selection/output table). These are issue references in local commit messages, not newly read issue discussions. The PostgreSQL backend was introduced by **480c6c98fd** on February 14; **9353aa448b** on February 16 adds the crucial direct-query path. **265500812d** on February 15 fixes preservation of searchOn_seed in subsequent page loads.

**Recovered server design.** `gnrfreezedselections.py` defines GnrFreezedSelectionsBackend, Pickle, shared Sql, Sqlite, Unlogged, and the public GnrFreezedSelections page proxy. Backend selection uses the sys freeze_backend preference (pickle/sqlite/postgres), with a page use_freeze_backend override. This historical selection mechanism is not an approved Gramlot dispatch/fallback design.

The PostgreSQL implementation creates UNLOGGED tables under schema `_qc`, with metadata in filesystem `unlogged_meta.json`. It uses an internal `_rowidx` column and creates a unique index for it. This is therefore the concrete UNLOGGED implementation previously described by the owner as “untracked”; it is no longer merely a guessed interpretation of that word for this recovered branch.

The fast path is:

1. apphandler.getSelection asks the page for outputTableName(selectionName) before query execution.
2. That returns a qualified output target using the historical UL: convention; SqlQuery receives `_outputTable` in sqlparams.
3. SqlQuery wraps the SQL in `CREATE UNLOGGED TABLE … AS SELECT row_number() OVER () - 1 AS _rowidx, …`.
4. _dofetch detects this output and returns metadata/row count without fetching the whole result into Python. The selection carries `_outputTable` and `_totalrows`.
5. freezeSelection indexes the table and writes metadata; apphandler fetches only the first requested page through getFromFreezedSelection.

That explains the architectural basis for the owner's reported performance; it does not reproduce the timing. The branch also retains query-recreation and Python insert paths, including an exception-catching fallback. Those paths, type conversion and broad method dispatch need destination review under the single-primary-path constitution; historical existence is not approval to import them.

**Page serving, sort and search.** getFromFreezedSelection reads the materialized table using ORDER BY/LIMIT/OFFSET and reconstructs only the returned page as a SqlSelection, ultimately serialized into grid Bag rows. It avoids full unpickle for page retrieval. Default ordering uses `_rowidx`; requested order columns are checked against stored columns. The presence of an index does not turn this actual OFFSET query into an ordinal range seek.

Search builds a SQL VIEW over text-like columns using tokenized LIKE/ILIKE predicates, optionally restricted by searchOn_columns. It computes the filtered count and requested sums, caches search state in JSON and returns filtered pages from the view. Clearing the seed removes search state and restores the underlying selection. The state reuse key in this snapshot compares the seed; independent simultaneous views, changing search-column sets and concurrency need review. searchOn_field appears in the API but the inspected shared SQL search path does not use it to choose a field. These are code-review observations, not executed failures.

**Client integration is present.** `resources/common/th/th_view.py:1299` binds searchOn_seed to the searchbox Data path. `genro_grid.js:994–1027` routes virtual non-pickle search to store.loadData instead of a local cached-row filter, and restores the searchbox from response metadata freezed_search_seed without firing an unintended new search. SearchBox uses input events; grid cell rendering highlights search tokens. `genro_components.js:7908–7937` carries the current searchOn_seed on each virtual page RPC alongside selectionName, row_start, row_count, sortedBy and table. Thus pages reached after scrolling stay within the search, rather than reverting to the unfiltered saved selection. The grid's backend check reads the application preference; its agreement with the server's per-page override is a destination-review point.

**Lifecycle and scope limits.** The Unlogged backend contains cleanupSelection, cleanupPage, cleanupOrphans and cleanupAll methods. Their existence does not demonstrate automatic wiring for every lifecycle event. Full unfreeze and frozen-key retrieval still fetch the full requested result; bounded page serving is a specific path. The retrieved paging API accepts ordering, sums and text-search parameters, but not group_by: getSelection accepts group_by/having when creating a query. Therefore a dedicated regrouping operation over an already materialized selection is not established by this snapshot and remains a retrieval/contract question, distinct from the owner's reported overall capability.

**Verification boundary.** The recovered web suite exercises pickle and SQLite backends against a PostgreSQL-backed test_invoice_pg source site. Its explicit parameterization does not cover the PostgreSQL UNLOGGED selection backend. The lazy-selection tests include SQLite/PostgreSQL variants, but are not a 400,000-row UNLOGGED/browser benchmark. No historical suite, database mutation or browser run was performed during this read-only recovery; source blobs and ref identities were verified directly against Git, and documentation links/anchors/digests checked. No fresh evidence contradicts or reproduces the owner's historical timing.

Useful exact source entry points at the recovered revision:

- [PostgreSQL backend and direct freeze path](https://github.com/genropy/genropy/blob/9353aa448ba868307b1a4b24bce8933abd735c18/gnrpy/gnr/web/gnrwebpage_proxy/gnrfreezedselections.py#L992).
- [SQL page/search implementation](https://github.com/genropy/genropy/blob/9353aa448ba868307b1a4b24bce8933abd735c18/gnrpy/gnr/web/gnrwebpage_proxy/gnrfreezedselections.py#L683).
- [Query output-table wrapping](https://github.com/genropy/genropy/blob/9353aa448ba868307b1a4b24bce8933abd735c18/gnrpy/gnr/sql/gnrsqldata.py#L1093).
- [Client search routing](https://github.com/genropy/genropy/blob/9353aa448ba868307b1a4b24bce8933abd735c18/gnrjs/gnr_d11/js/genro_grid.js#L994) and [page requests](https://github.com/genropy/genropy/blob/9353aa448ba868307b1a4b24bce8933abd735c18/gnrjs/gnr_d11/js/genro_components.js#L7908).

The branch is recovered and relevant. Next work, if requested, is a bounded contract comparison against the owner's static/virtual collection model, with backend and client responsibilities separated. It is not authorized for copying or implementation merely because it has been located.


<a id="gc-320-135"></a>

## 135 · JSONL Worker experiment and composed SQL feasibility — 2026-10-25

Historical checkpoint before the subsequent full-run instruction and completed measurements in §140.

**Owner scope.** The owner requested 500,000 typical business rows with 30 columns in a Worker, identified `asqueel-org/asqueel-js`, authorized using its migration function, and specified the existing JSONL/TYTX shipping adapter. The owner subsequently interrupted the full run, questioned the 1,000-row batch and asked whether the SQL could be composed in one call. These instructions authorize measurement, not a storage API adoption or a streaming RPC implementation in core.

**Actual path.** TYTX 0.16.4 provides `toTytxIter` / `fromTytxIter` for one-record-at-a-time typed JSON data. A JSONL reader/writer supplies framing. Current core HttpTransport/RpcHandler still consume a complete response text and envelope. The retained experiment is therefore an isolated loopback HTTP/Worker fixture, not an implemented Gramlot streaming RPC or application. It uses Asqueel `defineModel`, `migrateSQLite`, `openBrowserSQLite`, and existing `sql_insert`, with no dependency source edits. The Worker imports progressive records into SQLite rather than retaining a full 500,000-node Bag. The CollectionStore Bag contract remains undecided at implementation level.

**Initial evidence.** The 1,000-row end-to-end smoke passed migration, import, full-width sample checks, row count/key sum, query samples and close/reopen persistence: about 957 ms for transfer/decode/import through commit. The requested full run was stopped at the owner's instruction; its last progress event reports **280,000 rows in 216.884 seconds**. There is no completed 500,000-row result, final integrity result, commit confirmation or full-run memory summary. No full run was restarted. The batch size of 1,000 was an agent-selected baseline consistent with Asqueel's file importer, not an owner requirement or tuned optimum. The transaction covered the entire stream; batches were not separate commits or requests.

**Composed SQL probe.** On the same Apple M4 / 24 GiB machine, Chromium 156 and wa-sqlite 1.0.0 (SQLite 3.44.0), a separate bounded probe uses the same 30-column synthetic dataset and a migration-created temporary IndexedDB database. Times include SQL composition and transaction commit, but exclude dataset generation, migration and network transfer. These are individual sequential samples, not repeated statistical benchmarks.

| Path | Rows | Time | Outcome |
| --- | ---: | ---: | --- |
| Current Asqueel table.sql_insert | 1,000 | 915.1 ms | Passed |
| Individual INSERT statements concatenated into one adapter.execute call | 1,000 | 23.2 ms | Passed |
| One multi-row INSERT with 30,000 bound parameters | 1,000 | 19.3 ms | Passed |
| One multi-row INSERT with SQL literals | 1,000 | 17.7 ms | Passed |
| One multi-row INSERT with 300,000 bound parameters | 10,000 | — | Rejected: too many SQL variables; rollback verified |
| One multi-row INSERT with SQL literals | 10,000 | 172.6 ms | Passed; SQL size 4,372,212 bytes |

Successful cases check count, primary-key sum and all 30 values at three sample IDs. The failed parameterized case leaves zero rows. The actual build reports MAX_VARIABLE_NUMBER=32766, limiting a statement with 30 independent parameters per row to 1,092 rows. Its MAX_SQL_LENGTH is 1,000,000,000 bytes; that advertised ceiling is not evidence that a 500,000-row statement is practical or verified.

**Interpretation and correction.** The earlier explanation based only on individual INSERT preparation was incomplete: concatenating still executes individual SQL statements internally yet is much faster in this probe. Cost in the current per-record Asqueel invocation/compilation/binding path needs profiling; this experiment does not apportion those costs. It establishes that the browser database can ingest this small workload much faster through composed SQL. The literal encoder is deliberately limited to the fixed synthetic schema; it is not a general production serializer or an approved workaround in Gramlot. A production change belongs in Asqueel and must preserve typed values, defaults, generated values, partition behavior and transaction semantics. No implementation choice has been approved by this measurement.

[Methodology and reproduction](../../ports/PORT-0023-grid-and-stores/benchmark/README.md), [SQL results](../../ports/PORT-0023-grid-and-stores/benchmark/results/sql-composition.json), and [source fingerprints](../../ports/PORT-0023-grid-and-stores/benchmark/results/source-evidence.json) are retained. The Asqueel working source includes local changes, identified by file hashes in addition to HEAD. TYTX iterator tests: 15 passed. Measurement limits include headless blank-page scheduling, loopback-only transfer, single samples and same-session adapter reopen; no real-grid smoothness or production capacity claim.


<a id="gc-320-140"></a>

## 140 · Full 500,000-row blocks, early page delivery and query replacement — 2026-10-25

**Owner instruction.** The owner clarified that the objective is a completed 500,000-row measurement across block sizes, and that the interface can display data while the Worker loads, with the user potentially changing query after seeing only 30 records. This explicitly resumes full-scale measurement after §135's interrupted run. It establishes requirements to investigate, not acceptance of the fixture's lifecycle/API choices as Gramlot architecture.

**Fixture policy, not an adopted store contract.** The existing isolated benchmark now streams JSONL through TYTX into raw multi-row SQL via Asqueel's actual SQLite/IndexedDB adapter. Migration creates the table. A first transaction commits 30 rows; subsequent transactions commit blocks of 1,000, 10,000 or 50,000. The Worker reads the first 30 committed rows from SQLite and sends them to the main thread immediately, then continues loading. The main fixture is blank: this measures delivery and scheduling, not real grid rendering. The 30-column synthetic dataset is unchanged except for a query-generation prefix on document_number to detect cross-query contamination. No Asqueel dependency source or Gramlot runtime was changed.

**Completed full runs.** Each size has one independent fresh-browser run on Apple M4 / 24 GiB, Chromium 156, with the same uncompressed loopback payload of **404,890,606 bytes**. Final logical SQLite size is **205,320,192 bytes**. These are single exploratory samples, not statistical optima or network predictions.

| Steady block rows | Load through final commit | First 30 rows at main thread | Sampled Chromium RSS sum | Largest SQL block |
| --- | ---: | ---: | ---: | ---: |
| 1,000 | 10.449 s | 99.6 ms | 749.9 MiB | about 0.46 MB |
| 10,000 | 10.064 s | 98.5 ms | 925.8 MiB | about 4.53 MB |
| 50,000 | 11.486 s | 97.7 ms | 1,392.4 MiB | about 22.58 MB |

Load time starts inside the Worker before opening/migrating the database and ends at the last commit. First-page time starts on the main thread before Worker startup. Memory is the sum of dedicated Chromium process RSS, sampled every second over the entire run including verification: it can double-count shared mappings and miss short peaks; it is not exact Worker heap or physical RAM. The 10,000-row sample is only about 4% faster than 1,000; one sample cannot establish that difference as stable. The 50,000-row sample was slower and larger in memory. SQL construction took about 1.3 s cumulatively; insertion about 4.0–4.2 s; commits about 2.3–2.8 s. These sums are instrumented stages, not a complete CPU profile.

**Query replacement checks.** The consumer switches its active query identifier immediately. The Worker receives replacement, aborts the fetch, finishes or rolls back the current SQLite operation, closes/deletes only the old query's isolated database, then starts the new query serially in the same Worker. There is no native SQLite interrupt wired into this fixture. The new request returns 120 records and is verified through commit/reopen; its first 30 are delivered earlier. A deliberately replayed old page after the new page tests rejection by query identifier; it is a synthetic delayed-delivery check, not a claim that the network spontaneously delivered that duplicate.

| Block rows | New first page after switching immediately on first 30 | Cancellation/cleanup acknowledgement when switching during INSERT | New first page when switching during INSERT |
| --- | ---: | ---: | ---: |
| 1,000 | 22.6 ms | 25.2 ms | 42.4 ms |
| 10,000 | 24.1 ms | 130.7 ms | 145.3 ms |
| 50,000 | 24.2 ms | 685.4 ms | 700.0 ms |

The in-flight trigger is emitted after BEGIN and immediately before executing the first steady SQL block. Event processing is cooperative: cancellation cannot assume instantaneous interruption of synchronous SQL work. The 1,000-row block completed/committed before cancellation was observed (1,030 old rows total); the 10,000/50,000 attempts rolled back the in-flight block, retaining only the first 30 until the old database was deleted. All old databases were deleted, all new results passed verification, and no old-generation page was accepted after the switch.

After switching on the first 30 rows, only 128 old records had been decoded and 30 committed; the fixture server stopped generation at 1,024 rows, about 0.81 MB written, instead of producing 500,000. During later switches the server stopped at 2,304 / 15,744 / 58,240 rows respectively. This demonstrates cancellation propagation to this synthetic HTTP producer. Real database cursor/query cancellation remains an integration responsibility; stopping fetch does not by itself prove a PostgreSQL query was cancelled.

**Main thread and read access.** No main-thread long tasks were observed; animation-frame intervals stayed around 16.7 ms on the blank page. This is not proof of real-grid smoothness. More materially, post-load reads using ORDER BY id LIMIT 30 OFFSET were about 0.8 ms at offset zero, **1.28–1.45 s at offset 250,000**, and **2.57–2.70 s at offset 499,970**. The full load therefore succeeds, but deep ordinal access through OFFSET is too slow to assume fluid scrolling. Indexed ordinal/range access and its treatment of sort/filter remain to be designed and measured. Full validation/read/reopen/cleanup took the overall cases to about 19.6–20.9 s; that must not be confused with the 10–11.5 s loading time.

**Verification and decisions exposed.** Nine final smoke cases passed, followed by three complete 500,000-row loads and six replacement cases. All complete results verified row order/width, count, primary-key sum, three full 30-field samples, and count after adapter reopen; all temporary databases were deleted. Source hashes confirm inspected dependencies remained unchanged. [Raw complete suite](../../ports/PORT-0023-grid-and-stores/benchmark/results/bulk-500000.json), [method and reproduction](../../ports/PORT-0023-grid-and-stores/benchmark/README.md), and retained scripts provide the evidence.

The measurements support keeping small bounded work units in consideration; they do not approve a fixed block size. Still to decide: first-page publication/commit policy; fixed or adaptive block sizing; partial versus complete collection state and available sort/filter/count operations; cancellation and partial-cache retention; integration of streaming RPC and upstream cancellation; and indexed access to an ordinal row. Any general SQL literal/bulk optimization belongs in Asqueel, with its complete type/default/partition contract, rather than copying the fixture's fixed-schema conversion into Gramlot.


<a id="gc-320-145"></a>

## 145 · PostgreSQL saved-selection comparison — 2026-10-25

The owner asked whether retaining the saved selection in PostgreSQL and sending data to the client is preferable. The comparison here interprets that as **server-retained selection with requested pages**, versus shipping the complete result into the Worker. This is an analysis of the already expressed PostgreSQL direction (§125), not a new approved runtime contract.

A dedicated PostgreSQL 17.7 cluster was initialized under /tmp, listening only on a private Unix socket. It used defaults including shared_buffers=128MB, work_mem=4MB, fsync/on, synchronous_commit/on and full_page_writes/on. No application database or connection configuration was used. The same 500,000 × 30 synthetic records were copied into a source table; source preparation (~2.97 s) is excluded because this experiment starts with business records already in PostgreSQL. Three iterations materialized an UNLOGGED selection, generated `_rowidx` using row_number() OVER (ORDER BY id)-1, built its unique index and ran ANALYZE. The explicit window order gives deterministic ordinal semantics; the recovered historical code used OVER () instead. The source/OS cache was warm. This is not a cold-cache or concurrent multi-user capacity test.

| Operation | Observed across three iterations |
| --- | ---: |
| Materialize 500,000 rows | 444–475 ms |
| Build unique ordinal index | 55–58 ms |
| Materialize + index | 499–532 ms |
| Add ANALYZE: total measured stages | 745–757 ms |
| Read 30 rows by indexed ordinal range, start/middle/end | 0.027–0.054 ms SQL execution |
| Read 30 rows by OFFSET halfway / near end | 39.6–41.4 ms / 77.3–81.2 ms SQL execution |
| Filter region and sort gross amount, no supporting secondary index | 22.2–23.1 ms SQL execution |
| GROUP BY region, no supporting secondary index | 37.0–50.6 ms SQL execution |

PostgreSQL selection storage was 206,585,856 table bytes and 217,849,856 total bytes including indexes. Counts, key sum, ordinal bounds, full-field samples against source, and the identities of all requested page rows passed. EXPLAIN ANALYZE/BUFFERS plans and measured stage times are retained in [results](../../ports/PORT-0023-grid-and-stores/benchmark/results/postgres-500000.json). The cluster was stopped and its temporary directory removed after verification. The script stops its own cluster in finally; its printed stoppedClusterPath identifies disposable synthetic artifacts if reproducing.

**Comparison limits and implications.** The Worker path measured a full uncompressed 404.9 MB HTTP/TYTX transfer plus SQL import in 10–11.5 s; PostgreSQL figures above measure database operations only, excluding HTTP, TYTX serialization, RPC latency, browser rendering and final transaction acknowledgement. They must not be presented as directly equivalent end-to-end measurements. Warm indexed PostgreSQL range reads also must not be compared to SQLite OFFSET as if both used the same access algorithm; indexed SQLite ordinal/range access has not yet been measured.

Nevertheless, server-retained selection avoids transferring the complete 404.9 MB unless the user actually consumes it. The measured sub-second materialization is consistent with the owner's earlier performance report. This supports the already stated PostgreSQL direction for large online administrative collections, while full client materialization remains a candidate for workloads that need the complete result locally. PostgreSQL has a per-selection server storage/CPU and lifetime cost; client loading moves storage/memory costs to each browser. No scale/concurrency winner is established by this single-user fixture.

Still required for a complete product comparison: actual paged RPC/first-paint and scrolling under representative latency, selective prefetch/cache behavior, query cancellation, current-selection ordinal handling after sort/filter, and concurrent selection lifecycle/resource limits. The measured filter/sort/group queries do not rebuild or validate an ordinal mapping for the derived result. No runtime adoption, adapter change or new API is implemented by the comparison.
