# 340 · Bag JS calculation and validation: deferred ideas

Document ID: **GC-340**. Updated: **2026-10-28**.

**Status: reminder, not an implementation contract.** The owner requests keeping
these ideas for later. For the current grid work, formulas and totals follow the
legacy model. No Bag JS modification is authorized.

[Concise reference](../../docs_llm/future/340-bag-js-calculation-and-validation.md).
[Legacy Python mechanisms](335-bag-formulas-and-validation.md).
[Updated legacy grid review](345-legacy-grid-filtering-review.md).
[Evidence](../../ports/PORT-0023-grid-and-stores/review-2026-10-28/README.md).

<a id="gc-340-005"></a>

## 005 · Owner direction

After discussing possible equivalents of Python Bag formulas and validators in
Bag JS, the owner said: “fai un do da tenere li. per il momento per formule e
totali ci leghiam al modo legagy”.

This confirms two distinct dispositions:

1. Keep a future reminder about data-level calculation and validation primitives.
2. For now, retain the legacy grid direction: declarations in the struct, grid
   calculation writing results into its store, and column totalization/footers.

The owner already clarified that a second grid sharing the store can display
calculated values without declaring the same formula. Multiple grids alone do
not require moving calculation ownership into a new store engine.
Exact Gramlot grammar, execution details and aggregate scope still require their
own contract. Choosing the legacy model does not approve its defects, fallbacks,
private compiler or arbitrary execution of formula text arriving through Data.

<a id="gc-340-010"></a>

## 010 · What was found in the installed JavaScript Bag

> **Inspection record, 2026-10-28.** Installed `@genrojs/bag` package metadata
> reports `0.11.0`. This is the inspected local snapshot, not a claim about the
> latest upstream release or modern Python parity.

The [manifest](../../ports/PORT-0023-grid-and-stores/review-2026-10-28/manifest.json)
fingerprints the installed sources and current Gramlot consumers.

| Existing mechanism | Source and implication |
| --- | --- |
| `BagResolver`, `BagCbResolver` | `src/resolver.js`: callbacks, cache lifetime and read-only/materialized caching already exist; start from these rather than adding a second resolver abstraction |
| Explicit reads | `BagNode.getValue` delegates to `resolve`; resolver `reset()` invalidates for a later read. Removed `reactive`/`interval` options are rejected |
| Writable resolver cache | `cachedValue` writes to the attached node with notifications disabled when `readOnly` is false. This is not a complete reactive derived-value publication protocol |
| Mutation events | `BagNode.setValue` stores the new value before invoking the legacy value hook and subscriptions. These callbacks cannot serve as a guaranteed pre-write rejection boundary |
| Formula/validation APIs | No equivalents of legacy `defineFormula`, `defineSymbol` or `BagValidationList` were found in this installed public surface and value-assignment path |

The default `readOnly` is false for both resolver classes, unlike the legacy
Python `BagFormula` default. An analogous computed-on-read use must explicitly
choose its materialization and notification semantics rather than assume parity.

<a id="gc-340-015"></a>

## 015 · Potentially useful primitives, still proposals

**Computed values.** A data container can expose a value calculated independently
of the grid or form that reads it. Existing callback resolvers are the first
mechanism to evaluate. A reusable expression declaration, dependencies and error
reporting would be separate design questions; there is no proposal to copy
legacy Python `eval` or introduce unrestricted JS evaluation into Bag.

**Validation before assignment.** A deliberate validation boundary could reject
an invalid candidate before replacing the accepted value or emitting a successful
change. It would be useful for writes originating from different widgets,
controllers and synchronization paths. Whether it belongs in Bag itself, an
explicit Bag extension or an owning store remains undecided.

**Attribute fields.** Any proposal must account for both node values and node
attributes: legacy value validators did not guard fields stored in attributes.
No implicit conversion between row representations is authorized.

These are possibilities to investigate when needed, not missing capabilities
that this documentation task is authorized to implement.

<a id="gc-340-020"></a>

## 020 · Existing Gramlot responsibilities to preserve

| Layer | Current evidence / future boundary |
| --- | --- |
| Bag/resolvers | Data, mutations and explicit resolution; inspect the owning library before extending it |
| Gramlot Source runtime | Existing `dataFormula`, bindings and controllers already manage reactive execution and result writeback (`js/src/binding/providers.js`) |
| Controls | `FieldState` and `validateInput` validate candidates and coordinate presentation/async validation; accepted Data writes remain owned by the control adapter |
| Grid/store | Current discussion retains grid-declared formulas; future store-level formulas are deferred. No additional reactive engine is selected |
| Provider/persistence | Parent-save baselines, conflicts, transactions and database constraints require their own contracts; a validator receiving a current `oldvalue` is not an optimistic-concurrency protocol |

A client-side check does not establish a database invariant. Likewise, a value
computed when read does not notify all existing views merely by existing. Keep
computation, write validation, publication and persistence distinct.

<a id="gc-340-025"></a>

## 025 · Questions for reopening this reminder

1. What concrete consumer needs data-level rules beyond existing resolvers and
   Gramlot reactive providers?
2. Is a derived value lazy, cached or materialized? What changes invalidate it or
   publish an updated result? How are dependencies and cycles handled?
3. Does validation only reject or also explicitly transform values? How are
   multiple rules ordered and errors represented?
4. Can a check be asynchronous? If so, who retains the accepted value and pending
   candidate, and who excludes obsolete results?
5. What is the unit of validation: value, attribute, row or multi-row operation?
6. How do authoritative server validation and save/conflict handling compose with
   browser feedback, without assuming shared-memory atomicity across a network?
7. How are rules declared and activated through existing Source mechanisms, and
   how is Python/JS behavior made explicit without silently normalizing inputs?

No public names or signatures are chosen here. Apply GC-225 if this work is
opened; use an owner-approved bounded dependency assignment for library changes.

<a id="gc-340-030"></a>

## 030 · Completion and limits

This reminder records local source inspection only; no new Bag JS runtime tests
or feature qualification are claimed. GC-335 retains separate Python legacy
probes, and GC-345 retains the updated legacy grid tests. Documentation pairing,
links, evidence hashes and the public-documentation boundary are checked.

No dependency or runtime edits, new aliases, compatibility layer or rule engine.
The next grid discussion continues with the legacy formula/totalization model;
this reminder is not a prerequisite or an execution plan for that work.
