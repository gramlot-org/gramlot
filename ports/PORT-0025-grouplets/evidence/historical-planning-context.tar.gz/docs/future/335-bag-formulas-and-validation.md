# 335 · Bag formulas and data validation: legacy reminder

Document ID: **GC-335**. Updated: **2026-10-28**.

> **Historical record.** This document recovers mechanisms from GenroPy's Python
> Bag for a possible future store design. The examples are legacy Python APIs,
> not Gramlot APIs or an approved port. No runtime implementation is requested.

[Concise reference](../../docs_llm/future/335-bag-formulas-and-validation.md).
[Collection model](330-collection-store-agent-brief.md).
[Grid/store investigation](320-grid-and-stores.md).
[Evidence and executable probes](../../ports/PORT-0023-grid-and-stores/README.md).

<a id="gc-335-005"></a>

## 005 · Owner context and scope

The owner clarified that a grid may declare a formula and write its result into
the shared store; another grid using that same store sees the result without
declaring the formula itself. Multiple grids are an uncommon case and do not, by
themselves, require moving formulas out of the grid structure.

The owner then requested this reminder: “esatto . magari in futuro potremmo
dichiarare delle formule a livello di store. se guardi le bag legacy python in
genropy ne trovi traccia sia di formule che di validaiuoni sui dati. varrebbe la
pena di ricavartne un doc promemoria”. This records the 2026-10-28 discussion,
not the date when the legacy mechanisms were introduced.

**Confirmed scope:** recover and explain the historical mechanisms. **Future
possibility:** formulas declared at store level. No store formula API, validation
protocol, replacement of grid formulas or implementation schedule is approved.
This note does not settle the rest of the ongoing grid/struct design.

<a id="gc-335-010"></a>

## 010 · Sources and verification boundary

Inspected local GenroPy revision:
`fa35e5adfa6ad1b269f3a22a9b12c4c1ee6513ea`. The two evidence files have no local
diff against that revision. Exact SHA-256 fingerprints are retained under
[PORT-0023](../../ports/PORT-0023-grid-and-stores/legacy-bag-formulas-evidence.json).

| Source | Relevant mechanism |
| --- | --- |
| [gnrbag.py:1676](https://github.com/genropy/genropy/blob/fa35e5adfa6ad1b269f3a22a9b12c4c1ee6513ea/gnrpy/gnr/core/gnrbag.py#L1676) | `defineSymbol`, `defineFormula`, `formula` |
| [gnrbag.py:3147](https://github.com/genropy/genropy/blob/fa35e5adfa6ad1b269f3a22a9b12c4c1ee6513ea/gnrpy/gnr/core/gnrbag.py#L3147) | `BagFormula` resolver |
| [gnrbag.py:203](https://github.com/genropy/genropy/blob/fa35e5adfa6ad1b269f3a22a9b12c4c1ee6513ea/gnrpy/gnr/core/gnrbag.py#L203) | Node reads and validated value assignments |
| [gnrbag.py:2472](https://github.com/genropy/genropy/blob/fa35e5adfa6ad1b269f3a22a9b12c4c1ee6513ea/gnrpy/gnr/core/gnrbag.py#L2472) | `BagValidationList` and built-in validators |
| `gnrbag.py:3349`, `testFormule()` | Invoice example: row formulas, parent references, chained totals |
| `gnrpy/tests/core/gnrbag_test.py:185`, `test_BagNodeInternals` | Existing validation assertions, inspected but not executed here |

The process explicitly imported the historical `gnr.core.gnrbag` module in
`legacy` mode. This does not establish the APIs or behavior of the separate
modern `genro-bag` package, JavaScript Bag or current Gramlot.

<a id="gc-335-015"></a>

## 015 · Formula authoring and evaluation

Three cooperating methods existed:

| Method | Responsibility |
| --- | --- |
| `defineSymbol(**symbols)` | Register symbolic names mapped to Bag paths |
| `defineFormula(**formulas)` | Register reusable named expression strings |
| `formula(expression_or_name, **symbols)` | Create a `BagFormula` resolver with the expression and symbol mappings |

Legacy Python example, exercised by the probes:

```python
from gnr.core.gnrbag import Bag

b = Bag()
b.defineSymbol(q='quantity', p='price')
b.defineFormula(amount='$q * $p')
b['rows.a'] = Bag(dict(quantity=2, price=3))
b['rows.a.total'] = b.formula('amount')

assert b['rows.a.total'] == 6
b['rows.a.quantity'] = 4
assert b['rows.a.total'] == 12
```

The expression can also be inline:
`b.formula('$q * $p', q='quantity', p='price')`. It is a Python expression;
`$symbol` placeholders are replaced with Bag access expressions. Evaluation uses
the containing Bag of the node where the resolver is installed. A formula built
at the root can therefore read fields relative to a row. Paths such as
`../../rate` can reach an ancestor; `formula()` enables Bag back-references.

The resolver captures a copy of the symbol mapping at construction. Changing
`defineSymbol` later affects newly created resolvers, not existing ones. The
implementation also supports symbol names starting with `_` by substituting
`curr.getResolver(path)` rather than `curr[path]`; that branch was inspected,
not separately executed in this investigation.

**Evaluation is lazy.** `BagFormula` defaults to `cacheTime=0` and `readOnly=True`:
each normal read recomputes the result, and the result is not written into the
node's static value. Here `readOnly` describes resolver materialization; it is not
a field permission or a concurrency guarantee. Changing an input does not itself
publish a derived-value update for the formula node. This is different from the
PoC grid's formula manager, which writes calculated values into its store.

`BagFormula.load()` uses Python `eval`. This is not a bounded arithmetic language
or a sandbox. The inspected formula path has no dependency graph, topological
recalculation or explicit cycle diagnostic. Evaluation errors propagate on read.
Those limitations are evidence, not a proposed implementation strategy.

<a id="gc-335-020"></a>

## 020 · Aggregates and chained calculations

Because symbols can reference a Bag and expressions can call methods, a formula
can aggregate child records and another formula can use that result:

```python
b['order.rate'] = 2
b['order.rows.a'] = Bag(dict(amount=3))
b['order.rows.b'] = Bag(dict(amount=5))
for key in ('a', 'b'):
    b[f'order.rows.{key}.total'] = b.formula(
        '$amount * $rate', amount='amount', rate='../../rate')
b['order.total'] = b.formula("$rows.sum('#v.total')", rows='rows')
assert b['order.total'] == 16
```

`Bag.sum` operates over the Bag content selected through `digest`; it is not a
server query aggregate or a total over unloaded records. The source's invoice
example already combines row amounts, an ancestor parameter, subtotal, tax and
final total. Decimal multiplication was verified when the operands are Decimal;
Python expression semantics still apply, with no automatic numeric-type policy.

For future virtual stores the scope remains a separate decision: resident rows,
filtered projection, a child window or the complete logical collection. A local
sum does not supply a complete remote total.

<a id="gc-335-025"></a>

## 025 · Validation belongs to BagNode value assignment

Validators can be installed through `BagNode(..., validators=...)`,
`Bag.setItem(..., _validators=...)`, or `Bag.addValidator(path, validator, parameter)`.
A callable validator receives `(value, oldvalue, parameter)` and returns the next
value, or raises an exception. Validators run in registration order, passing the
transformed value to the next validator. They are not just Boolean predicates.

```python
b = Bag()
b.setItem('code', 'mi',
          _validators={'case': 'upper', 'inList': 'MI,NA', 'length': '2,2'})
assert b['code'] == 'MI'
b['code'] = 'na'
assert b['code'] == 'NA'
# b['code'] = 'ROMA' raises BagValidationError; the accepted value remains 'NA'.
```

`BagNode.setValue` validates before replacing `_value` and before emitting its
value-update notification. For the plain scalar assignment exercised here, a
validation exception preserves the previous value and emits no update. This is
not a transaction for a multi-field operation or side effects inside a callback.
Adding a validator to an existing node does not retroactively validate its value.

The validator receives the node's current value as `oldvalue`, not the value that
a remote child originally loaded. It therefore does **not** implement the
original-value comparison and atomic save discussed for parent/child stores.

**Field representation matters:** these validators guard a node's value.
`setAttr` changes bypass that value-validation chain. A record represented by
fields in a nested Bag can give each field its own node; a record represented by
attributes does not automatically get equivalent per-field validation.

<a id="gc-335-030"></a>

## 030 · Built-ins and limitations to retain

| Validator | Observed implementation |
| --- | --- |
| `case` | Requires a string; converts upper/lower/capitalized case |
| `inList` | Checks membership in a comma-separated list of strings |
| `length` | Checks inclusive bounds encoded as a two-integer string, e.g. `2,20` |
| callable | Receives new value, current old value and the registered parameter |
| `db` | Stub returning the input unchanged; no database validation |
| `hostaddr` | Signature does not match the three-argument dispatcher; raises `TypeError` before DNS code runs |
| unknown name | Falls through to `defaultExt`, prints a missing-validator message and returns `None`; assignment can silently erase the value |

The last three are reproduced legacy limitations, not compatibility requirements.
Fields named `status` and `errMsg` exist on `BagValidationList`, but the inspected
dispatch path does not implement a structured validation-status protocol. The
helper `coerceFromText` is not wired into that pipeline and is not evidence of
automatic coercion. UI error presentation, async checks, cross-record uniqueness,
database constraints and concurrency guarantees are not supplied by this chain.

<a id="gc-335-035"></a>

## 035 · Reminder for future Gramlot design

The reusable idea is that data can carry calculations and write validation
independently of the widget displaying it. This is compatible with keeping the
owner's current grid-declared formulas while considering store-level declarations
later; it does not require implementing both now.

Questions to resolve only when that work is opened:

1. Is a formula computed on read or materialized with change notifications?
2. How are row context, parent paths, dependencies, errors and cycles represented?
3. If grid and store both declare calculations for a field, which owns its writes?
4. What aggregate scope is explicit for partial/virtual collections?
5. Where do validation and permitted transformations run for value and attribute
   rows, and how do they compose with existing control validation and server rules?
6. How do validation failures and original-value conflicts participate in save?
7. How are declarations transported and activated through existing Source
   mechanisms? A formula string in a Data struct is not automatically executable
   under constitution 11.53; the legacy `eval` and PoC compiler are not a port contract.

Inspect current Bag, resolver, Source, binding and controller services before any
implementation. Report missing dependency capabilities in their owning projects;
do not restore old internals or add Gramlot workarounds. No class names, grammar
tags or runtime extensions are approved here.

<a id="gc-335-040"></a>

## 040 · Verification receipt

On 2026-10-28, all **11** isolated characterization cases in
[legacy-bag-formulas-probe.py](../../ports/PORT-0023-grid-and-stores/legacy-bag-formulas-probe.py)
passed against the exact legacy module. They cover lazy reads and absence of
derived writes; relative/captured symbols; ancestor access and aggregates;
formula exceptions; ordered transformations; rejected-write preservation;
callable old values; attribute bypass; and the three incomplete validator paths.
The probes include a Decimal multiplication and make no network requests.
All three Python examples in this document were also executed successfully.
Successful characterization of a defect does not make it accepted behavior.

Reproduce from the Gramlot checkout with a Python environment containing the
legacy GenroPy dependencies:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/path/to/genropy/gnrpy \
  /path/to/legacy-venv/bin/python \
  ports/PORT-0023-grid-and-stores/legacy-bag-formulas-probe.py
```

The existing pytest case was inspected but could not be run because the legacy
environment has no pytest installed. No full legacy suite, browser, modern Bag,
database transaction or cross-language qualification is claimed. Repository
runtime and dependency sources were not modified. Documentation checks cover
paired anchors, local links, evidence hashes and the public-site exclusion.
The repository's `scripts/check_public_docs.py` also passes on the existing public
build (11 pages, search, downloadable sources, links and mirrored anchors); this
internal future note is deliberately absent from that build.
