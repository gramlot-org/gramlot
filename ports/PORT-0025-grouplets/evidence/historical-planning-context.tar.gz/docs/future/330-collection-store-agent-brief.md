# 330 · Collection store logic and open decisions

Document ID: **GC-330**. Updated: **2026-10-27**.

A collection store provides a common way for grids and other widgets to access and edit a collection, while its implementation handles the data origin, row representation, loading and saving. The owner wants to preserve this useful legacy abstraction without carrying forward its accumulated implementation layers.

This English brief consolidates the owner's explanation for a receiving agent. **Clarified** means explicitly described by the owner; it does not mean implemented or accepted as a complete Gramlot API. **Open** means a contract or responsibility still needs an owner decision. Historical behavior and benchmark evidence are identified separately.

[Concise reference](../../docs_llm/future/330-collection-store-agent-brief.md). [Investigation and discussion record](320-grid-and-stores.md). [PostgreSQL selection brief](325-postgresql-unlogged-selections.md). [Port evidence](../../ports/PORT-0023-grid-and-stores/README.md).

<a id="gc-330-005"></a>

## 005 · The common abstraction

**Clarified.** Different collection-store types expose the same conceptual methods and implement them differently. A view can ask for the next row or row number X. Filtering and sorting belong to the collection abstraction. A grid is one consumer; the contract also serves other widgets.

The owner's statement was: “ogni collectyon strire espione gli stessi metodi ma a seconda del tipo li implementa in modi diverso”. The spelling is retained here as source evidence; the intended meaning is a common consumer contract with type-specific implementations. See [GC-320 §095](320-grid-and-stores.md#gc-320-095).

**Open.** The exact method list, signatures, returned objects, asynchronous behavior, errors and optional capabilities are not defined. A common contract does not imply that every origin can write, delete, support arbitrary jumps efficiently or implement every operation identically. It also does not select an inheritance hierarchy.

<a id="gc-330-010"></a>

## 010 · Terms that must remain distinct

| Term | Meaning in this discussion |
| --- | --- |
| Collection store | The abstraction through which a consumer accesses a set of rows and its supported operations |
| Data Bag | The collection's data representation; not the UI Source tree |
| Origin | Where data is loaded from and, when writable, where changes are saved |
| Working collection | The data currently exposed for the selected context, possibly a detached copy |
| Context | The parameters identifying the current collection, such as a selected region or query |
| Row identity | Which record a row represents; exact identity rules remain open |
| Row position | A row's ordinal in an ordering; filtering and sorting can change it |
| Resident data | Rows currently available locally; not necessarily the whole logical collection |
| Named selection | A server-side saved query result identified for subsequent requests |
| UI selection | Rows selected by the user; different from a named query selection |
| Save | Writing working changes to their origin, including another in-memory Bag |
| Autosave | A policy that triggers a write automatically in specified contexts |

The legacy `gnr.formstores.Collection` navigates and edits records using a parent collection. It is not interchangeable with the collection-store family `gnr.stores`. Similarly, PoC `CollectionStores` is a registry, not the whole abstraction. [GC-320 §§055–090](320-grid-and-stores.md#gc-320-055) documents these naming collisions.

<a id="gc-330-015"></a>

## 015 · Bag data and the two row layouts

**Clarified.** The owner describes collection-store data as always a Bag. In memory, a row can use either of two analogous layouts:

| Layout | Where the row fields are stored |
| --- | --- |
| Attribute row | Attributes of the row node; the row node's value is null |
| Value row | A Bag in the row node's value, containing the fields |

These are illustrative data shapes, not constructors or a proposed API:

```text
Attribute row:
  province_MI: value = null; attributes = {code: "MI", name: "Milano"}

Value row:
  province_MI: value = Bag
    code: "MI"
    name: "Milano"
```

The consumer should obtain the required row/field behavior through the common store contract. The layout changes how the implementation accesses and updates fields. This does not authorize silently falling back from one layout to the other.

**Open.** How a layout is declared, the row object returned to consumers, field access/update methods, identity and metadata conventions. “The store is a Bag” does not settle whether a store class subclasses Bag or wraps it. For virtual collections, it does not require every logical row to be resident in one browser Bag.

Owner evidence: [GC-320 §§100–110](320-grid-and-stores.md#gc-320-100).

<a id="gc-330-020"></a>

## 020 · Origins and loading strategies

**Clarified.** The discussion includes the following origins:

| Origin | Owner-described behavior | Boundary still open |
| --- | --- | --- |
| In-memory Bag/path | Store X takes data from a path in store Y; edits can be shared or saved back from a copy | Binding/rebinding and copy/writeback details |
| Database through RPC | A request returns rows for a context; edits can be saved explicitly or by contextual autosave | Persistence protocol, transactions and conflicts |
| Filesystem | A collection of documents with metadata can feed a form that edits a document | Content loading, metadata/content saving, identity and concurrency |
| Generic RPC service, including an external service | A response supplies data that can be represented in a Bag | Response adaptation and whether/how the service supports writes |

Origin, row layout, copy/reference relationship, save policy and resident/virtual loading are distinct aspects of the model. This is a way to describe the requirements, not an approved configuration matrix in which every combination must work.

The owner completed the explanation of **static collection stores** before discussing virtual collections. Here static identifies that part of the discussion; it does not mean read-only, immutable, synchronous or unable to load through RPC.

<a id="gc-330-025"></a>

## 025 · Working copy versus direct shared reference

**Clarified.** Both alternatives are valid depending on context:

| Mode | Load | Editing | Save back to the in-memory origin |
| --- | --- | --- | --- |
| Working copy | Copy the selected source Bag into a separate working store | Changes the copy | Required to transfer the edits to the original |
| Direct shared reference | Use the selected original Bag through its address/reference | Changes the original immediately | No separate copy-writeback step for those edits |

The concrete region/province example resolves earlier ambiguous wording about “referenced” versus “shared”. In this brief, **direct shared reference always means edits immediately affect the original Bag**. It does not mean a detached copy that remembers where it came from.

Direct sharing is not remote autosave: one mutates the same in-memory data, while the other performs a write through a service boundary. Direct sharing also does not imply persistence beyond that Bag or an ability to undo changes.

**Open.** Copy depth and metadata preservation, replacement versus merge on save, concurrent changes to the parent, and lifecycle when a source path changes or disappears. Rollback for shared data has not been specified.

<a id="gc-330-030"></a>

## 030 · The region and province example

The source Bag contains regions, each with its provinces:

```text
regions
  LOMBARDIA
    MI: Milano
    BG: Bergamo
  CAMPANIA
    NA: Napoli
    SA: Salerno
```

A variable datapath selects the province collection for the current region. Selecting Lombardia shows its provinces; selecting Campania shows Campania's provinces.

**Clarified copy behavior.** Loading Lombardia copies its province Bag into the grid's working store. The user edits that copy. To retain those edits when switching region, a save must return them to Lombardia's original Bag before loading Campania. This is a real load/save cycle even though both stores are entirely in memory.

**Clarified shared behavior.** If the grid's store directly references Lombardia's province Bag, editing already changes that original. Switching the reference to Campania changes which data is shown. It must not be described as discarding unsaved Lombardia changes: those changes have already reached the original.

The same conceptual context switch can instead load provinces through an RPC. The origin implementation changes; the need to handle pending edits before replacing the working collection remains.

<a id="gc-330-035"></a>

## 035 · Pending edits when the context changes

**Clarified.** The owner expects a save/discard question when changing region would replace modified, unsaved data. In the copy example, saving targets the previous origin; discarding abandons the pending working edits. The RPC example has the same expectation.

The essential distinction is between the **loaded context** and the **requested next context**. Saving Lombardia's edits must not use Campania's newly selected path or request parameters.

The required conceptual sequence is:

1. The current working collection belongs to Lombardia.
2. A request arrives to switch to Campania.
3. If there are pending edits under the applicable save policy, resolve whether to save them to Lombardia or discard them.
4. The working collection can then be replaced with Campania's data.

This sequence expresses the owner's behavior, not an implemented state machine. **Open:** who detects dirty state, who owns the prompt, validation and save-failure behavior, when the selected-region UI changes, whether navigation can be cancelled, and how rapid successive requests are handled. No silent data-loss policy or rollback mechanism is approved.

<a id="gc-330-040"></a>

## 040 · Explicit save and contextual autosave

**Clarified.** A database store can have an autosave mode in which leaving an edited row triggers an RPC to persist its changes. The owner also included adding and deleting rows. This applies in suitable contexts; it is not a universal default or a requirement to save on every keystroke.

An automatically initiated write still has an acknowledgement and can fail. The exact insert/delete triggers were not specified separately. The dirty-context interaction must account for the chosen save policy and pending writes; it cannot assume that all stores either always prompt or never prompt.

**Open.** Validation timing, write granularity, transaction scope, errors and retries, row/context navigation while a write is pending, server-assigned identities after insert, delete timing and conflicts with concurrent writers. The owner has not assigned these responsibilities among collection store, form, editor and controller.

Owner evidence: [GC-320 §105](320-grid-and-stores.md#gc-320-105).

<a id="gc-330-045"></a>

## 045 · Filtering sorting and row access

**Clarified.** Filtering, sorting, sequential row access and access by row number are part of the collection concept. A widget should not have to know whether fields came from attributes, nested Bags or a remote result.

**Open.** Whether filtering/sorting mutate the underlying Bag or produce a separate projection; whether two consumers share those operations or have independent views; whether identity lookup can access filtered-out rows; how current-row navigation behaves after a transformation; and which operations require server execution.

Position must be distinguished from record identity when defining these contracts. A request for row X depends on an ordering. A record can remain the same while moving to another position after a sort or filter.

**Historical evidence.** Legacy local sorting mutated the Bag and filtering was instance-scoped. The PoC used projected ordering and shared projection state among consumers of one instance. Both had hidden-row lookup hazards in inspected paths. These differences are evidence for a decision, not two implicitly accepted destination behaviors. See [GC-320 §§060 and 090](320-grid-and-stores.md#gc-320-060).

<a id="gc-330-050"></a>

## 050 · Virtual collections and saved selections

**Clarified requirement.** Database collections can range from a few rows to hundreds of thousands. The client must not be assumed to hold the full result before serving the view. The owner described a legacy virtual store that could retain non-contiguous pages and obtain missing rows from the server when the view requested them.

**Historical record.** A named selection identified a server-side result, historically pickled on disk. The client might hold pages 1, 2, 5, 34 and 112, fetching a missing page on demand. This virtual data cache is separate from the grid's DOM window. The old cache is not evidence of a bounded eviction policy or of any particular new DOM strategy.

**Owner-selected direction.** The owner intends to use selections saved in PostgreSQL, supporting operations on the saved result and ordinal access. The recovered UNLOGGED strategy, its row-number column, client interaction and integration caveats are explained in [GC-325](325-postgresql-unlogged-selections.md). This is the owner's backend choice, not a requirement that Gramlot core depend on PostgreSQL.

**Open.** Selection identity/lifetime, page and request sizes, prefetch and eviction, counts, asynchronous random access, row identity outside cached pages, ordering after filter/sort/grouping, edits against snapshots, invalidation, and DOM virtualization. An ordinal in one saved ordering cannot automatically identify a position in another ordering.

<a id="gc-330-055"></a>

## 055 · Progressive loading and query replacement

**Clarified investigation requirement.** The owner requested measurements for 500,000 rows with 30 typical business columns and different block sizes. The UI may show the first 30 records while loading continues, and the user may immediately choose another query. Both time to usable data and the cost of abandoning work matter.

The explored alternative loaded JSONL through TYTX into Asqueel-JS SQLite in a Worker, backed by IndexedDB. It was a measured experiment, not a selected general collection-store implementation. The owner also emphasized that users should avoid unnecessarily broad queries; no numeric row cap or mandatory search UI was chosen.

[GC-320 §§140–145](320-grid-and-stores.md#gc-320-140) retain completed Worker loads, query-replacement experiments and the PostgreSQL comparison. Their timing boundaries differ; they do not establish complete Gramlot RPC/grid behavior. Block sizes used in those experiments are not product defaults.

**Open.** Whether a particular store publishes partial results, how partial counts/filter/sort are presented, cancellation versus retaining a reusable result, how late responses are excluded, and how client cancellation reaches server work. A first visible page, a completed result and a durably saved edit are separate events. PostgreSQL materialization does not by itself guarantee progressive first-page publication.

<a id="gc-330-060"></a>

## 060 · Decision register for the receiving agent

These questions refine the clarified model; they do not reopen its basic concepts.

| Area | Already clarified | Decision still needed |
| --- | --- | --- |
| Consumer contract | Common operations with type-specific implementations | Exact methods, results, asynchronous/error contract and unsupported operations |
| Data layouts | Attribute rows with null values and value-Bag rows | Explicit layout declaration, field access and returned row representation |
| Identity | Views request rows and positions | Keys, index base, missing rows, identity versus ordinal/path and insert identities |
| Copy/reference | Both valid; shared edits reach the original immediately | Copy semantics, writeback merge/replacement and source lifetime |
| Context replacement | Resolve pending edits against the previous origin | Dirty ownership, prompt owner, cancellation, failure and request ordering |
| Autosave | Contextual DB writes, including edit/insert/delete | Triggers, validation, acknowledgement, pending-write navigation and transactions |
| Filtering/sorting | Collection operations | Shared versus independent projections, source mutation and identity lookup |
| Forms/documents | Widgets and document forms consume collections | Collection versus record/form responsibilities; document content/metadata protocol |
| Virtual access | Fetch missing rows/pages; full residency is not assumed | Cache bounds, counts, random access, transformed ordinals and snapshot edits |
| Progressive loads | Early use and rapid query changes must be evaluated | Publication/cancellation/stale-response contract and resource cleanup |
| Server selections | PostgreSQL is the owner's chosen backend direction | Access control, lifetime, revision/invalidation and owning integration layer |
| Architecture | Preserve the abstraction and remove accumulated complexity | Concrete classes/composition, declarations and bounded implementation scope |

No generic compatibility layer, fallback representation or legacy hierarchy follows from this register. Names must follow [GC-225](../internal/225-naming-and-proxy-conventions.md); new runtime design and ownership need explicit confirmation under the [constitution](../00-constitution.md).

<a id="gc-330-065"></a>

## 065 · Behavioral examples for a future contract review

The following are **proposed review scenarios**, not an approved test plan or claims of implemented behavior:

- The same consumer accesses equivalent attribute-row and value-row collections through the agreed contract.
- A copied Lombardia collection changes locally, saves back to Lombardia and then loads Campania. Discard leaves the original Lombardia data unchanged.
- A shared Lombardia collection changes the original immediately; switching context does not promise to undo those edits.
- A failed or pending explicit save/autosave follows an agreed navigation policy without misrouting edits to the next context.
- Two consumers exercise the chosen shared/independent filter and sort semantics; identity lookup follows its separately agreed rules.
- A virtual consumer requests a distant row, then changes sort or query; pages are associated with the correct result and ordering.
- A query changes after the first visible rows; old replies and resources follow the chosen cancellation/retention policy.
- A filesystem document form follows the chosen content and metadata load/save boundaries.

The failure-policy and lifecycle cases require the decisions in §060 before expected results can be specified fully.

<a id="gc-330-070"></a>

## 070 · Evidence scope and handoff boundaries

The substantive owner explanations are retained in [GC-320 §§095–110](320-grid-and-stores.md#gc-320-095), including the common contract, filtering/sorting, two Bag layouts, copy/reference example, dirty context switch, autosave, filesystem and generic RPC origins. Virtual alternatives and the owner-specific PostgreSQL choice are in [§§115–125](320-grid-and-stores.md#gc-320-115). These references preserve the earlier conversation's attribution; this brief is dated 2026-10-27 and does not assign that date to the original statements.

Historical implementation evidence is in [GC-320 §090](320-grid-and-stores.md#gc-320-090) and [GC-325](325-postgresql-unlogged-selections.md). Measurements and their limitations are in [GC-320 §§135–145](320-grid-and-stores.md#gc-320-135) and the [benchmark record](../../ports/PORT-0023-grid-and-stores/benchmark/README.md).

The present assignment is to explain the model and expose decisions. No collection-store runtime port, final method contract, new dependency API or formal Live Object Tree semantics is approved by this document. Before implementation, inspect existing Source/Data, binding, controller, resolver and messaging mechanisms; identify concrete gaps rather than creating parallel mechanisms. Read the destination instructions and choose a bounded contract with the owner, resolving one decision at a time without asking again for the concepts already clarified.
