# 345 · Updated legacy grid: filters and adjacent improvements

Document ID: **GC-345**. Reviewed: **2026-10-28**.

> **Historical evidence, not a Gramlot implementation contract.** This review
> supplements GC-320's September source baseline with the GenroPy `develop` tip
> verified on GitHub on 2026-10-28: `a135c9d949d0b014a22f57c418e83b315f85e7bf`
> (commit date 2026-10-27). It does not replace the older evidence with an
> undated claim about all legacy versions.

[Concise reference](../../docs_llm/future/345-legacy-grid-filtering-review.md).
[Earlier investigation](320-grid-and-stores.md).
[Deferred Bag JS ideas and current formula direction](340-bag-js-calculation-and-validation.md).
[Source hashes and test receipt](../../ports/PORT-0023-grid-and-stores/review-2026-10-28/README.md).

<a id="gc-345-005"></a>

## 005 · Assignment and scope

Owner, 2026-10-28: “a proposito di legacy : rivedi bene le legacy grid perche sono
state aggiunte piossibilita di mettere filtri e altre migliotrie”. This requests
renewed inspection, not implementation of all recovered features.

The local GenroPy working files still reflect September; the cached develop ref
is newer but is not treated as current GitHub evidence. The GitHub branch API and
immutable contents were read directly. Twenty-two upstream files and seven local
Bag JS/Gramlot comparison files are fingerprinted in the review manifest.
Read paths include grid rendering, collection stores, widget/filter/formula
helpers, struct authoring, framegrid/customizer, styles, examples and focused tests.

The principal additions are column-value filters, date periods, filter-aware
actions and a hierarchy derived from a column path. Earlier capabilities such
as formulas, totalizers, columnsets, resizing and configuration remain relevant;
they are not all new October features.

<a id="gc-345-010"></a>

## 010 · Column filter declarations

The newer grid adds an icon to supported column headers while retaining sorting
on the title. Examples below are **legacy spelling**, not proposed Gramlot APIs:

```python
grid = pane.quickGrid(value='^.invoices', filterFieldDefault=True)
grid.column('invoice', name='Invoice', filterField=False)
grid.column('customer', name='Customer', filterField=True)
grid.column('issued', name='Issued', dtype='D', filterField=True)
```

| Declaration | Observed meaning |
| --- | --- |
| `filterField=True` on a cell | Filter by that cell's own field |
| `filterField='another_field'` | Filter by another field while presenting an appropriate caption; query-column extraction includes the requested field |
| `filterFieldDefault=True` on the grid | Enable filters for eligible plain data columns, including columns later built through the configurator |
| `filterField=False` | Opt that column out of the default |
| `grid_filterFieldDefault=True` on TableHandler | Forward the grid option from the higher-level declaration |

Default eligibility excludes composite/template/custom-getter, calculated, values,
checkbox/user-set and button cells. Explicit filtering on a composite cell has
separate caption handling, using the filtered value instead of template markup.

**Hard boundary:** `NewIncludedView` supplies the feature; `VirtualSelection`
is explicitly excluded. The check suppresses the icon and the column predicates.
These are browser filters over resident data, not a query protocol for the full
server-side selection. Do not filter one loaded page and call it a global filter.

Sources: [genro_grid.js:1924](https://github.com/genropy/genropy/blob/a135c9d949d0b014a22f57c418e83b315f85e7bf/gnrjs/gnr_d11/js/genro_grid.js#L1924),
[NewIncludedView:4664](https://github.com/genropy/genropy/blob/a135c9d949d0b014a22f57c418e83b315f85e7bf/gnrjs/gnr_d11/js/genro_grid.js#L4664),
[column_filter.py](https://github.com/genropy/genropy/blob/a135c9d949d0b014a22f57c418e83b315f85e7bf/projects/gnrcore/packages/test/webpages/components/Grid/column_filter.py).

<a id="gc-345-015"></a>

## 015 · Popup values, counts and predicate composition

The popup offers distinct values with counts, checkboxes, text search, ascending
or descending value order, an empty-value option, clear-filter action and a
filtered/total row count. Numeric/date values use numeric order when applicable;
captions otherwise use natural, case-insensitive comparison. Empty remains last.

Selected values are **OR** within one column; active columns combine with **AND**.
Counts apply the other active filters but skip the column's own predicate. The
popup retains options with zero matches, and cached captions preserve selected
values that disappeared after a reload. Distinct IDs with the same caption remain
distinct options.

The implementation groups null, undefined and empty string into one empty option.
Other keys are stringified; it does not establish type-distinct identity for e.g.
numeric `1` and string `"1"`. This legacy behavior must not be inherited as a new
typed-value contract without a decision.

Search is shown above six options. Without a search, the pane normally limits
rendered unchecked options after 200; checked options are retained. A search
removes that display limit. These are legacy UI constants, not a cache bound or
chosen Gramlot defaults; distinct counts still traverse the resident items.

`compileFilter` combines the existing text/comparison search, `GridFilterManager`
filter sets and column filters. The older filter-set mechanism supports OR within
a selected group and AND between groups. Existing exclusion-list handling then
participates in building the row-index projection.

Column selections/ranges are written back into the struct cell attributes as
`filterValues` and `filterRange`. Sort direction of popup options is held on the
runtime cell. This alone is not evidence of a complete saved-view persistence
contract for all filter UI state.

Sources: [genro_wdg.js:1968](https://github.com/genropy/genropy/blob/a135c9d949d0b014a22f57c418e83b315f85e7bf/gnrjs/gnr_d11/js/genro_wdg.js#L1968),
[genro_components.js:7130](https://github.com/genropy/genropy/blob/a135c9d949d0b014a22f57c418e83b315f85e7bf/gnrjs/gnr_d11/js/genro_components.js#L7130).

<a id="gc-345-020"></a>

## 020 · Date periods: code corrects an example's prose

Date/datetime columns add From/To fields. Comparison uses the calendar day, with
inclusive bounds and optional open ends; Date objects are converted using their
local calendar day, not an unqualified UTC truncation.

The example docstring says a period and checked values exclude each other.
**The current implementation and tests contradict that wording:** setting a new
period first selects its range, and checking/unchecking individual values then
refines it. Both predicates apply together. An empty checked set inside a period
matches no rows; an empty set without a period clears the value filter.
Removing the period can retain the checked values. Clearing From has a specific
UI rule that also clears To; programmatic one-sided bounds remain supported.

This correction matters for a future specification: do not copy the stale prose
into the new contract. Verified by the period and checkbox tests in
[grid_column_filter.test.js:338](https://github.com/genropy/genropy/blob/a135c9d949d0b014a22f57c418e83b315f85e7bf/gnrjs/tests/grid_column_filter.test.js#L338).

<a id="gc-345-025"></a>

## 025 · Filtered actions and interaction corrections

October fixes carry filtering into operations beyond display:

- `currentItems`/`currentPkeys` make static-selection print and batch actions use
  visible rows when there is no explicit row selection.
- Raw-data export uses that projection, including the case where **zero** rows
  match. An empty filtered result must not be confused with no filter.
- Batch assignment resolves a selected visible row to the right underlying row,
  avoiding changes to another record after filtering.
- Header filter clicks are separated from sort/column-drag/resize hit handling;
  the icon is not a resize area or a column drag source.
- The shared tooltip pane follows its anchor during ancestor scrolling, closes
  when it is clipped/detached and removes its tracking listeners on close/destroy.

The raw-data export tests do not establish correctness for the separate
DOM-scraping formatted export branch in `currentData`, nor full export/print
server execution. Keep that boundary explicit.

Sources: [currentData:5385](https://github.com/genropy/genropy/blob/a135c9d949d0b014a22f57c418e83b315f85e7bf/gnrjs/gnr_d11/js/genro_grid.js#L5385),
`grid_batch_assign_filtered.test.js`, `tooltip_pane_follow_scroll.test.js` and
the filter suite, all at the revision in §005.

<a id="gc-345-030"></a>

## 030 · Hierarchical grid from a path column

The first column may declare `hierarchical='/'` (or another separator):

```python
rows = struct.view().rows()  # legacy struct syntax
rows.cell('description', name='Name', hierarchical='/')
rows.cell('population', name='Population', dtype='L')
```

Paths such as `Tools/Hammers/Claw` become a tree while the remaining columns stay
aligned in the grid. The cell displays the last path segment. Missing ancestors
become synthetic rows, distinct from database records. The store maintains a
visible depth-first projection; sorting acts among siblings at each level.
Open branches survive a row reload. Collapsing a branch moves selection to its
real parent row or removes it when the parent is synthetic.

Both value-Bag and attribute rows are covered. Only the first column activates
this mode; other hierarchical columns produce a warning. A `VirtualSelection`
explicitly refuses it. Hierarchy/filter tests exercise the current visible tree
projection, not a global search that loads and expands hidden remote descendants.

This is a grid presentation built over paths in flat records. It does not approve
a Gramlot `hierarchicalStore` API or automatically replace the current tree.
Sources: [tree mode:7224](https://github.com/genropy/genropy/blob/a135c9d949d0b014a22f57c418e83b315f85e7bf/gnrjs/gnr_d11/js/genro_components.js#L7224),
[tree_grid.py](https://github.com/genropy/genropy/blob/a135c9d949d0b014a22f57c418e83b315f85e7bf/projects/gnrcore/packages/test/webpages/components/Grid/tree_grid.py).

<a id="gc-345-035"></a>

## 035 · Other reviewed improvements and retained formula behavior

| Area | Source evidence and limits |
| --- | --- |
| Resident distinct values | `distinctColumnValues` reads through row conversion for both layouts; captions containing commas use a newline separator. Legacy attribute fallback remains evidence, not an authorized Gramlot representation fallback |
| Concurrent selection loads | A load requested during an in-flight query queues one subsequent load with the latest arguments. Deferred completion/error and callback-throw behavior are tested; this is not cancellation or a latest-response-only publication guarantee |
| Template grid geometry | A headerless single full-width row-template view uses available width when no explicit minimum overrides it. Flex minimum widths and columnset/footer alignment also have fixtures; no browser performance/visual qualification was executed here |
| Template activation | Literal row templates have a trusted-template path while row data still goes through the final sanitization pass. This is a legacy mechanism, not permission to copy it around Gramlot Source activation |
| Configurator/struct | Existing columnsets, formatting, dynamic struct and input/print customization remain relevant; the inspection does not establish whole-colgroup drag or independent scroll as existing legacy features |
| Formula declarations | `formula`, `calculated`, `formula_*` parameters and special `#`, `+=field`, `%=field` expressions remain in GridChangeManager; `calculateFormula` writes through `collectionStore().updateRowNode` |
| Totals | `totalize=True` maps to a Data total path; an explicit path is possible. Footers can prefer filtered totals. More than one selected row takes priority over the filtered collection in `calculateFilteredTotals`; server-provided totals have a separate path |

The current owner direction is to retain legacy formulas/totals for now, not to
move them into Bag JS. Preserve useful behavior while specifying its scope: whole
resident collection, filtered rows, selected rows or server result are different
totals. The legacy regex dependency extraction, dynamic evaluator, error-to-null
behavior and compatibility paths are not automatically approved for Gramlot.
The dedicated formula/totalizer behavior in this section is source inspection;
the 67 tests below qualify the filtering/interaction scope, not a new complete
formula suite.

Sources: [GridChangeManager:2270](https://github.com/genropy/genropy/blob/a135c9d949d0b014a22f57c418e83b315f85e7bf/gnrjs/gnr_d11/js/genro_wdg.js#L2270),
[selection load:7800](https://github.com/genropy/genropy/blob/a135c9d949d0b014a22f57c418e83b315f85e7bf/gnrjs/gnr_d11/js/genro_components.js#L7800),
[template/flex geometry:613](https://github.com/genropy/genropy/blob/a135c9d949d0b014a22f57c418e83b315f85e7bf/gnrjs/gnr_d11/js/genro_grid.js#L613).

<a id="gc-345-040"></a>

## 040 · Comparison with the PoC and design implications

The reviewed PoC remains `10478b57ce3f22e6445eb6b72eba343520cbebac`: it contains
local store filter/sort, bounded DOM rendering, formula writers and resident
totals. The reviewed collection/grid sources do not implement the newer
`filterField`/`filterFieldDefault` popup, date range UI or path-column tree mode.
Do not describe the September PoC as covering these October additions.

For the proposed Gramlot struct, retain these as requirements to discuss:

1. Column filter capability and current filter state are distinguishable from
   the layout/group definition, even if expressed through the same struct grammar.
2. Filter state must flow through the generic store contract when filtering is
   remote; the grid cannot infer the full universe from its loaded window.
3. Counts, totals, selection, export and batch operations must identify their
   projection explicitly, including an empty result.
4. Group dragging/independent horizontal scrolling must coexist with filter icons,
   resizing, column sorting and popup anchoring. The legacy has useful interaction
   tests but does not implement the proposed new colgroup semantics.
5. A minimal read-only grid need not implement every recovered feature. The owner
   selects the first scope; this review is not an expanded implementation plan.

<a id="gc-345-045"></a>

## 045 · Verification receipt

All **67** upstream Node tests passed against source files retrieved at the exact
GitHub revision. The suites cover column filters/date periods/actions, tree mode,
distinct values, filtered batch assignment, queued selection reloads and tooltip
scroll/lifecycle. The initial attempt lacked `gnrstores.js`; retrieving that
same-revision dependency resolved the setup failure, then the full selection passed.

The tests execute real legacy methods in VM contexts with stubbed Dojo/browser
surfaces. They do not launch the full application, a database, or a real browser;
Python example pages and visual fixtures were inspected, not run. No latency,
large-data, full accessibility or cross-browser qualification is claimed.

The [manifest and log](../../ports/PORT-0023-grid-and-stores/review-2026-10-28/README.md)
retain immutable source paths, hashes and reproduction instructions. Paired docs,
local links, evidence and the existing public-doc checker are verified. No legacy,
PoC, dependency or Gramlot runtime sources were modified by this review.
